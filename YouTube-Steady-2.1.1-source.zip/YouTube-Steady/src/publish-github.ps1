param(
    [switch]$PrepareOnly,
    [string]$SupportUrl,
    [switch]$AllowWithoutSupport
)
$ErrorActionPreference = 'Stop'
$steadyProject = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$steadyOutput = Split-Path -Parent $steadyProject
$steadyNode = (Get-Command node -ErrorAction Stop).Source
function Invoke-SteadyCommand([string]$Program, [string[]]$Arguments) {
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Command failed: $Program $($Arguments[0])" }
}
$steadyConfig = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'distribution.json') -Raw | ConvertFrom-Json
if ($SupportUrl) { Invoke-SteadyCommand $steadyNode @((Join-Path $PSScriptRoot 'build-distribution.cjs'),'--support-url',$SupportUrl) }
$steadyConfig = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'distribution.json') -Raw | ConvertFrom-Json
if (!$PrepareOnly) {
    $steadyGh = (Get-Command gh -ErrorAction Stop).Source
    Invoke-SteadyCommand $steadyGh @('auth','status','--hostname','github.com')
    $steadyAccountText = & $steadyGh api user
    if ($LASTEXITCODE) { throw 'Sign in using gh auth login before publishing.' }
    $steadyAccount = $steadyAccountText | ConvertFrom-Json
    $steadyRepository = "$($steadyAccount.login)/YouTube-Steady"
    if ($steadyConfig.repository -and $steadyConfig.repository -cne $steadyRepository) { throw 'Configured repository differs from the signed-in personal account. Review distribution.json first.' }
    if (!$steadyConfig.supportUrl -and !$AllowWithoutSupport) { throw 'Supply your own public PayPal.Me link with -SupportUrl, or explicitly use -AllowWithoutSupport to publish with tips hidden.' }
    Invoke-SteadyCommand $steadyNode @((Join-Path $PSScriptRoot 'build-distribution.cjs'),'--repository',$steadyRepository)
}
Push-Location $steadyProject
try {
    Invoke-SteadyCommand $steadyNode @((Join-Path $PSScriptRoot 'build-locales.cjs'),'--check')
    Invoke-SteadyCommand $steadyNode @((Join-Path $PSScriptRoot 'build-distribution.cjs'),'--check')
    Invoke-SteadyCommand $steadyNode @('--test','tests/depan.test.cjs','tests/settings.test.cjs','tests/i18n.test.cjs','tests/distribution.test.cjs')
    & (Join-Path $PSScriptRoot 'package-release.ps1')
    Invoke-SteadyCommand $steadyNode @((Join-Path $PSScriptRoot 'build-site.cjs'))
    $steadyVersion = (Get-Content -LiteralPath 'extension/manifest.json' -Raw | ConvertFrom-Json).version
    $steadyStage = [IO.Path]::GetFullPath((Join-Path $steadyProject "work/github-$steadyVersion"))
    $steadyWork = [IO.Path]::GetFullPath((Join-Path $steadyProject 'work')) + [IO.Path]::DirectorySeparatorChar
    if (!$steadyStage.StartsWith($steadyWork,[StringComparison]::OrdinalIgnoreCase)) { throw 'Staging path is outside this project.' }
    $steadyMarker = "$steadyStage.prepared.json"
    if ((Test-Path -LiteralPath $steadyStage) -and !(Test-Path -LiteralPath $steadyMarker)) { throw 'Existing staging folder is not owned by this publisher.' }
    if (Test-Path -LiteralPath $steadyMarker) {
        $steadyPrevious = Get-Content -LiteralPath $steadyMarker -Raw | ConvertFrom-Json
        if (!$steadyPrevious.owned -or $steadyPrevious.version -cne $steadyVersion) { throw 'Staging marker does not match this release.' }
    }
    @{version=$steadyVersion;owned=$true;prepared=$false} | ConvertTo-Json | Set-Content -LiteralPath $steadyMarker -Encoding UTF8
    $steadyAllowed = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    [IO.Directory]::CreateDirectory($steadyStage) | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $steadySource = [IO.Compression.ZipFile]::OpenRead((Join-Path $steadyOutput "YouTube-Steady-$steadyVersion-source.zip"))
    try {
        foreach ($steadyEntry in $steadySource.Entries) {
            if (!$steadyEntry.FullName.StartsWith('YouTube-Steady/')) { throw 'Unexpected source archive root.' }
            $steadyRelative = $steadyEntry.FullName.Substring(15)
            if (!$steadyRelative) { continue }
            $steadyTarget = [IO.Path]::GetFullPath((Join-Path $steadyStage $steadyRelative))
            if (!$steadyTarget.StartsWith($steadyStage + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe archive entry.' }
            [IO.Directory]::CreateDirectory((Split-Path -Parent $steadyTarget)) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($steadyEntry,$steadyTarget,$true)
            $steadyAllowed.Add($steadyRelative.Replace('\','/')) | Out-Null
        }
    } finally { $steadySource.Dispose() }
    [IO.Directory]::CreateDirectory((Join-Path $steadyStage 'docs')) | Out-Null
    # Publish only declared assets; ignore stale files or owner-added local data.
    $steadySiteFiles = @('index.html','style.css','script.js','icon.svg','public.js','LICENSE.txt','NOTICE.txt','.nojekyll','downloads/SHA256SUMS.txt',"downloads/YouTube-Steady-$steadyVersion.zip","downloads/YouTube-Steady-$steadyVersion-source.zip")
    foreach ($steadySiteName in $steadySiteFiles) {
        $steadySiteTarget = Join-Path $steadyStage "docs/$steadySiteName"
        [IO.Directory]::CreateDirectory((Split-Path -Parent $steadySiteTarget)) | Out-Null
        Copy-Item -LiteralPath (Join-Path $steadyProject "work/public-site/$steadySiteName") -Destination $steadySiteTarget -Force
        $steadyAllowed.Add('docs/' + $steadySiteName) | Out-Null
    }
    $steadyIgnore = "work/`nnode_modules/`nbrowser-test-results.json`nyoutube-preview.png`n*.local.json`n"
    [IO.File]::WriteAllText((Join-Path $steadyStage '.gitignore'),$steadyIgnore)
    $steadyAllowed.Add('.gitignore') | Out-Null
    $steadyConfig = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'distribution.json') -Raw | ConvertFrom-Json
    if ($steadyConfig.supportUrl) {
        [IO.Directory]::CreateDirectory((Join-Path $steadyStage '.github')) | Out-Null
        [IO.File]::WriteAllText((Join-Path $steadyStage '.github/FUNDING.yml'),"custom: ['$($steadyConfig.supportUrl)']`n")
        $steadyAllowed.Add('.github/FUNDING.yml') | Out-Null
    }
    @{version=$steadyVersion;owned=$true;prepared=$true} | ConvertTo-Json | Set-Content -LiteralPath $steadyMarker -Encoding UTF8
    $steadyPublicationZip = Join-Path $steadyOutput "YouTube-Steady-$steadyVersion-publication.zip"
    $steadyStream = [IO.File]::Open($steadyPublicationZip,[IO.FileMode]::Create)
    try {
        $steadyArchive = [IO.Compression.ZipArchive]::new($steadyStream,[IO.Compression.ZipArchiveMode]::Create,$false)
        try {
            foreach ($steadyRelative in ($steadyAllowed | Sort-Object)) {
                [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($steadyArchive,(Join-Path $steadyStage $steadyRelative),$steadyRelative,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
            }
        } finally { $steadyArchive.Dispose() }
    } finally { $steadyStream.Dispose() }
    if ($PrepareOnly) { Write-Output "Prepared locally only: $steadyPublicationZip"; return }
    $steadyGit = (Get-Command git -ErrorAction Stop).Source
    $steadyStateFile = Join-Path $steadyProject 'work/github-publication-state.json'
    $steadyState = if (Test-Path -LiteralPath $steadyStateFile) { Get-Content -LiteralPath $steadyStateFile -Raw | ConvertFrom-Json } else { $null }
    if (!$steadyState) {
        Invoke-SteadyCommand $steadyGh @('repo','create',$steadyRepository,'--public','--disable-wiki','--description','Free, open-source local YouTube video stabilization. Preview release with optional one-time support.')
        $steadyState = [pscustomobject]@{repository=$steadyRepository;stage=$steadyStage;created=$true}
        $steadyState | ConvertTo-Json | Set-Content -LiteralPath $steadyStateFile -Encoding UTF8
    } elseif ($steadyState.repository -cne $steadyRepository -or $steadyState.stage -cne $steadyStage) { throw 'Existing publication state belongs to another destination. Review it before proceeding.' }
    $steadyRemoteText = & $steadyGh repo view $steadyRepository --json nameWithOwner,isPrivate,viewerPermission
    if ($LASTEXITCODE) { throw 'Could not verify the destination repository.' }
    $steadyRemote = $steadyRemoteText | ConvertFrom-Json
    if ($steadyRemote.nameWithOwner -ine $steadyRepository -or $steadyRemote.isPrivate -or $steadyRemote.viewerPermission -ne 'ADMIN') { throw 'Expected a public repository administered by the signed-in owner.' }
    Push-Location $steadyStage
    try {
        if (!(Test-Path -LiteralPath '.git')) {
            Invoke-SteadyCommand $steadyGit @('init','-b','main')
            Invoke-SteadyCommand $steadyGit @('remote','add','origin',"https://github.com/$steadyRepository.git")
        }
        $steadyOrigin = & $steadyGit remote get-url origin
        if ($LASTEXITCODE -or $steadyOrigin -cne "https://github.com/$steadyRepository.git") { throw 'The staging remote was changed; review it before publishing.' }
        Invoke-SteadyCommand $steadyGit @('config','--local','user.name',$steadyAccount.login)
        Invoke-SteadyCommand $steadyGit @('config','--local','user.email',"$($steadyAccount.id)+$($steadyAccount.login)@users.noreply.github.com")
        Invoke-SteadyCommand $steadyGit (@('add','--') + @($steadyAllowed))
        $steadyStagedPaths = & $steadyGit diff --cached --name-only
        if ($LASTEXITCODE) { throw 'Could not inspect the staged file list.' }
        foreach ($steadyStagedPath in $steadyStagedPaths) { if (!$steadyAllowed.Contains($steadyStagedPath)) { throw 'Unrelated files were staged. Review them before publishing.' } }
        & $steadyGit diff --cached --quiet
        if ($LASTEXITCODE -eq 1) { Invoke-SteadyCommand $steadyGit @('commit','-m',"Release YouTube Steady $steadyVersion preview") }
        elseif ($LASTEXITCODE -ne 0) { throw 'Could not inspect the staged changes.' }
        Invoke-SteadyCommand $steadyGit @('-c','credential.helper=','-c','credential.helper=!gh auth git-credential','push','-u','origin','main')
    } finally { Pop-Location }
    $steadyNotes = Join-Path $steadyProject 'RELEASE.txt'
    $steadyReleaseText = & $steadyGh release view "v$steadyVersion" --repo $steadyRepository --json assets,isDraft 2>$null
    if ($LASTEXITCODE -ne 0) {
        Invoke-SteadyCommand $steadyGh @('release','create',"v$steadyVersion",'--repo',$steadyRepository,'--target','main','--draft','--prerelease','--title',"YouTube Steady $steadyVersion preview",'--notes-file',$steadyNotes)
        $steadyReleaseText = & $steadyGh release view "v$steadyVersion" --repo $steadyRepository --json assets,isDraft
        if ($LASTEXITCODE) { throw 'Could not inspect the draft release.' }
    }
    $steadyRelease = $steadyReleaseText | ConvertFrom-Json
    foreach ($steadyAssetName in @("YouTube-Steady-$steadyVersion.zip","YouTube-Steady-$steadyVersion-source.zip")) {
        $steadyAssetFile = Join-Path $steadyOutput $steadyAssetName
        $steadyExistingAsset = $steadyRelease.assets | Where-Object name -eq $steadyAssetName
        if ($steadyExistingAsset) {
            if ($steadyExistingAsset.size -ne (Get-Item -LiteralPath $steadyAssetFile).Length) { throw 'An existing release asset differs. Bump the version; existing downloads are never overwritten.' }
            $steadyAssetCheck = Join-Path $steadyProject 'work/release-asset-check'
            [IO.Directory]::CreateDirectory($steadyAssetCheck) | Out-Null
            Invoke-SteadyCommand $steadyGh @('release','download',"v$steadyVersion",'--repo',$steadyRepository,'--pattern',$steadyAssetName,'--dir',$steadyAssetCheck,'--clobber')
            if ((Get-FileHash -LiteralPath (Join-Path $steadyAssetCheck $steadyAssetName) -Algorithm SHA256).Hash -cne (Get-FileHash -LiteralPath $steadyAssetFile -Algorithm SHA256).Hash) { throw 'An existing release asset has a different SHA-256. Use a new version.' }
        } else {
            if (!$steadyRelease.isDraft) { throw 'A published release is missing an asset. Inspect it before modifying it.' }
            Invoke-SteadyCommand $steadyGh @('release','upload',"v$steadyVersion",'--repo',$steadyRepository,$steadyAssetFile)
        }
    }
    if ($steadyRelease.isDraft) { Invoke-SteadyCommand $steadyGh @('release','edit',"v$steadyVersion",'--repo',$steadyRepository,'--draft=false') }
    $steadyPagesText = & $steadyGh api "repos/$steadyRepository/pages" 2>$null
    if ($LASTEXITCODE -ne 0) {
        $steadyPagesInput = Join-Path $steadyProject 'work/github-pages-request.json'
        [IO.File]::WriteAllText($steadyPagesInput,'{"source":{"branch":"main","path":"/docs"},"build_type":"legacy"}')
        Invoke-SteadyCommand $steadyGh @('api','--method','POST',"repos/$steadyRepository/pages",'--input',$steadyPagesInput)
    }
    Write-Output "Repository and preview release published: https://github.com/$steadyRepository"
    Write-Output 'Pages was requested. Verify the returned Pages URL and deployment status before reporting it live.'
} finally { Pop-Location }
