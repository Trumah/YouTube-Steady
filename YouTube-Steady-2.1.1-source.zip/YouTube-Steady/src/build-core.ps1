param(
    [string]$SdkRoot = '',
    [string]$FftwRoot = '',
    [string]$FftwBuild = ''
)
$ErrorActionPreference = 'Stop'
$steadyProject = Split-Path -Parent $PSScriptRoot
$steadyWorkspace = Split-Path -Parent (Split-Path -Parent $steadyProject)
if (!$SdkRoot) { $SdkRoot = Join-Path $steadyWorkspace 'work\tools\emsdk' }
if (!$FftwRoot) { $FftwRoot = Join-Path $steadyWorkspace 'work\sources\fftw\fftw-3.3.10' }
if (!$FftwBuild) { $FftwBuild = Join-Path $steadyWorkspace 'work\build\fftw-wasm' }
$env:EM_CONFIG = Join-Path $SdkRoot '.emscripten'
if (!$env:EMSDK_PYTHON) { $env:EMSDK_PYTHON = Join-Path $SdkRoot 'python\3.13.3_64bit\python.exe' }
$env:EMCC_TEMP_DIR = Join-Path $steadyWorkspace 'work\build\em-temp'
New-Item -ItemType Directory -Path $env:EMCC_TEMP_DIR -Force | Out-Null
$steadyCompiler = Join-Path $SdkRoot 'upstream\emscripten\em++.exe'
$steadyLibrary = Join-Path $FftwBuild 'libfftw3f.a'
if (!(Test-Path -LiteralPath $steadyLibrary)) { throw "Build FFTW single precision first: $steadyLibrary" }
$steadyExports = '["_ys_configure","_ys_input_ptr","_ys_input_capacity","_ys_result_ptr","_ys_reset","_ys_process","_ys_push_motion","_ys_set_fps"]'
& $steadyCompiler (Join-Path $PSScriptRoot 'depan_core.cpp') $steadyLibrary "-I$FftwRoot/api" `
    -std=c++17 -O3 -msimd128 -ffp-contract=off -fno-exceptions -fno-rtti `
    '-sMODULARIZE=1' '-sEXPORT_NAME=YTDePanModule' '-sENVIRONMENT=web,worker,node' `
    '-sDYNAMIC_EXECUTION=0' '-sALLOW_MEMORY_GROWTH=0' '-sINITIAL_MEMORY=134217728' `
    '-sFILESYSTEM=0' '-sASSERTIONS=0' '-sMALLOC=emmalloc' '-sSTACK_SIZE=1048576' `
    '-sEXPORTED_RUNTIME_METHODS=["HEAPU8","HEAPF32"]' `
    "-sEXPORTED_FUNCTIONS=$steadyExports" `
    -o (Join-Path $steadyProject 'extension\depan-core.js')
if ($LASTEXITCODE -ne 0) { throw "DePan WebAssembly build failed ($LASTEXITCODE)" }
Get-Item (Join-Path $steadyProject 'extension\depan-core.js'), (Join-Path $steadyProject 'extension\depan-core.wasm') | Select-Object Name, Length
