/* YouTube Steady 2: sequential, translation-only DePan core adapter.
 * Derived from DePan/DePanEstimate by A.G. Balakhnin (Fizick), 2004-2016,
 * and Ferenc Pinter's 8-16 bit/MT maintenance. GNU GPL, see LICENSE.txt.
 * Upstream commit: b41dca46d97916c9e86c7be2b7fc434349df0fd4.
 * Kept: FFTW single precision correlation, peak/trust/subpixel calculation,
 * method=0 nonlinear predictor/corrector, rolling base, and soft travel limits.
 * Removed: Avisynth/Windows interfaces, interlacing, rotation, zoom estimation,
 * future-frame border filling and file IO. No frames leave the browser.
 * Deliberate fixes: initialized trust; deterministic nonzero-dx sentinel;
 * preserve the sign of the final negative-limit safety clamp.
 */
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <deque>
#include <fftw3.h>

namespace {
struct Motion { int frame; float x, y; };
struct Result {
  float motionX, motionY, trust, mapX, mapY, valid;
  float frame, base, reason, change, deviation, reserved;
};
struct Axis { float c0=0, c1=0, c2=0, s0=0, s1=0, s2=0; };
int width=0, height=0, stride=0, count=0, estimateX=0, estimateY=0;
float trustLimit=4, stab=1, cutoff=1.25f, damping=1, limitX=128, limitY=128, fps=30;
fftwf_complex *current=nullptr, *previous=nullptr, *correlation=nullptr;
fftwf_plan forwardPlan=nullptr, inversePlan=nullptr;
alignas(16) uint8_t input[1026*1026*4];
uint8_t previousPixels[1024*1024];
bool havePrevious=false;
float previousTrust=0;
int frameIndex=-1, baseFrame=0;
std::deque<Motion> history;
Result output{};

void reset() {
  havePrevious=false; previousTrust=0; frameIndex=-1; baseFrame=0;
  history.clear(); output={};
}
void release() {
  if (forwardPlan) fftwf_destroy_plan(forwardPlan);
  if (inversePlan) fftwf_destroy_plan(inversePlan);
  if (current) fftwf_free(current);
  if (previous) fftwf_free(previous);
  if (correlation) fftwf_free(correlation);
  forwardPlan=inversePlan=nullptr; current=previous=correlation=nullptr;
}
float step(Axis &a, float motion, int relative, float frequency, float nonlin) {
  a.c2=a.c1; a.c1=a.c0; a.c0 += motion;
  a.s2=a.s1; a.s1=a.s0;
  if (relative<2) return a.s0=0;
  const float cdamp=12.56f*damping/fps, cquad=39.44f/(fps*fps);
  const float first=2*a.s1-a.s2
    -cdamp*frequency*(a.s1-a.s2-a.c1+a.c2)
      *(1+0.5f*nonlin/frequency*std::fabs(a.s1-a.s2-a.c1+a.c2))
    -cquad*frequency*frequency*(a.s1-a.c1)*(1+nonlin*std::fabs(a.s1-a.c1));
  a.s0=2*a.s1-a.s2
    -cdamp*frequency*0.5f*(first-a.s2-a.c0+a.c2)
      *(1+0.5f*nonlin/frequency*0.5f*std::fabs(first-a.s2-a.c0+a.c2))
    -cquad*frequency*frequency*(a.s1-a.c1)*(1+nonlin*std::fabs(a.s1-a.c1));
  return a.s0;
}
float softLimit(float value, float bound) {
  if (bound==0) return 0;
  if (std::fabs(value)>bound) value=std::copysign(std::sqrt(std::fabs(value)*bound),value);
  if (std::fabs(value)>bound) value=std::copysign(std::sqrt(std::fabs(value)*bound),value);
  if (std::fabs(value)>bound*1.5f) value=std::copysign(bound,value);
  return value;
}
void stabilize(float dx, float dy, bool valid) {
  ++frameIndex;
  if (!valid) baseFrame=frameIndex;
  const float framesBack=std::min(10*fps/cutoff,5*fps);
  baseFrame=std::max(baseFrame,std::max(0,int(float(frameIndex)-framesBack)));
  history.push_back({frameIndex,dx,dy});
  while (!history.empty()&&history.front().frame<baseFrame) history.pop_front();
  Axis x,y;
  const float lambda=std::sqrt(1+6*damping*damping+
    std::sqrt((1+6*damping*damping)*(1+6*damping*damping)+3));
  const float frequency=cutoff/lambda;
  for (const auto &m:history) if (m.frame>baseFrame) {
    step(x,m.x,m.frame-baseFrame,frequency,limitX?5/std::fabs(limitX):0);
    step(y,m.y,m.frame-baseFrame,frequency,limitY?5/std::fabs(limitY):0);
  }
  float mx=x.s0-x.c0,my=y.s0-y.c0;
  if (!std::isfinite(mx)||!std::isfinite(my)) {
    baseFrame=frameIndex;history.clear();history.push_back({frameIndex,0,0});
    mx=my=0;output.reason=4;
  }
  output.mapX=softLimit(mx,limitX);output.mapY=softLimit(my,limitY);
  output.frame=float(frameIndex);output.base=float(baseFrame);
}
void peak() {
  const float *surface=reinterpret_cast<float*>(correlation);
  float maximum=surface[0],mean=0; int samples=0,imax=0,jmax=0;
  auto row=[&](int j) {
    for (int i=0;i<=estimateX;i++) {
      const float v=surface[j*stride+i];mean+=v;++samples;
      if (maximum<v) {maximum=v;imax=i;jmax=j;}
    }
    for (int i=width-estimateX;i<width;i++) {
      const float v=surface[j*stride+i];mean+=v;++samples;
      if (maximum<v) {maximum=v;imax=i;jmax=j;}
    }
  };
  for (int j=0;j<=estimateY;j++) row(j);
  for (int j=height-estimateY;j<height;j++) row(j);
  mean=mean/samples/(width*height); maximum/=width*height;
  float trust=(maximum-mean)*100.0f/(maximum+0.1f);
  int dx=imax*2<width?imax:imax-width,dy=jmax*2<height?jmax:jmax-height;
  trust*=(estimateX+1)/(estimateX+1+stab*std::abs(dx))
    *(estimateY+1)/(estimateY+1+stab*std::abs(dy));
  output.trust=trust;output.valid=trust>=trustLimit;
  if (!std::isfinite(trust)) output.valid=0;
  if (!output.valid) {output.motionX=output.motionY=0;output.reason=2;return;}
  const int xp=(imax+1)%width,xm=(imax+width-1)%width;
  const int yp=(jmax+1)%height,ym=(jmax+height-1)%height;
  const float center=surface[jmax*stride+imax];
  const float fx1=(surface[jmax*stride+xp]-surface[jmax*stride+xm])/2;
  const float fx2=surface[jmax*stride+xp]+surface[jmax*stride+xm]-center*2;
  const float fy1=(surface[yp*stride+imax]-surface[ym*stride+imax])/2;
  const float fy2=surface[yp*stride+imax]+surface[ym*stride+imax]-center*2;
  float xa=fx2==0?0:std::clamp(-fx1/fx2,-1.0f,1.0f);
  float ya=fy2==0?0:std::clamp(-fy1/fy2,-1.0f,1.0f);
  if (std::fabs(dx+xa)>estimateX) xa=0;
  if (std::fabs(dy+ya)>estimateY) ya=0;
  output.motionX=dx+xa;output.motionY=dy+ya;
  // Upstream uses randomly signed .011 as its "valid zero" marker. A separate
  // flag removes that ambiguity here; deterministic +.011 preserves semantics.
  if (std::fabs(output.motionX)<0.01f) output.motionX=0.011f;
  if (trust<trustLimit*2&&trust<0.5f*previousTrust) {
    output.valid=0;output.motionX=output.motionY=0;output.reason=3;
  }
}
}

extern "C" {
uint8_t *ys_input_ptr() {return input;}
Result *ys_result_ptr() {return &output;}
int ys_input_capacity() {return sizeof(input);}
void ys_reset() {reset();}
int ys_configure(int w,int h,int ex,int ey,float trust,float penalty,
                 float frequency,float damp,float maxX,float maxY,float rate) {
  if (w<32||h<32||w>1024||h>1024||w%2||h%2||ex<0||ey<0||
      ex>=w/2||ey>=h/2||!std::isfinite(trust)||trust<0.1f||trust>100||
      !std::isfinite(penalty)||penalty<0||penalty>10||
      !std::isfinite(frequency)||frequency<0.2f||frequency>5||
      !std::isfinite(damp)||damp<0.25f||damp>3||
      !std::isfinite(maxX)||maxX<0||maxX>1024||
      !std::isfinite(maxY)||maxY<0||maxY>1024||
      !std::isfinite(rate)||rate<5||rate>240) return -1;
  if (w!=width||h!=height||!forwardPlan||!inversePlan) {
    release();width=w;height=h;stride=(w/2+1)*2;count=h*(w/2+1);
    current=fftwf_alloc_complex(count);previous=fftwf_alloc_complex(count);
    correlation=fftwf_alloc_complex(count);
    if (!current||!previous||!correlation) {release();return -2;}
    forwardPlan=fftwf_plan_dft_r2c_2d(h,w,reinterpret_cast<float*>(current),current,FFTW_ESTIMATE);
    inversePlan=fftwf_plan_dft_c2r_2d(h,w,correlation,reinterpret_cast<float*>(correlation),FFTW_ESTIMATE);
    if (!forwardPlan||!inversePlan) {release();return -3;}
  }
  estimateX=ex;estimateY=ey;trustLimit=trust;stab=penalty;
  cutoff=frequency;damping=damp;limitX=maxX;limitY=maxY;fps=rate;
  reset();return 0;
}
int ys_set_fps(float rate) {
  if (!std::isfinite(rate)||rate<5||rate>240) return -1;
  fps=rate;return 0;
}
Result *ys_process() {
  output={};
  if (!forwardPlan||!inversePlan) {output.reason=-1;return &output;}
  float *real=reinterpret_cast<float*>(current);
  double sum=0,sq=0,diff=0;int samples=0;
  for(int y=0;y<height;y++) for(int x=0;x<width;x++) {
    const int p=y*width+x;real[y*stride+x]=input[p];
    if (y%8==0&&x%8==0) {const float v=input[p];sum+=v;sq+=v*v;
      if(havePrevious)diff+=std::abs(int(input[p])-int(previousPixels[p]));++samples;}
    previousPixels[p]=input[p];
  }
  output.change=float(diff/std::max(1,samples));
  output.deviation=float(std::sqrt(std::max(0.0,sq/std::max(1,samples)-std::pow(sum/std::max(1,samples),2))));
  fftwf_execute_dft_r2c(forwardPlan,real,current);
  if (!havePrevious) {
    havePrevious=true;output.reason=1;stabilize(0,0,false);
  } else {
    for (int k=0;k<count;k++) {
      correlation[k][0]=current[k][0]*previous[k][0]+current[k][1]*previous[k][1];
      correlation[k][1]=current[k][0]*previous[k][1]-current[k][1]*previous[k][0];
    }
    fftwf_execute_dft_c2r(inversePlan,correlation,reinterpret_cast<float*>(correlation));
    peak();previousTrust=output.trust;
    stabilize(output.motionX,output.motionY,output.valid!=0);
  }
  std::swap(current,previous);return &output;
}
Result *ys_push_motion(float dx,float dy,int valid) {
  output={};output.motionX=dx;output.motionY=dy;output.valid=valid;
  stabilize(dx,dy,valid&&std::isfinite(dx)&&std::isfinite(dy));return &output;
}
}
