"use strict";
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),out=path.join(root,'work/public-site'),config=require('../extension/support.js');
const files=['index.html','style.css','script.js','icon.svg'];fs.mkdirSync(path.join(out,'downloads'),{recursive:true});
for(const name of files)fs.copyFileSync(path.join(root,'site',name),path.join(out,name));
fs.copyFileSync(path.join(root,'extension/support.js'),path.join(out,'public.js'));
for(const name of ['LICENSE.txt','NOTICE.txt'])fs.copyFileSync(path.join(root,name),path.join(out,name));
const sums=[];
for(const suffix of ['', '-source']){
  const name=`YouTube-Steady-${config.version}${suffix}.zip`,from=path.join(root,'..',name);
  if(!fs.existsSync(from))throw Error('Package the release first: '+name);
  fs.copyFileSync(from,path.join(out,'downloads',name));sums.push(crypto.createHash('sha256').update(fs.readFileSync(from)).digest('hex')+'  '+name);
}
fs.writeFileSync(path.join(out,'downloads/SHA256SUMS.txt'),sums.join('\n')+'\n');
let html=fs.readFileSync(path.join(out,'index.html'),'utf8').replace('id="download"','id="download" href="downloads/YouTube-Steady-'+config.version+'.zip"').replace('id="source"','id="source" href="downloads/YouTube-Steady-'+config.version+'-source.zip"').replace('<span id="version"></span>','<span id="version">v'+config.version+'</span>');
fs.writeFileSync(path.join(out,'index.html'),html);fs.writeFileSync(path.join(out,'.nojekyll'),'');
console.log('Static public-site bundle ready: '+out);
