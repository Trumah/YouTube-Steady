"use strict";
const test=require("node:test"),assert=require("node:assert/strict");
const S=require("../extension/settings.js");
test("MPC defaults and migration preserve user zoom and enable choice",()=>{
  assert.deepEqual(S.normalize(null),S.defaults);
  const migrated=S.normalize({enabled:false,zoom:1.12,smoothness:.96,garbage:"ignored"});
  assert.equal(migrated.enabled,false);assert.equal(migrated.zoom,1.12);
  assert.equal(migrated.cutoff,1.25);assert.equal(migrated.damping,1);
  assert.equal(migrated.winx,512);assert.equal(migrated.estimateDx,192);
  assert.equal(migrated.subpixel,1);assert.equal(migrated.schema,3);assert.equal(migrated.language,"auto");
  assert.ok(!("smoothness" in migrated)&&!("garbage" in migrated));
});
test("invalid stored values cannot reach the native core",()=>{
  const s=S.normalize({zoom:NaN,cutoff:Infinity,damping:-10,dxmax:1e9,dymax:-1,trust:"4",winx:513,winy:1,estimateDx:1e8,subpixel:9});
  assert.equal(s.zoom,1.06);assert.equal(s.cutoff,1.25);assert.equal(s.damping,.25);
  assert.equal(s.dxmax,512);assert.equal(s.dymax,0);assert.equal(s.trust,4);
  assert.equal(s.winx,512);assert.equal(s.winy,64);assert.equal(s.estimateDx,511);assert.equal(s.subpixel,1);
});
test("native source ROI stays centered, even and within Fourier search limits",()=>{
  const s=S.normalize({winx:1024,winy:1024,estimateDx:511,estimateDy:511});
  const a=S.effective(s,853,479);
  assert.deepEqual(a,{winx:852,winy:478,estimateDx:425,estimateDy:238,left:0,top:0});
  const b=S.effective(S.defaults,1920,1080);
  assert.deepEqual(b,{winx:512,winy:512,estimateDx:192,estimateDy:192,left:704,top:284});
  assert.throws(()=>S.effective(s,16,9),/source-dimensions-too-small/);
});
test("language migration keeps every existing stabilization parameter",()=>{
  const old={schema:2,enabled:false,zoom:1.12,cutoff:.7,damping:1.2,dxmax:96,dymax:64,winx:256,winy:256,estimateDx:127,estimateDy:96,trust:6,stab:1.2,subpixel:0};
  const migrated=S.normalize({...old,language:"ar"});
  for(const name of ["enabled",...Object.keys(S.fields)])assert.equal(migrated[name],old[name],name);
  assert.equal(migrated.language,"ar");assert.equal(migrated.schema,3);
  assert.equal(S.normalize({...old,language:"unsupported"}).language,"auto");
});
