/* Local preview adapter only; never included in the installable extension. */
(function(){
  const listeners=[],key="ytSteadySettings";
  globalThis.chrome={storage:{local:{
    async get(name){return {[name]:JSON.parse(localStorage.getItem(name)||"null")};},
    async set(values){for(const [name,value]of Object.entries(values)){const oldValue=JSON.parse(localStorage.getItem(name)||"null");localStorage.setItem(name,JSON.stringify(value));for(const listener of listeners)listener({[name]:{oldValue,newValue:value}},"local");}}
  },onChanged:{addListener(fn){listeners.push(fn);}}},tabs:{async query(){return [{id:1}];},async sendMessage(){return {found:false};}}};
  window.addEventListener("storage",event=>{if(event.key===key)for(const listener of listeners)listener({[key]:{newValue:JSON.parse(event.newValue||"null")}},"local");});
})();
