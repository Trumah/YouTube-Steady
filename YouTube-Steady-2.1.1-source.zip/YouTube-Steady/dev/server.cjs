"use strict";
const http = require("node:http"), fs = require("node:fs"), path = require("node:path");
const root = path.resolve(__dirname, ".."), port = Number(process.env.PORT||8770);
// Optional fixed runtime/page roots allow comparing a prior release without
// changing the installed extension or exposing arbitrary filesystem paths.
const runtimeRoot=process.env.STEADY_RUNTIME_ROOT?path.resolve(process.env.STEADY_RUNTIME_ROOT):path.join(root,"extension");
const fixture = path.join(__dirname, "fixture-v2.webm");
const types = {".html":"text/html; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".css":"text/css; charset=utf-8", ".webm":"video/webm", ".json":"application/json; charset=utf-8", ".wasm":"application/wasm"};
const server = http.createServer(async (req, res) => {
  try {
    const pathname = new URL(req.url, "http://127.0.0.1").pathname;
    if (req.method === "POST" && pathname === "/fixture-v2.webm" && req.headers.origin === `http://127.0.0.1:${port}` && req.headers["content-type"] === "video/webm") {
      const chunks = []; let length = 0;
      for await (const chunk of req) { length += chunk.length; if (length > 32 * 1024 * 1024) { res.writeHead(413); res.end(); return; } chunks.push(chunk); }
      fs.writeFileSync(fixture, Buffer.concat(chunks)); res.writeHead(201); res.end("synthetic fixture saved"); return;
    }
    if (req.method !== "GET" && req.method !== "HEAD") { res.writeHead(405); res.end(); return; }
    const routes = {"/":"dev/v2.html", "/v2-harness.js":"dev/v2-harness.js", "/depan-core.js":"extension/depan-core.js", "/depan-core.wasm":"extension/depan-core.wasm", "/locales.js":"extension/locales.js", "/i18n.js":"extension/i18n.js", "/ui.js":"extension/ui.js", "/settings.js":"extension/settings.js", "/support.js":"extension/support.js", "/renderer.js":"extension/renderer.js", "/controller.js":"extension/controller.js", "/fixture-v2.webm":"dev/fixture-v2.webm", "/i18n-harness.js":"dev/i18n-harness.js", "/popup-preview":"dev/popup-preview.html", "/popup-test-api.js":"dev/popup-test-api.js", "/popup.js":"extension/popup.js", "/support-test":"dev/support-test.html", "/support-harness.js":"dev/support-harness.js"};
    const rel = routes[pathname];
    if (!rel) { res.writeHead(404); res.end(); return; }
    const file = pathname==="/"&&process.env.STEADY_TEST_PAGE?path.resolve(process.env.STEADY_TEST_PAGE):rel.startsWith("extension/")?path.join(runtimeRoot,rel.slice(10)):path.join(root,rel), stat = fs.statSync(file);
    let start = 0, end = stat.size - 1, status = 200;
    if (req.headers.range) {
      const match = /^bytes=(\d+)-(\d*)$/.exec(req.headers.range);
      if (!match) { res.writeHead(416); res.end(); return; }
      start = Number(match[1]); end = match[2] ? Math.min(end, Number(match[2])) : end; status = 206;
      if (start > end || start >= stat.size) { res.writeHead(416, {"Content-Range":`bytes */${stat.size}`}); res.end(); return; }
    }
    const headers = {"Content-Type":types[path.extname(file)] || "application/octet-stream", "Content-Length":end - start + 1, "Accept-Ranges":"bytes", "Cache-Control":"no-store", "X-Content-Type-Options":"nosniff"};
    if(path.extname(file)===".html")headers["Content-Security-Policy"]=`default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src 'self' blob: http://localhost:${port}; connect-src 'self'; img-src 'self' data:; object-src 'none'`;
    if (status === 206) headers["Content-Range"] = `bytes ${start}-${end}/${stat.size}`;
    res.writeHead(status, headers); if (req.method === "HEAD") res.end(); else fs.createReadStream(file, {start, end}).pipe(res);
  } catch { res.writeHead(404); res.end("not found"); }
});
server.listen(port, "127.0.0.1", () => process.stdout.write(`YouTube Steady test server: http://127.0.0.1:${port}\n`));
server.on("error", error => { process.stderr.write(error.message + "\n"); process.exitCode = 1; });
