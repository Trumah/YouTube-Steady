/* YouTube Steady 2.1.1. GPL-2.0. See LICENSE.txt and NOTICE.txt.
 * One captured VideoFrame is analyzed and drawn as one completed output frame.
 * No per-frame CSS translation, extra decoder, audio output or remote service.
 */
(function(){
  "use strict";
  if(globalThis.__ytSteadyV2Loaded||!globalThis.YTSteadyPipeline||!globalThis.YTSteadySettings||!globalThis.YTSteadyPlayerUI)return;
  globalThis.__ytSteadyV2Loaded=true;
  const S=YTSteadySettings,P=YTSteadyPipeline,I=YTSteadyI18n,version="2.1.1",key="ytSteadySettings";
  const extension=!!globalThis.chrome?.runtime?.id;
  const testPage=!extension&&location.hostname==="127.0.0.1"&&!!document.querySelector("[data-ytsteady-test-player]");
  if(!extension&&!testPage)return;
  const asset=name=>extension?chrome.runtime.getURL(name):new URL("/"+name,location.href).href;
  let settings={...S.defaults},controller=null,reconcileTimer=0;
  const median=a=>{const b=a.slice().sort((x,y)=>x-y),n=b.length;return n%2?b[n>>1]:(b[n/2-1]+b[n/2])/2;};
  function changeSettings(value,forcePlayback=false){
    const next=S.normalize(value),languageChanged=next.language!==settings.language;
    const playbackChanged=forcePlayback||next.enabled!==settings.enabled||Object.keys(S.fields).some(name=>next[name]!==settings[name]);
    const previousLocale=I.code;settings=next;I.setLanguage(settings.language);
    if(!controller)return;
    if(languageChanged||previousLocale!==I.code)controller.applyLocale();
    if(playbackChanged)controller.applySettings();
    else{controller.refreshEntry();controller.updateStatus();controller.publish();}
  }
  async function save(patch,forcePlayback=false){
    changeSettings({...settings,...patch},forcePlayback);
    try{
      if(extension)await chrome.storage.local.set({[key]:settings});else localStorage.setItem(key,JSON.stringify(settings));
      if(controller){controller.saveFailed=false;controller.updateStatus();}
    }catch{if(controller){controller.saveFailed=true;controller.updateStatus();controller.publish();}}
  }
  class Player{
    constructor(player,video){
      this.player=player;this.video=video;this.core=null;this.loading=false;this.renderer=null;this.reader=new P.LumaReader();
      this.dead=false;this.error=false;this.ad=false;this.generation=0;this.callback=null;this.job=null;this.stillWanted=false;
      this.events=[];this.samples=[];this.drawTimes=[];this.deltas=[];this.slowFrames=[];
      this.outputFrames=0;this.invalid=0;this.resets=0;this.callbackMisses=0;this.lastPresented=null;
      this.mediaFps=30;this.lastTime=null;this.source=video.currentSrc;this.lastMotion=null;this.area=null;this.reason="loading";
      this.qualityBase=video.getVideoPlaybackQuality?.();this.lastStatus="";this.statusKey="";this.dirty=false;this.saveFailed=false;this.errorCode="";this.errorDetail="";
      this.createUI();
      for(const name of ["seeking","seeked","loadedmetadata","emptied","ratechange","ended"])this.listen(video,name,()=>{
        if(name==="loadedmetadata"||name==="emptied"){
          this.source=video.currentSrc;this.error=false;this.errorCode=this.errorDetail="";this.reader.reset();this.samples=[];this.drawTimes=[];
          this.outputFrames=this.invalid=this.callbackMisses=0;this.qualityBase=video.getVideoPlaybackQuality?.();
        }
        this.reset(name);if(name!=="seeking"&&name!=="emptied"&&name!=="ended")this.startOrStill();
      });
      this.listen(video,"play",()=>{this.drawTimes=[];this.startOrStill();});
      this.listen(video,"loadeddata",()=>this.startOrStill());this.listen(video,"canplay",()=>this.startOrStill());
      this.listen(video,"pause",()=>{this.cancel();this.updateStatus();this.publish();});
      this.listen(document,"visibilitychange",()=>{this.reset("visibility");if(!document.hidden)this.startOrStill();});
      this.listen(document,"fullscreenchange",()=>this.layout());
      this.listen(document,"enterpictureinpicture",()=>this.updateStatus());
      this.resize=new ResizeObserver(()=>this.layout());this.resize.observe(video);this.resize.observe(player);
      this.timer=setInterval(()=>this.tick(),1000);this.applySettings();
    }
    listen(target,name,fn){target.addEventListener(name,fn);this.events.push([target,name,fn]);}
    createUI(){
      this.view=new YTSteadyPlayerUI(this.player,{settings:()=>settings,save,
        draft:()=>{this.dirty=true;this.setStatus("statusPending");}});
      this.host=this.view.host;this.ui=this.view.elements;this.refreshEntry();
    }
    refreshFields(){this.view.refreshFields(settings);this.dirty=false;this.refreshEntry();}
    refreshEntry(){this.view.refreshEntry(settings,this.error);}
    togglePanel(force){this.view.togglePanel(force);this.layout();}
    layout(){this.view.layout();this.renderer?.sync(settings.zoom);}
    applyLocale(){
      this.view.translate();this.refreshEntry();this.updateStatus();this.view.setEffective(this.area);this.publish();
    }
    setStatus(key,args={}){
      this.statusKey=key;const text=I.t(key,args);
      if(text!==this.lastStatus){this.lastStatus=text;this.ui.status.textContent=text;}
    }
    updateStatus(){
      if(this.error){this.setStatus(this.errorCode||"errorProcessing");return;}
      if(this.dirty){this.setStatus("statusPending");return;}
      if(this.saveFailed){this.setStatus("statusSaveFailed");return;}
      this.setStatus(!settings.enabled?"statusOff":this.loading?"statusLoading":this.ad?"statusAd":
        this.video.seeking?"statusSeeking":this.video.paused&&this.renderer?.active?"statusPaused":
        this.renderer?.active?"statusActive":"statusWaiting");
    }
    async ensureCore(){
      if(this.core||this.loading||this.dead||!settings.enabled)return;
      if(typeof VideoFrame!=="function"||typeof this.video.requestVideoFrameCallback!=="function"){
        this.halt("errorUnsupported");return;
      }
      this.loading=true;this.updateStatus();
      try{this.core=await P.createCore(asset);if(this.dead)return;this.reason="ready";}
      catch(error){if(!this.dead)this.halt("errorCore",error.name+": "+error.message);}
      finally{this.loading=false;if(!this.dead){this.updateStatus();this.startOrStill();}}
    }
    applySettings(){
      if(this.error&&this.renderer){this.renderer.destroy();this.renderer=null;}
      this.error=false;this.errorCode=this.errorDetail="";this.refreshFields();this.reader.reset();this.reset("settings");
      this.ensureCore();this.startOrStill();this.updateStatus();this.publish();
    }
    cancel(){if(this.callback!==null){this.video.cancelVideoFrameCallback(this.callback);this.callback=null;}}
    reset(reason){
      this.generation++;this.cancel();this.core?.invalidate();this.renderer?.hide();this.lastTime=null;
      this.deltas=[];this.drawTimes=[];this.lastPresented=null;this.slowFrames=[];this.reason=reason;this.resets++;
    }
    halt(code,detail=""){
      this.error=true;this.errorCode=code;this.errorDetail=detail;this.reason="bypass";this.generation++;this.cancel();this.renderer?.hide();this.refreshEntry();this.setStatus(code);this.publish();
    }
    startOrStill(){
      if(this.dead||this.error||!settings.enabled||document.hidden||this.video.seeking)return;
      if(!this.core){this.ensureCore();return;}
      if(this.video.paused){this.stillWanted=true;if(!this.job)this.submit(performance.now(),{mediaTime:this.video.currentTime},true);return;}
      if(this.callback!==null||this.video.ended)return;
      this.callback=this.video.requestVideoFrameCallback((now,meta)=>{
        this.callback=null;
        // Subscribe before the asynchronous GPU readback. Registering only
        // after processing can miss the compositor's next callback deadline
        // even when the job itself takes less than one source-frame interval.
        // submit still permits only one in-flight job; busy frames are skipped.
        this.startOrStill();this.submit(now,meta,false);
      });
    }
    fps(time){
      if(this.lastTime!==null){const delta=time-this.lastTime;if(delta>1/250&&delta<.25){this.deltas.push(delta);if(this.deltas.length>12)this.deltas.shift();}}
      if(this.deltas.length){
        let rate=1/median(this.deltas),common=[12,15,16,18,20,23.976,24,25,29.97,30,48,50,59.94,60,90,120];
        const nearest=common.reduce((a,b)=>Math.abs(b-rate)<Math.abs(a-rate)?b:a);
        if(Math.abs(nearest-rate)/rate<.025)rate=nearest;this.mediaFps=Math.max(5,Math.min(240,rate));
      }
      this.lastTime=time;return this.mediaFps;
    }
    submit(now,meta,still){
      if(this.job||this.dead||this.error||!settings.enabled||document.hidden||this.video.readyState<2||this.video.seeking)return;
      this.stillWanted=false;
      const ad=this.player.classList.contains("ad-showing")||this.player.classList.contains("ad-interrupting");
      if(ad!==this.ad){this.ad=ad;this.reset("ad");this.updateStatus();}
      if(ad){if(!still)this.startOrStill();return;}
      if(this.source!==this.video.currentSrc){this.source=this.video.currentSrc;this.reset("source");this.reader.reset();}
      if(this.lastTime!==null&&(meta.mediaTime<this.lastTime-.001||meta.mediaTime-this.lastTime>.25))this.reset("time-gap");
      const generation=this.generation,profile={...settings};let frame;
      try{frame=new VideoFrame(this.video,{timestamp:Math.round(meta.mediaTime*1000000)});}
      catch(error){
        // During source/seek transitions readyState can precede an actually
        // capturable image. Wait for loadeddata/canplay or the next real RVFC;
        // do not turn a temporary decoder state into a persistent bypass.
        if(error.name==="InvalidStateError"){
          this.reason="waiting-for-frame";this.renderer?.hide();this.updateStatus();this.publish();
          if(!still)this.startOrStill();return;
        }
        this.halt(error.name==="SecurityError"?"errorRestricted":"errorCapture",error.name+": "+error.message);return;
      }
      this.job=P.exclusive(async()=>{
        if(this.dead||generation!==this.generation||this.error||!settings.enabled)return;
        const begin=performance.now(),area=S.effective(profile,frame.visibleRect.width,frame.visibleRect.height);
        const rate=this.fps(meta.mediaTime);this.core.activate(profile,area,rate);
        const copyBegin=performance.now();await this.reader.read(frame,area,this.core);
        if(this.dead||generation!==this.generation||this.error||!settings.enabled)return;
        const computeBegin=performance.now(),motion=this.core.process(),drawBegin=performance.now();
        if(!this.renderer){
          this.renderer=new P.Renderer(this.video,this.player);
          this.renderer.canvas.addEventListener("contextlost",()=>this.halt("errorCanvas"));
        }
        this.renderer.draw(frame,motion,profile,meta.mediaTime);
        const end=performance.now();this.outputFrames++;if(!motion.valid&&motion.reason!==1)this.invalid++;
        if(this.lastPresented!==null&&meta.presentedFrames>this.lastPresented+1)this.callbackMisses+=meta.presentedFrames-this.lastPresented-1;
        if(Number.isFinite(meta.presentedFrames))this.lastPresented=meta.presentedFrames;
        this.drawTimes.push(end);this.samples.push({total:end-begin,copy:computeBegin-copyBegin,compute:drawBegin-computeBegin,draw:end-drawBegin,delay:end-now});
        if(this.samples.length>360)this.samples.shift();
        this.area=area;this.lastMotion=motion;this.reason=motion.reason===1?"reference":motion.valid?"matched":"scene-or-low-trust";
        this.view.setEffective(area);
        const budget=1000/(rate*this.video.playbackRate);
        this.slowFrames.push(end-begin>budget*1.3);if(this.slowFrames.length>60)this.slowFrames.shift();
        if(this.slowFrames.length===60&&this.slowFrames.filter(Boolean).length>40){
          this.halt("errorOverload");return;
        }
        this.updateStatus();
      }).catch(error=>{
        if(!this.dead&&generation===this.generation)this.halt(error.name==="SecurityError"?"errorRestricted":"errorProcessing",error.name+": "+error.message);
      }).finally(()=>{
        frame.close();this.job=null;
        if(this.dead)return;
        if(this.stillWanted&&this.video.paused)this.startOrStill();else if(!this.video.paused)this.startOrStill();
        if(this.video.paused||this.outputFrames===1)this.publish();
      });
    }
    tick(){
      if(this.dead)return;
      if(this.source!==this.video.currentSrc){this.source=this.video.currentSrc;this.error=false;this.errorCode=this.errorDetail="";this.reset("source-recovery");this.reader.reset();this.startOrStill();}
      this.updateStatus();this.publish();
    }
    publish(){
      const now=performance.now();this.drawTimes=this.drawTimes.filter(t=>t>now-5000);
      const outputFps=this.drawTimes.length<2?0:(this.drawTimes.length-1)*1000/Math.max(1,this.drawTimes.at(-1)-this.drawTimes[0]);
      const mean=key=>this.samples.reduce((n,s)=>n+s[key],0)/Math.max(1,this.samples.length),sorted=this.samples.map(s=>s.total).sort((a,b)=>a-b);
      const quality=this.video.getVideoPlaybackQuality?.();
      const state={version,scheduler:"early-subscribe",...settings,locale:I.code,direction:I.dir,statusKey:this.statusKey,errorDetail:this.errorDetail,active:!!this.renderer?.active,error:this.error,reason:this.reason,outputFrames:this.outputFrames,
        outputFps:+outputFps.toFixed(1),mediaFps:+this.mediaFps.toFixed(3),meanMs:+mean("total").toFixed(2),p95Ms:+(sorted[Math.floor(sorted.length*.95)]||0).toFixed(2),
        copyMs:+mean("copy").toFixed(2),computeMs:+mean("compute").toFixed(2),drawMs:+mean("draw").toFixed(2),delayMs:+mean("delay").toFixed(2),
        invalidMatches:this.invalid,callbackMisses:this.callbackMisses,resets:this.resets,pixelFormat:this.reader.format,area:this.area,
        mapX:this.lastMotion?.mapX||0,mapY:this.lastMotion?.mapY||0,trustValue:this.lastMotion?.trust||0,mediaTime:this.lastTime||0,
        paused:this.video.paused,status:this.lastStatus,total:Math.max(0,(quality?.totalVideoFrames||0)-(this.qualityBase?.totalVideoFrames||0)),
        dropped:Math.max(0,(quality?.droppedVideoFrames||0)-(this.qualityBase?.droppedVideoFrames||0))};
      this.host.dataset.state=JSON.stringify(state);
      this.view.publish(state);
    }
    destroy(){
      this.dead=true;this.generation++;this.cancel();clearInterval(this.timer);this.resize.disconnect();
      for(const [target,name,fn]of this.events)target.removeEventListener(name,fn);
      this.renderer?.destroy();this.host.remove();
    }
  }
  function reconcile(){
    reconcileTimer=0;
    const allowed=testPage||(location.pathname==="/watch"&&new URLSearchParams(location.search).has("v"));
    const player=allowed?document.querySelector(testPage?"[data-ytsteady-test-player]":"#movie_player"):null;
    const video=player?.querySelector("video.html5-main-video,video");
    if(controller&&(controller.video!==video||controller.player!==player||!video?.isConnected)){controller.destroy();controller=null;}
    if(!controller&&player&&video)controller=new Player(player,video);
  }
  function queueReconcile(){if(!reconcileTimer)reconcileTimer=setTimeout(reconcile,150);}
  new MutationObserver(queueReconcile).observe(document.documentElement,{childList:true,subtree:true});
  for(const name of ["yt-navigate-finish","yt-page-data-updated","popstate"])document.addEventListener(name,queueReconcile);
  if(extension){
    chrome.storage.onChanged.addListener((changes,area)=>{
      if(area==="local"&&changes[key]){const next=S.normalize(changes[key].newValue);if(JSON.stringify(next)!==JSON.stringify(settings))changeSettings(next);}
    });
    chrome.runtime.onMessage.addListener((message,sender,reply)=>{if(message?.type==="yt-steady-panel"){controller?.togglePanel(true);reply({found:!!controller,version});}});
  }else window.addEventListener("storage",event=>{if(event.key===key){try{changeSettings(JSON.parse(event.newValue));}catch{}}});
  window.addEventListener("languagechange",()=>{if(settings.language==="auto"){I.setLanguage("auto");controller?.applyLocale();}});
  (async()=>{
    try{settings=S.normalize(extension?(await chrome.storage.local.get(key))[key]:JSON.parse(localStorage.getItem(key)||"null"));}
    catch{settings={...S.defaults};}I.setLanguage(settings.language);reconcile();
  })();
})();
