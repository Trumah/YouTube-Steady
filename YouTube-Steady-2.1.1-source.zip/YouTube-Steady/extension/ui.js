/* Accessible, direction-aware player UI. Playback and motion state are owned
 * by controller.js; changing language only updates this view. GPL-2.0-or-later. */
(function(root){
  "use strict";
  const I=root.YTSteadyI18n,S=root.YTSteadySettings;
  const keys={zoom:"",cutoff:"cutoff",damping:"damping",dxmax:"dxmax",dymax:"dymax",winx:"winx",winy:"winy",estimateDx:"estimate.dxmax",estimateDy:"estimate.dymax",trust:"trust",stab:"stab"};
  class PlayerUI{
    constructor(player,actions){
      this.player=player;this.actions=actions;this.errors=new Map();this.effectiveSignature="";this.host=document.createElement("div");this.host.id="yt-steady-controls";
      this.host.style.cssText="position:absolute;inset-inline-end:12px;inset-block-end:58px;z-index:65;pointer-events:none;";
      this.shadow=this.host.attachShadow({mode:"open"});
      const input=id=>`<label class="row"><span class="label"><span data-i18n="${id}"></span>${keys[id]?`<small class="key"><bdi dir="ltr">${keys[id]}</bdi></small>`:""}</span><input id="${id}" type="text" inputmode="${S.fields[id].step<1?"decimal":"numeric"}" role="spinbutton" aria-valuemin="${S.fields[id].min}" aria-valuemax="${S.fields[id].max}" dir="ltr" required autocomplete="off" spellcheck="false"></label>`;
      this.shadow.innerHTML=`<style>
        :host{font:14px/1.5 system-ui,-apple-system,'Segoe UI','Noto Sans','Microsoft JhengHei',sans-serif;color:#edf3ff;color-scheme:dark}*{box-sizing:border-box}#support{border-block-start:1px solid #3d506a;margin-block-start:12px;padding-block-start:9px}#support a{color:#b6d9ff;text-underline-offset:3px}#support a:focus-visible{outline:2px solid #a7d1ff;outline-offset:3px}
        button,input,select{font:inherit}button{cursor:pointer;border:1px solid #7489a4;border-radius:6px;background:#27364b;color:#fff;padding:7px 10px;line-height:1.35}button:hover{background:#3b5273}
        button:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:2px solid #a7d1ff;outline-offset:2px}
        [hidden]{display:none!important}#entry{pointer-events:auto;display:block;margin-inline-start:auto;background:#17253bed;font-size:13px;padding:5px 10px;max-inline-size:100%;overflow-wrap:anywhere}
        #entry[aria-pressed=true]{border-color:#9bc6ff}#panel{pointer-events:auto;overflow:auto;overscroll-behavior:contain;scroll-padding-block:64px;background:#111d2df5;border:1px solid #6f87a7;border-radius:10px;inline-size:384px;padding:14px;box-shadow:0 8px 28px #0009;margin-block-end:8px}
        .head,.row,.footer{display:flex;align-items:center;justify-content:space-between;gap:10px}.head{position:sticky;inset-block-start:-14px;z-index:2;background:#111d2d;padding-block:3px 9px;margin-block-end:10px;font-weight:650}.head small{display:block;font-size:11px;color:#adbed5;font-weight:400}.head button{border:0;background:transparent;font-size:23px;padding:0 5px;align-self:flex-start}
        .row{margin-block:11px}.label{flex:1;min-inline-size:0;font-size:13px;overflow-wrap:anywhere}.key{display:block;font:11px/1.4 ui-monospace,Consolas,monospace;color:#acbfd8}input[role=spinbutton],select{min-inline-size:0;inline-size:96px;border:1px solid #7489a4;border-radius:5px;background:#233349;color:#fff;padding:6px;scroll-margin-block:64px}input[role=spinbutton]{flex:0 0 96px;text-align:end;font-variant-numeric:tabular-nums}
        input[aria-invalid=true]{border-color:#ffb29f}input[type=checkbox]{inline-size:18px;block-size:18px;accent-color:#9bc6ff;vertical-align:middle;margin-inline:0 7px}.language{display:block}.language>span{display:block;margin-block-end:5px}.language select{inline-size:100%}
        .hint{font-size:12px;color:#b9c8dd;margin-block:5px 12px;overflow-wrap:anywhere}.footer{position:sticky;inset-block-end:-14px;z-index:1;background:#111d2d;padding-block:11px 3px;margin-block-start:10px;border-block-start:1px solid #3d506a;align-items:stretch}.footer button{flex:1;min-inline-size:0;font-size:13px;white-space:normal;overflow-wrap:anywhere}#apply{background:#285e9c}
        details{border-block-start:1px solid #3d506a;margin-block-start:12px;padding-block-start:9px}summary{cursor:pointer;font-size:13px;color:#d1e2fc;overflow-wrap:anywhere}#effective,#status,#perf{font-size:12px;color:#c8dfff;overflow-wrap:anywhere}#effective{margin-block-start:9px}#status{margin-block-start:11px;min-block-size:18px}#perf{white-space:pre-line;margin-block-start:8px;font-variant-numeric:tabular-nums}#subpixel{max-inline-size:48%;inline-size:150px}
      </style><section id="panel" role="dialog" aria-labelledby="panelTitle" hidden><form id="form" novalidate>
        <div class="head"><span><span id="panelTitle" data-i18n="panelTitle"></span><small><bdi dir="ltr">YouTube Steady · 2.1.1</bdi></small></span><button type="button" id="close" data-i18n-aria="close">×</button></div>
        <label class="language"><span data-i18n="language"></span><select id="language" aria-describedby="languageHint"></select></label><p id="languageHint" class="hint"></p>
        <label><input id="enabled" type="checkbox"><span data-i18n="enabled"></span></label>
        ${input("zoom")}<p id="zoomHint" class="hint"></p>
        ${input("cutoff")}<p class="hint" data-i18n="cutoffHint"></p>
        ${input("damping")}<p id="dampingHint" class="hint"></p>
        <details id="advanced"><summary data-i18n="advanced"></summary><p class="hint" data-i18n="sourcePixelsHint"></p>
          ${input("dxmax")}${input("dymax")}<p class="hint" data-i18n="softLimitHint"></p>
          ${input("winx")}${input("winy")}${input("estimateDx")}${input("estimateDy")}${input("trust")}<p class="hint" data-i18n="trustHint"></p>${input("stab")}
          <label class="row"><span class="label"><span data-i18n="subpixel"></span><small class="key"><bdi dir="ltr">subpixel</bdi></small></span><select id="subpixel"><option value="1" data-i18n="bilinear"></option><option value="0" data-i18n="nearest"></option></select></label>
          <div id="effective"></div><p class="hint" data-i18n="scopeHint"></p>
        </details>
        <div id="status" role="status" aria-live="polite"></div><details id="performance"><summary data-i18n="performance"></summary><div id="perf" aria-live="off"></div></details>
        <div id="support" hidden><a id="supportLink" target="_blank" rel="noopener noreferrer" data-i18n="supportOneTime" aria-describedby="supportHint"></a><p id="supportHint" class="hint" data-i18n="supportHint"></p></div>
        <div class="footer"><button type="button" id="defaults" data-i18n="reset"></button><button type="submit" id="apply" data-i18n="apply"></button></div>
      </form></section><button id="entry" data-i18n-aria="openSettings" aria-haspopup="dialog" aria-controls="panel" aria-expanded="false" aria-pressed="true"></button>`;
      this.elements=Object.fromEntries([...this.shadow.querySelectorAll("[id]")].map(el=>[el.id,el]));const e=this.elements;
      const support=root.YTSteadySupport;if(support?.enabled&&support.supportUrl){e.supportLink.href=support.supportUrl;e.support.hidden=false;}
      e.entry.addEventListener("click",()=>this.togglePanel());e.close.addEventListener("click",()=>this.togglePanel(false));
      e.enabled.addEventListener("change",()=>actions.save({enabled:e.enabled.checked}));
      e.language.addEventListener("change",()=>actions.save({language:e.language.value}));
      e.defaults.addEventListener("click",()=>actions.save({...S.defaults,language:actions.settings().language},true));
      e.form.addEventListener("submit",event=>{
        event.preventDefault();const values={};let valid=true;
        for(const name of Object.keys(S.fields)){
          const result=I.validate(e[name].value,S.fields[name]);this.showValidation(name,result);
          if(result.error)valid=false;else values[name]=result.value;
        }
        if(!valid){e.form.reportValidity();return;}actions.save(values,true);
      });
      for(const name of Object.keys(S.fields)){
        const field=e[name];field.addEventListener("input",()=>this.draftChanged(name));
        if(name!=="subpixel")field.addEventListener("keydown",event=>{
          if(!["ArrowUp","ArrowDown"].includes(event.key)||event.ctrlKey||event.altKey||event.metaKey)return;
          event.preventDefault();const spec=S.fields[name],parsed=I.parseNumber(field.value),current=parsed.value??spec.value;
          const steps=Math.round((current-spec.min)/spec.step)+(event.key==="ArrowUp"?1:-1)*(event.shiftKey?10:1);
          field.value=I.input(Math.max(spec.min,Math.min(spec.max,Math.round((spec.min+steps*spec.step)*10000)/10000)));this.draftChanged(name);
        });
      }
      for(const name of ["keydown","keyup","keypress"])this.shadow.addEventListener(name,event=>{
        event.stopPropagation();if(event.key==="Escape"&&!e.panel.hidden){this.togglePanel(false);event.preventDefault();}
      });
      for(const name of ["click","dblclick","pointerdown","wheel"])this.host.addEventListener(name,event=>event.stopPropagation());
      player.append(this.host);this.refreshFields(actions.settings());this.translate();this.layout();
    }
    draftChanged(name){this.showValidation(name,{});this.updateNumericARIA(name);this.actions.draft();}
    updateNumericARIA(name){
      const field=this.elements[name];if(name==="subpixel")return;
      const parsed=I.parseNumber(field.value);if(parsed.error){field.removeAttribute("aria-valuenow");field.removeAttribute("aria-valuetext");}
      else{field.setAttribute("aria-valuenow",String(parsed.value));field.setAttribute("aria-valuetext",I.input(parsed.value));}
    }
    showValidation(name,result){
      const field=this.elements[name];field.setCustomValidity(result.error?I.t(result.error,Object.fromEntries(Object.entries(result.args||{}).map(([k,v])=>[k,I.input(v)]))):"");
      if(result.error){field.setAttribute("aria-invalid","true");this.errors.set(name,result);}
      else{field.removeAttribute("aria-invalid");this.errors.delete(name);}
    }
    refreshFields(settings){
      const e=this.elements;e.enabled.checked=settings.enabled;
      for(const name of Object.keys(S.fields)){e[name].value=name==="subpixel"?String(settings[name]):I.input(settings[name]);this.showValidation(name,{});this.updateNumericARIA(name);}
      I.languageOptions(e.language);
    }
    translate(){
      this.host.lang=I.tag;this.host.dir=I.dir;this.host.style.direction=I.dir;
      I.translateDOM(this.shadow);I.languageOptions(this.elements.language);
      this.elements.zoomHint.textContent=I.t("zoomHint",{zoom:I.input(S.defaults.zoom),full:I.number(1,2)});
      this.elements.dampingHint.textContent=I.t("dampingHint",{damping:I.number(1,1)});
      this.elements.languageHint.textContent=I.t("automaticHint",{language:I.languageName});this.elements.languageHint.hidden=I.choice!=="auto";
      for(const name of Object.keys(S.fields)){
        if(name!=="subpixel"){const value=I.parseNumber(this.elements[name].value);if(!value.error)this.elements[name].value=I.input(value.value);this.updateNumericARIA(name);}
        if(this.errors.has(name))this.showValidation(name,this.errors.get(name));
      }
      this.effectiveSignature="";this.layout();
    }
    refreshEntry(settings,error){const e=this.elements;e.entry.textContent=I.t(error?"entryBypass":settings.enabled?"entryOn":"entryOff");e.entry.setAttribute("aria-pressed",String(settings.enabled&&!error));}
    togglePanel(force){
      const e=this.elements,open=force??e.panel.hidden;e.panel.hidden=!open;e.entry.setAttribute("aria-expanded",String(open));this.layout();
      (open?e.close:e.entry).focus({preventScroll:true});
    }
    layout(){
      const e=this.elements,open=!e.panel.hidden,compact=open&&this.player.clientHeight<300;
      e.entry.hidden=compact;const bottom=compact?12:58;this.host.style.insetBlockEnd=bottom+"px";
      const entryHeight=compact?0:(e.entry.offsetHeight||30)+8;
      e.panel.style.inlineSize=Math.max(100,Math.min(384,this.player.clientWidth-24,innerWidth-24))+"px";
      e.panel.style.maxHeight=Math.max(60,Math.min(this.player.clientHeight-bottom-entryHeight-12,innerHeight-bottom-entryHeight-24))+"px";
    }
    setEffective(area){
      if(!area)return;const signature=[I.code,area.winx,area.winy,area.estimateDx,area.estimateDy].join(":");
      if(signature===this.effectiveSignature)return;this.effectiveSignature=signature;
      this.elements.effective.textContent=I.t("effective",{width:I.number(area.winx),height:I.number(area.winy),dx:I.number(area.estimateDx),dy:I.number(area.estimateDy)});
    }
    publish(state){
      const n=(value,digits=0)=>I.number(value,digits);
      this.elements.perf.textContent=[I.t("perfOutput",{fps:n(state.outputFps,1)}),I.t("perfTiming",{mean:n(state.meanMs,2),p95:n(state.p95Ms,2)}),
        I.t("perfStages",{read:n(state.copyMs,2),compute:n(state.computeMs,2),draw:n(state.drawMs,2)}),
        I.t("perfSource",{dropped:n(state.dropped),total:n(state.total),missed:n(state.callbackMisses)}),I.t("perfUncertain",{count:n(state.invalidMatches)}),
        I.t("perfFormat",{format:state.pixelFormat||"—"}),...(state.errorDetail?[I.t("perfError",{error:state.errorDetail})]:[])].join("\n");
    }
  }
  root.YTSteadyPlayerUI=PlayerUI;
})(globalThis);
