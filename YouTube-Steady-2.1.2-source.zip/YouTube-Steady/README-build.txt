YouTube Steady 2.1.2 — corresponding source and verification

Runtime: desktop Chrome 120+ with VideoFrame, requestVideoFrameCallback,
WebAssembly SIMD. Tested on Chrome 156 / Windows with the included reports.
Other Chromium browsers are not separately qualified.
No Node, Python, compiler or local server is needed for normal extension use.

Build prerequisites (official tools; not installed globally by this project):
  Emscripten SDK 6.0.13, CMake 3.24+ or 4.x, Ninja, PowerShell.
  https://emscripten.org/docs/getting_started/downloads.html
  git clone https://github.com/emscripten-core/emsdk.git <SDK>
  <SDK>\emsdk.bat install 6.0.13
  <SDK>\emsdk.bat activate 6.0.13 --embedded
  All paths below should be absolute. No persistent PATH edit is required.

FFTW:
  The matching source ZIP includes src/vendor/fftw/fftw-3.3.10.tar.gz.
  SHA256 56c932549852cddcfafdab3820b0200c7742675be92179e59e6215b340e26467
  Extract that archive to a build directory; it contains all original source,
  build inputs, licenses and documentation. The wasm build uses single
  precision, static linking, SIMD, no OpenMP/threads/Fortran or native DLLs.

From this project directory in PowerShell:
  .\src\build-fftw.ps1 -SdkRoot <SDK> -FftwRoot <EXTRACTED-FFTW> `
      -FftwBuild <FFTW-BUILD> -CMake <CMAKE-EXE> -Ninja <NINJA-EXE>
  .\src\build-core.ps1 -SdkRoot <SDK> -FftwRoot <EXTRACTED-FFTW> `
      -FftwBuild <FFTW-BUILD>
  Output: extension/depan-core.js and extension/depan-core.wasm.
  Run build-core.ps1 under PowerShell; do not run em++.exe without the SDK
  configuration. The scripts set process-local EM_CONFIG/EMCC_TEMP_DIR.

Automated tests (Node 20+; no npm packages required):
  npm test
  360 source-luma frames, including cuts and a long pan, compare the wasm
  estimator with the installed native DePanEstimate 2.12. Three parameter
  sets compare method=0 compensation with native DePan 2.15. The original
  native golden data, DLL hashes and input luma are in validation/native.
  These tests do not need AviSynth or the native DLLs to run.
  Native regeneration only: Python 3 + Pillow, installed AviSynth C API,
  DePan.dll, DePanEstimate.dll, ImageSeq.dll. See tests/native_reference.py.
  Neither the test nor the browser extension changes steady.avs.

Browser regression (synthetic media only):
  npm run serve
  Open http://127.0.0.1:8770/ in an active foreground Chrome tab.
  Click 製作測試片 once. It creates a local 12-second 1080p/30 WebM.
  Click each test button and inspect the JSON results. The test reads the
  actual output canvas: a fixed background landmark and an encoded source
  frame ID check stabilization and same-frame pairing independently.
  Deliberately using the prior compensation is a negative control.
  Other buttons cover forward/back/rapid seeks, pause, parameter changes,
  speed, video replacement, ads, original CSS, restricted frames and
  renderer failure/retry. The restricted-frame test intentionally serves
  synthetic media through localhost rather than 127.0.0.1; it does not
  bypass the browser's origin policy. Ctrl+C stops the local-only server.
  This development server is not used by the installed extension.

Algorithm scope and differences:
  The translation estimator uses original unnormalized single-precision FFTW
  cross-correlation and native peak/trust/subpixel calculations. Smoothing
  ports DePanStabilize method=0's nonlinear predictor/corrector, rolling base
  and soft travel limits. It is not a wrapper around an AviSynth DLL.
  src/depan_core.cpp records the deliberate fixes and removed features.
  Runtime analyzes and draws the same captured VideoFrame, in source-pixel
  units. Audio and the timeline remain owned by YouTube; output has one
  processing interval of delay. Cuts/low confidence reset compensation.
  A large moving foreground or textureless scene can still confuse the
  original global estimator. Rotation, optical rolling shutter, deliberate
  camera motion and zoom are not universally removable by translation.
  Border fill is black; no future-frame synthesis. PiP/casting uses original
  video. HDR output is not calibrated. Protected/non-readable media safely
  uses the original player. See 使用說明.txt for controls and tuning.

License/provenance: GNU GPL v2 or later; see LICENSE.txt and NOTICE.txt.



UI/localization changes do not require rebuilding the motion core. Run
  npm run build:locales
after editing message catalogs, then npm test. See TRANSLATING.txt.
The browser harness also tests 12 languages, draft preservation, localized
validation, output recovery and compact 320x180 RTL layouts. Pixel readback
stress and ordinary playback cadence are separate observations; use the
Compare playback cadence button to record original and stabilized intervals.
An optional previous-release comparison can use process-local PORT,
STEADY_RUNTIME_ROOT (an extracted old extension), and STEADY_TEST_PAGE
(a matching fixed test HTML file). No installed extension is overwritten.
