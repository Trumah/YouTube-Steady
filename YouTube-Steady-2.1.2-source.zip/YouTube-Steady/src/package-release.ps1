$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$steadyProject = Split-Path -Parent $PSScriptRoot
$steadyOutput = Split-Path -Parent $steadyProject
$steadyManifest = Get-Content -LiteralPath (Join-Path $steadyProject 'extension\manifest.json') -Raw | ConvertFrom-Json
$steadyVersion = $steadyManifest.version
if ($steadyVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'Expected a three-part release version' }
& node (Join-Path $PSScriptRoot 'build-locales.cjs') --check
if ($LASTEXITCODE) { throw 'Locale bundle is not ready for release' }
& node (Join-Path $PSScriptRoot 'build-distribution.cjs') --check
if ($LASTEXITCODE) { throw 'Public destinations are not ready for release' }
$steadyExtension = @('manifest.json','depan-core.js','depan-core.wasm','locales.js','i18n.js','settings.js','support.js','renderer.js','ui.js','controller.js','popup.html','popup.js','LICENSE.txt','NOTICE.txt','FFTW-COPYRIGHT.txt','EMSCRIPTEN-LICENSE.txt')
foreach ($steadyCatalog in Get-ChildItem -LiteralPath (Join-Path $steadyProject 'extension\_locales') -Filter messages.json -File -Recurse) {
    $steadyExtension += $steadyCatalog.FullName.Substring((Join-Path $steadyProject 'extension').Length + 1).Replace('\','/')
}
function Write-SteadyZip([string]$Path, [hashtable]$Files) {
    $steadyStream = [IO.File]::Open($Path,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try {
        $steadyArchive = [IO.Compression.ZipArchive]::new($steadyStream,[IO.Compression.ZipArchiveMode]::Create,$false)
        try {
            foreach ($steadyEntry in ($Files.Keys | Sort-Object)) {
                $steadyFile = $Files[$steadyEntry]
                if (!(Test-Path -LiteralPath $steadyFile -PathType Leaf)) { throw "Missing release input: $steadyFile" }
                [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($steadyArchive,$steadyFile,$steadyEntry,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
            }
        } finally { $steadyArchive.Dispose() }
    } finally { $steadyStream.Dispose() }
}
$steadyBinaryFiles = @{}
foreach ($steadyName in $steadyExtension) { $steadyBinaryFiles[$steadyName] = Join-Path $steadyProject "extension\$steadyName" }
$steadyBinaryZip = Join-Path $steadyOutput "YouTube-Steady-$steadyVersion.zip"
Write-SteadyZip $steadyBinaryZip $steadyBinaryFiles
$steadySourceFiles = @{}
foreach ($steadyName in $steadyExtension) { $steadySourceFiles["YouTube-Steady/extension/$steadyName"] = Join-Path $steadyProject "extension\$steadyName" }
# Public source includes synthetic evidence only. Local installed-browser
# records and screenshots of a signed-in YouTube page stay outside this ZIP.
$steadyRelativeFiles = @('package.json','README.txt','README-build.txt','TRANSLATING.txt','使用說明.txt','LICENSE.txt','NOTICE.txt','FFTW-COPYRIGHT.txt','EMSCRIPTEN-LICENSE.txt','ui-preview-en.png','ui-preview-ar.png','tests/depan.test.cjs','tests/settings.test.cjs','tests/i18n.test.cjs','tests/native_reference.py','dev/v2.html','dev/v2-harness.js','dev/i18n-harness.js','dev/popup-preview.html','dev/popup-test-api.js','dev/server.cjs','validation/native/reference.json','validation/native/world-0.bin','validation/native/world-1.bin','validation/native-conformance.json','validation/i18n-browser.json','validation/media-v2.1.json','validation/cadence-v2.0-local.json','validation/cadence-v2.1-local.json','validation/public-validation.json')
foreach ($steadyName in $steadyRelativeFiles) { $steadySourceFiles["YouTube-Steady/$steadyName"] = Join-Path $steadyProject $steadyName }
foreach ($steadyName in @('PUBLISHING.txt','RELEASE.txt','tests/distribution.test.cjs','site/index.html','site/style.css','site/script.js','site/icon.svg','dev/site-server.cjs','dev/support-test.html','dev/support-harness.js','validation/i18n-browser-2.1.1.json','validation/support-browser.json','validation/site-browser.json','website-preview-en.png','website-preview-zh-mobile.png')) {
    $steadySourceFiles["YouTube-Steady/$steadyName"] = Join-Path $steadyProject $steadyName
}
foreach ($steadyName in @('validation/i18n-browser-2.1.2.json','validation/support-browser-2.1.2.json','validation/popup-support-2.1.2.json','validation/site-browser-2.1.2.json')) {
    $steadySourceFiles["YouTube-Steady/$steadyName"] = Join-Path $steadyProject $steadyName
}
foreach ($steadyFile in Get-ChildItem -LiteralPath $PSScriptRoot -File -Recurse) {
    $steadyName = $steadyFile.FullName.Substring($steadyProject.Length + 1).Replace('\','/')
    $steadySourceFiles["YouTube-Steady/$steadyName"] = $steadyFile.FullName
}
$steadySourceZip = Join-Path $steadyOutput "YouTube-Steady-$steadyVersion-source.zip"
Write-SteadyZip $steadySourceZip $steadySourceFiles
@($steadyBinaryZip,$steadySourceZip) | ForEach-Object {
    [pscustomobject]@{file=[IO.Path]::GetFileName($_);bytes=(Get-Item -LiteralPath $_).Length;sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash}
} | ConvertTo-Json
