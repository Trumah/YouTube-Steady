/* App-owned browser regression; run via the visible test button. */
(function(){
  "use strict";
  const $=id=>document.getElementById(id),pause=ms=>new Promise(r=>setTimeout(r,ms));
  const state=()=>JSON.parse($("yt-steady-controls")?.dataset.state||"{}"),ui=()=>$("yt-steady-controls").shadowRoot;
  async function until(fn,ms=8000){const start=performance.now();while(!fn()){if(performance.now()-start>ms)throw Error("Timed out");await pause(30);}}
  async function language(code){const select=ui().getElementById("language");select.value=code;select.dispatchEvent(new Event("change",{bubbles:true}));await pause(70);}
  function field(name,value){const input=ui().getElementById(name);input.value=value;input.dispatchEvent(new Event("input",{bubbles:true}));}
  $("test-i18n").addEventListener("click",async()=>{
    const button=$("test-i18n"),player=$("movie_player"),video=player.querySelector("video"),I=YTSteadyI18n,S=YTSteadySettings;
    const report={version:"2.1.2",environment:navigator.userAgent,checks:{},locales:[],compact:[]};
    const show=()=>{$("i18n-results").textContent=JSON.stringify(report,null,2);};
    const check=(name,pass,detail={})=>{report.checks[name]={pass,...detail};show();};
    const originalStyle=player.getAttribute("style"),originalLoop=video.loop;let original;
    button.disabled=true;$("i18n-status").textContent="Testing languages, input, playback and compact layout…";
    try{
      await until(()=>video.readyState>=2&&!!$("yt-steady-controls"));original=state();video.loop=true;
      if(!ui().getElementById("enabled").checked)ui().getElementById("enabled").click();
      if(ui().getElementById("panel").hidden)ui().getElementById("entry").click();
      video.currentTime=0;await until(()=>!video.seeking);await video.play();await until(()=>state().active&&state().outputFrames>=6);
      field("zoom","1,12");const before=state(),beforeTime=video.currentTime;
      for(const locale of I.languages){
        await language(locale.code);const s=state(),panel=ui().getElementById("panel"),rect=panel.getBoundingClientRect(),bounds=player.getBoundingClientRect();
        report.locales.push({code:locale.code,locale:s.locale,dir:$("yt-steady-controls").dir,label:ui().getElementById("apply").textContent,zoomDraft:ui().getElementById("zoom").value,
          noOverflow:panel.scrollWidth<=panel.clientWidth+1,insidePlayer:rect.left>=bounds.left-1&&rect.right<=bounds.right+1&&rect.top>=bounds.top-1&&rect.bottom<=bounds.bottom+1,
          correct:s.locale===locale.code&&$("yt-steady-controls").dir===locale.dir&&ui().getElementById("apply").textContent===I.t("apply")&&I.parseNumber(ui().getElementById("zoom").value).value===1.12&&s.zoom===before.zoom&&s.statusKey==="statusPending"});
      }
      const after=state();check("all_12_languages",report.locales.length===12&&report.locales.every(x=>x.correct&&x.noOverflow&&x.insidePlayer),{count:report.locales.length});
      check("language_keeps_playback_and_motion",after.resets===before.resets&&after.outputFrames>before.outputFrames&&video.currentTime>beforeTime&&!video.paused,{before:before.resets,after:after.resets,frames:after.outputFrames-before.outputFrames});
      await language("ar");field("zoom","١٫١٢");field("cutoff","٠٫٧٠");field("damping","١٫٢");ui().getElementById("apply").click();
      await until(()=>state().zoom===1.12&&state().cutoff===.7&&state().damping===1.2&&state().active);
      check("arabic_numeric_apply",true,{zoom:state().zoom,cutoff:state().cutoff,damping:state().damping});
      field("zoom","١٫٣٠");ui().getElementById("apply").click();await pause(60);
      check("localized_range_guard",state().zoom===1.12&&ui().getElementById("zoom").getAttribute("aria-invalid")==="true"&&!!ui().getElementById("zoom").validationMessage,{message:ui().getElementById("zoom").validationMessage});
      await language("fr");check("invalid_draft_survives_language",I.parseNumber(ui().getElementById("zoom").value).value===1.3&&ui().getElementById("zoom").getAttribute("aria-invalid")==="true"&&state().zoom===1.12,{draft:ui().getElementById("zoom").value,message:ui().getElementById("zoom").validationMessage});
      ui().getElementById("defaults").click();await until(()=>state().active&&!state().error);
      $("yt-steady-output").dispatchEvent(new Event("contextlost"));await pause(60);const errorResets=state().resets;
      await language("ar");check("error_translates_without_retry",state().error&&!state().active&&state().resets===errorResets&&state().statusKey==="errorCanvas"&&ui().getElementById("status").textContent===I.t("errorCanvas"));
      ui().getElementById("apply").click();await until(()=>state().active&&!state().error);check("unchanged_apply_recovers_output",true);
      player.style.width="320px";player.style.height="180px";ui().getElementById("advanced").open=true;
      for(const code of ["de","ru","ar","hi"]){
        await language(code);const panel=ui().getElementById("panel"),rect=panel.getBoundingClientRect(),bounds=player.getBoundingClientRect();
        report.compact.push({code,width:panel.clientWidth,height:panel.clientHeight,scrollWidth:panel.scrollWidth,
          insidePlayer:rect.left>=bounds.left-1&&rect.right<=bounds.right+1&&rect.top>=bounds.top-1&&rect.bottom<=bounds.bottom+1,noOverflow:panel.scrollWidth<=panel.clientWidth+1});
      }
      check("compact_320x180_rtl_and_long_labels",report.compact.every(x=>x.insidePlayer&&x.noOverflow));
      check("source_video_css_preserved",video.style.transform==="translateZ(0px)"&&video.style.translate==="3px 2px"&&video.style.scale==="1");
      $("i18n-status").textContent="UI regression completed";
    }catch(error){check("unexpected_error",false,{message:error.message});$("i18n-status").textContent="UI regression failed: "+error.message;}
    finally{
      video.pause();video.loop=originalLoop;if(originalStyle===null)player.removeAttribute("style");else player.setAttribute("style",originalStyle);
      if(original){await language(original.language||"auto");for(const name of Object.keys(S.fields))field(name,name==="subpixel"?String(original[name]):I.input(original[name]));ui().getElementById("apply").click();if(ui().getElementById("enabled").checked!==original.enabled)ui().getElementById("enabled").click();}
      button.disabled=false;show();
    }
  });
})();
