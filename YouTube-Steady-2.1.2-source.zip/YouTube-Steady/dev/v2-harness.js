"use strict";
const $=id=>document.getElementById(id),wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let video=document.querySelector("video"),fixture=location.origin+"/fixture-v2.webm";
const results={version:"2.1.2",environment:{userAgent:navigator.userAgent,visibility:document.visibilityState},checks:{}};
const state=()=>JSON.parse($("yt-steady-controls")?.dataset.state||"{}");
const ui=()=>$("yt-steady-controls").shadowRoot;
function show(){ $("results").textContent=JSON.stringify(results,null,2); }
function status(text){$("status").textContent=text;}
function check(name,pass,details={}){results.checks[name]={pass,...details};show();}
function once(target,name,ms=15000){return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{target.removeEventListener(name,done);reject(Error(name+" timed out"));},ms);function done(e){clearTimeout(timer);resolve(e);}target.addEventListener(name,done,{once:true});});}
async function until(fn,ms=8000){const begin=performance.now();while(!fn()){if(performance.now()-begin>ms)throw Error("condition timed out");await wait(40);}}
async function load(url){video.pause();const ready=once(video,"loadeddata");video.src=url;video.load();await ready;await until(()=>!!$("yt-steady-controls"));}
async function seek(time){const ready=once(video,"seeked");video.currentTime=time;await ready;await wait(120);}
async function enabled(value){if(ui().getElementById("enabled").checked!==value)ui().getElementById("enabled").click();await wait(60);}
async function params(value){for(const [name,v]of Object.entries(value))ui().getElementById(name).value=String(v);ui().getElementById("apply").click();await wait(70);}
async function defaults(){ui().getElementById("defaults").click();await wait(70);}
function truth(n){return {x:Math.round((5.8*Math.sin(n*1.7)+2.7*Math.cos(n*.91)+n*.075)*6),y:Math.round(3.8*Math.sin(n*2.21)*6),pan:n*.075*6};}
function makeWorld(){
  const c=document.createElement("canvas");c.width=2560;c.height=1480;const ctx=c.getContext("2d");
  ctx.fillStyle="#8e8e8e";ctx.fillRect(0,0,c.width,c.height);let seed=0x715681;
  const rand=()=>{seed=Math.imul(seed,1664525)+1013904223|0;return(seed>>>0)/4294967296;};
  for(let n=0;n<3000;n++){const gray=30+Math.floor(rand()*185);ctx.fillStyle=`rgb(${gray},${gray},${gray})`;const x=rand()*c.width,y=rand()*c.height;ctx.fillRect(x,y,7+rand()*70,7+rand()*55);ctx.strokeStyle="#e3e3e3";ctx.strokeRect(x,y,7+rand()*70,7+rand()*55);}
  ctx.fillStyle="#fff";ctx.font="bold 75px sans-serif";ctx.fillText("DePan · FRAME MATCHED",480,490);
  // This fixed background marker moves with the known camera displacement.
  ctx.fillStyle="#f52222";ctx.fillRect(1280-12,740-12,24,24);return c;
}
async function prepare(){
  $("prepare").disabled=true;status("正在產生 1080p／30 fps 測試片，約 12 秒…");
  try{
    const world=makeWorld(),canvas=document.createElement("canvas");canvas.width=1920;canvas.height=1080;const ctx=canvas.getContext("2d",{alpha:false});
    const stream=canvas.captureStream(0),track=stream.getVideoTracks()[0],chunks=[];
    const mime=["video/webm;codecs=vp9","video/webm;codecs=vp8"].find(MediaRecorder.isTypeSupported);
    const recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:7000000});recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
    const stopped=once(recorder,"stop",25000);recorder.start();const begin=performance.now();
    for(let n=0;n<360;n++){
      const p=truth(n);ctx.drawImage(world,-320+p.x,-200+p.y);
      // Moving foreground, outside the background marker's tracking region.
      ctx.fillStyle="#273b52";ctx.fillRect(1350+Math.sin(n*.09)*120,700,100,160);
      // Frame-ID bar is outside the FFT analysis window and survives typical motion.
      ctx.fillStyle="#000";ctx.fillRect(84,84,195,44);ctx.fillStyle="#10f020";ctx.fillRect(96,96,10,22);
      for(let bit=0;bit<9;bit++){ctx.fillStyle=(n>>bit)&1?"#fff":"#111";ctx.fillRect(116+bit*16,96,16,22);}track.requestFrame();
      await wait(Math.max(0,begin+(n+1)*1000/30-performance.now()));
    }
    recorder.stop();await stopped;track.stop();const blob=new Blob(chunks,{type:"video/webm"});
    const response=await fetch("/fixture-v2.webm",{method:"POST",headers:{"Content-Type":"video/webm"},body:blob});if(!response.ok)throw Error("fixture write failed");
    await load(fixture);if(!Number.isFinite(video.duration)){await seek(1e6);await seek(0);}
    results.fixture={width:video.videoWidth,height:video.videoHeight,duration:video.duration,bytes:blob.size};
    activate();status("測試片已就緒");show();
  }catch(error){status("製作失敗："+error.message);check("prepare",false,{error:error.message});}
  finally{$("prepare").disabled=false;}
}
function activate(){for(const id of ["pixels","seek","recovery","lifecycle"])$(id).disabled=false;}
function observePixels(canvas){
  const ctx=canvas.getContext("2d"),bar=ctx.getImageData(0,0,450,270),landmark=ctx.getImageData(790,360,560,360);
  let gx=0,gy=0,gcount=0,minX=Infinity,minY=Infinity,maxY=-1;
  for(let y=0;y<bar.height;y++)for(let x=0;x<bar.width;x++){
    const p=(y*bar.width+x)*4;if(bar.data[p]<80&&bar.data[p+1]>155&&bar.data[p+2]<100){gx+=x;gy+=y;gcount++;minX=Math.min(minX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);}
  }
  if(gcount<35)return null;const cy=Math.round(gy/gcount),anchor=Math.round(gx/gcount-4.5);let n=0;
  for(let bit=0;bit<9;bit++){const x=anchor+20+bit*16+8,p=(cy*bar.width+x)*4;if(bar.data[p]>128)n|=1<<bit;}
  let rx=0,ry=0,count=0;
  for(let y=0;y<landmark.height;y++)for(let x=0;x<landmark.width;x++){
    const p=(y*landmark.width+x)*4;if(landmark.data[p]>160&&landmark.data[p+1]<95&&landmark.data[p+2]<95){rx+=x+790;ry+=y+360;count++;}
  }
  if(count<100)return null;
  return {n,x:rx/count,y:ry/count,map:JSON.parse(canvas.dataset.frame||"{}")};
}
async function pixelTest(){
  $("pixels").disabled=true;
  try{
    video.pause();video.playbackRate=1;await defaults();await enabled(false);
    check("original_video_untouched",video.style.transform==="translateZ(0px)"&&video.style.translate==="3px 2px"&&video.style.scale==="1",{style:video.getAttribute("style")});
    check("disable_restores_original",!state().active,{state:state()});await enabled(true);await seek(0);
    status("量測實際輸出畫素、影格編號與配對，約 10 秒…");
    const observations=[];let handle,done=false,last=-1;
    const collect=()=>{
      const canvas=$("yt-steady-output"),data=canvas?.dataset.frame;
      if(data&&data!==last&&state().enabled){last=data;const point=observePixels(canvas);if(point&&point.n<360)observations.push(point);}
      if(!done)handle=requestAnimationFrame(collect);
    };
    const q0=video.getVideoPlaybackQuality();await video.play();handle=requestAnimationFrame(collect);await wait(10400);video.pause();done=true;cancelAnimationFrame(handle);await wait(120);
    const q1=video.getVideoPlaybackQuality(),frames=observations.filter((f,i)=>f.n>=25&&f.n<310&&(i===0||f.n!==observations[i-1].n));
    let raw=0,after=0,pairs=0;const errors=[],staleErrors=[];
    const first=frames[0];if(!first)throw Error("No output pixel markers found");const p0=truth(first.n),base={x:first.x-p0.x+first.map.mapX,y:first.y-p0.y+first.map.mapY};
    for(let i=1;i<frames.length;i++){
      const a=frames[i-1],b=frames[i],pa=truth(a.n),pb=truth(b.n);
      errors.push(Math.hypot(b.x-(base.x+pb.x-b.map.mapX),b.y-(base.y+pb.y-b.map.mapY)));
      staleErrors.push(Math.hypot(b.x-(base.x+pb.x-a.map.mapX),b.y-(base.y+pb.y-a.map.mapY)));
      if(b.n-a.n!==1)continue;const pan=pb.pan-pa.pan;
      raw+=(pb.x-pa.x-pan)**2+(pb.y-pa.y)**2;after+=(b.x-a.x-pan)**2+(b.y-a.y)**2;pairs++;
    }
    const ratio=Math.sqrt(after/raw),percentile=(a,p)=>a.slice().sort((x,y)=>x-y)[Math.floor(a.length*p)];
    results.pixels={frames:frames.length,pairs,residualVelocityRatio:ratio,reductionPercent:100*(1-ratio),pairErrorP95:percentile(errors,.95),stalePairErrorMedian:percentile(staleErrors,.5),decoded:q1.totalVideoFrames-q0.totalVideoFrames,dropped:q1.droppedVideoFrames-q0.droppedVideoFrames,state:state(),sample:frames.slice(8,13)};
    check("output_pixel_stabilization",pairs>150&&ratio<.4,{pairs,ratio});
    check("same_frame_pairing",percentile(errors,.95)<.8,{p95:percentile(errors,.95)});
    check("stale_pair_negative_control",percentile(staleErrors,.5)>5,{median:percentile(staleErrors,.5)});
    check("output_framerate",results.pixels.state.outputFps>25,{fps:results.pixels.state.outputFps,missed:results.pixels.state.callbackMisses});
    check("source_playback",results.pixels.dropped<=4,{decoded:results.pixels.decoded,dropped:results.pixels.dropped});
    status("畫素與影格配對測試完成");show();
  }catch(error){check("pixel_test_error",false,{error:error.message});status("畫素測試失敗："+error.message);}
  finally{$("pixels").disabled=false;}
}
async function seekTest(){
  $("seek").disabled=true;
  try{
    await defaults();video.pause();await seek(8);await video.play();await wait(1200);video.pause();const forward={time:video.currentTime,...state()};
    await seek(2);await video.play();await wait(1200);video.pause();const backward={time:video.currentTime,...state()};
    check("seek_forward_backward",forward.time>8&&backward.time>2&&backward.time<4.5&&forward.active&&backward.active&&!backward.error,{forward,backward});
    await wait(180);const before=$("yt-steady-output").dataset.frame;await wait(280);check("pause_freezes_output",$("yt-steady-output").dataset.frame===before,{frame:JSON.parse(before)});
    for(const time of [6,1,7,2])video.currentTime=time;await until(()=>!video.seeking);await video.play();await wait(800);video.pause();
    check("rapid_seek_recovery",state().active&&!state().error,{state:state()});status("跳轉與暫停測試完成");
  }catch(error){check("seek_test_error",false,{error:error.message});status(error.message);}finally{$("seek").disabled=false;}
}
async function recoveryTest(){
  $("recovery").disabled=true;
  try{
    await defaults();await load(`http://localhost:${location.port}/fixture-v2.webm`);await video.play();await wait(1000);video.pause();
    check("restricted_frame_safe_restore",state().error&&!state().active,{state:state()});
    await load(fixture);await video.play();await wait(1200);video.pause();check("source_recovery",state().active&&!state().error,{state:state()});
    $("yt-steady-output").dispatchEvent(new Event("contextlost"));await wait(80);check("canvas_failure_restore",state().error&&!state().active,{state:state()});
    await defaults();await video.play();await wait(900);video.pause();check("canvas_failure_recovery",state().active&&!state().error,{state:state()});status("失敗恢復測試完成");
  }catch(error){check("recovery_test_error",false,{error:error.message});status(error.message);}finally{$("recovery").disabled=false;}
}
async function lifecycleTest(){
  $("lifecycle").disabled=true;
  try{
    await params({cutoff:.7,damping:1.2,dxmax:96,dymax:128,trust:4,winx:256,winy:256,estimateDx:192,estimateDy:192});
    await seek(0);video.playbackRate=2;await video.play();await wait(2200);video.pause();
    check("parameters_and_double_speed",state().cutoff===.7&&state().damping===1.2&&state().area.estimateDx===127&&state().active&&!state().error,{time:video.currentTime,state:state()});
    video.playbackRate=1;await defaults();await seek(0);await video.play();await wait(300);$("movie_player").classList.add("ad-showing");await wait(250);
    check("ad_original_passthrough",!state().active||$("yt-steady-surface").style.display==="none");$("movie_player").classList.remove("ad-showing");await wait(400);
    video.style.transform="scaleX(-1)";await wait(200);check("external_transform_kept",video.style.transform==="scaleX(-1)"&&$("yt-steady-surface").style.transform.includes("matrix(-1"),{surface:$("yt-steady-surface").style.transform});
    video.pause();const old=video,newVideo=document.createElement("video");newVideo.className="html5-main-video";newVideo.controls=true;newVideo.muted=true;newVideo.playsInline=true;newVideo.style.cssText="transform:translateZ(0);translate:3px 2px;scale:1";old.replaceWith(newVideo);video=newVideo;
    await load(fixture);await video.play();await wait(1000);video.pause();
    check("video_replacement",state().active&&!state().error&&document.querySelectorAll("#yt-steady-controls").length===1&&document.querySelectorAll("#yt-steady-surface").length===1,{state:state(),oldStyle:old.getAttribute("style")});
    status("參數與換片測試完成");
  }catch(error){check("lifecycle_test_error",false,{error:error.message});status(error.message);}finally{$("lifecycle").disabled=false;}
}
$("prepare").addEventListener("click",prepare);$("pixels").addEventListener("click",pixelTest);$("seek").addEventListener("click",seekTest);$("recovery").addEventListener("click",recoveryTest);$("lifecycle").addEventListener("click",lifecycleTest);
$("fullscreen").addEventListener("click",()=>document.fullscreenElement?document.exitFullscreen():$("movie_player").requestFullscreen());
$("test-cadence").addEventListener("click",async()=>{
  $("test-cadence").disabled=true;const samples=[];
  try{
    await defaults();video.playbackRate=1;
    for(const stabilized of [false,true]){
      video.pause();await enabled(stabilized);await seek(0);await video.play();await wait(1000);
      status(stabilized?"Measuring stabilized playback without pixel readbacks…":"Measuring original playback…");
      const begin=video.getVideoPlaybackQuality(),time=video.currentTime;await wait(8000);const end=video.getVideoPlaybackQuality();
      video.pause();await wait(80);samples.push({stabilized,seconds:video.currentTime-time,decoded:end.totalVideoFrames-begin.totalVideoFrames,dropped:end.droppedVideoFrames-begin.droppedVideoFrames,state:state()});
    }
    results.cadence=samples;check("native_playback_baseline",samples[0].dropped<=4,{sample:samples[0]});
    check("stabilized_playback_without_readbacks",samples[1].dropped<=4&&samples[1].state.outputFps>=29,{sample:samples[1]});status("Playback cadence comparison completed");
  }catch(error){check("cadence_error",false,{error:error.message});}finally{$("test-cadence").disabled=false;show();}
});
(async()=>{try{const response=await fetch("/fixture-v2.webm",{method:"HEAD"});if(response.ok){await load(fixture);if(!Number.isFinite(video.duration)){await seek(1e6);await seek(0);}activate();status("既有測試片已就緒");}else status("請先製作測試片");}catch(error){status(error.message);}})();
