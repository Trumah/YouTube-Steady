/* Each job owns one VideoFrame. Analysis and output always use that same object.
 * The original video's audio, timeline and controls stay in YouTube's player.
 * The video itself receives no CSS changes. GPL-2.0, see LICENSE.txt.
 */
(function(root){
  "use strict";
  let modulePromise=null,owner=null,queue=Promise.resolve();
  function exclusive(fn){const next=queue.then(fn,fn);queue=next.catch(()=>{});return next;}
  async function createCore(asset){
    if(!modulePromise)modulePromise=root.YTDePanModule({locateFile:name=>asset(name)}).catch(error=>{modulePromise=null;throw error;});
    return new Core(await modulePromise);
  }
  class Core{
    constructor(module){this.module=module;this.signature="";this.resetNeeded=true;this.input=module._ys_input_ptr();this.result=module._ys_result_ptr()>>2;}
    invalidate(){this.resetNeeded=true;}
    activate(settings,area,fps){
      const signature=JSON.stringify([area.winx,area.winy,area.estimateDx,area.estimateDy,settings.trust,settings.stab,settings.cutoff,settings.damping,settings.dxmax,settings.dymax]);
      if(owner!==this||signature!==this.signature){
        const code=this.module._ys_configure(area.winx,area.winy,area.estimateDx,area.estimateDy,settings.trust,settings.stab,settings.cutoff,settings.damping,settings.dxmax,settings.dymax,fps);
        if(code!==0)throw new Error("core-configuration-failed: "+code);
        owner=this;this.signature=signature;this.resetNeeded=false;
      }else if(this.resetNeeded){this.module._ys_reset();this.resetNeeded=false;}
      this.module._ys_set_fps(fps);
    }
    process(){
      this.module._ys_process();const s=this.module.HEAPF32.subarray(this.result,this.result+12);
      return {dx:s[0],dy:s[1],trust:s[2],mapX:s[3],mapY:s[4],valid:!!s[5],frame:s[6],base:s[7],reason:s[8],change:s[9],deviation:s[10]};
    }
  }
  class LumaReader{
    constructor(){this.bytes=new Uint8Array(0);this.canvas=document.createElement("canvas");this.ctx=this.canvas.getContext("2d",{willReadFrequently:true,alpha:false});this.format="";}
    async read(frame,area,core){
      const rect=frame.visibleRect,format=frame.format||"";
      const native8=["I420","I420A","I422","I444","NV12"].includes(format);
      const native16=/^I4(?:20|22|44)P(?:10|12)$/.test(format);
      if(native8||native16){
        const wantedX=rect.x+area.left,wantedY=rect.y+area.top;
        const x=Math.floor(wantedX/2)*2,y=Math.floor(wantedY/2)*2;
        const width=Math.ceil((wantedX+area.winx-x)/2)*2,height=Math.ceil((wantedY+area.winy-y)/2)*2;
        const crop={x,y,width,height};
        if(x>=rect.x&&y>=rect.y&&x+width<=rect.x+rect.width&&y+height<=rect.y+rect.height){
          const size=frame.allocationSize({rect:crop});
          if(this.bytes.length<size)this.bytes=new Uint8Array(size);
          const layout=await frame.copyTo(this.bytes,{rect:crop});
          const offsetX=wantedX-x,offsetY=wantedY-y,plane=layout[0],target=core.module.HEAPU8;
          if(native8){
            for(let row=0;row<area.winy;row++){
              const p=plane.offset+(row+offsetY)*plane.stride+offsetX;
              target.set(this.bytes.subarray(p,p+area.winx),core.input+row*area.winx);
            }
          }else{
            const shift=format.endsWith("10")?2:4;
            for(let row=0;row<area.winy;row++)for(let col=0;col<area.winx;col++){
              const p=plane.offset+(row+offsetY)*plane.stride+(col+offsetX)*2;
              target[core.input+row*area.winx+col]=Math.min(255,((this.bytes[p]|this.bytes[p+1]<<8)+(1<<(shift-1)))>>shift);
            }
          }
          this.format=format+" / Y";return;
        }
      }
      // RGB-backed frames use the same captured VideoFrame, never the moving
      // HTMLVideoElement. GPU YUV frames normally take the direct-luma path.
      if(this.canvas.width!==area.winx||this.canvas.height!==area.winy){this.canvas.width=area.winx;this.canvas.height=area.winy;}
      const sx=frame.displayWidth/rect.width,sy=frame.displayHeight/rect.height;
      this.ctx.drawImage(frame,area.left*sx,area.top*sy,area.winx*sx,area.winy*sy,0,0,area.winx,area.winy);
      const rgba=this.ctx.getImageData(0,0,area.winx,area.winy).data,target=core.module.HEAPU8;
      const matrix=frame.colorSpace?.matrix,sd=matrix==="smpte170m"||matrix==="bt470bg"||(!matrix&&rect.height<=576);
      const r=sd ? .299 : .2126,g=sd ? .587 : .7152,b=sd ? .114 : .0722;
      const full=frame.colorSpace?.fullRange===true,scale=full?1:219/255,black=full?0:16;
      for(let i=0,p=0;i<area.winx*area.winy;i++,p+=4)target[core.input+i]=Math.max(0,Math.min(255,Math.round(black+scale*(r*rgba[p]+g*rgba[p+1]+b*rgba[p+2]))));
      this.format=(format||"RGB")+" → Y";
    }
    reset(){this.canvas.width=this.canvas.width;}
  }
  class Renderer{
    constructor(video,player){
      this.video=video;this.player=player;
      this.host=document.createElement("div");this.host.id="yt-steady-surface";
      this.host.style.cssText="position:absolute;pointer-events:none;z-index:1;background:#000;overflow:hidden;display:none;";
      this.canvas=document.createElement("canvas");this.canvas.id="yt-steady-output";
      this.canvas.style.cssText="position:absolute;pointer-events:none;display:block;";
      this.context=this.canvas.getContext("2d",{alpha:false,desynchronized:true});
      if(!this.context)throw new Error("canvas-context-unavailable");
      this.host.append(this.canvas);this.lastLayout="";this.active=false;this.frame=null;
    }
    sync(zoom){
      const video=this.video,parent=video.offsetParent&&this.player.contains(video.offsetParent)?video.offsetParent:this.player;
      if(this.host.parentElement!==parent)parent.append(this.host);
      const cs=getComputedStyle(video),w=video.clientWidth,h=video.clientHeight;
      const displayW=this.frame?.displayWidth||video.videoWidth,displayH=this.frame?.displayHeight||video.videoHeight;
      if(!w||!h||!displayW||!displayH)return;
      const factor=cs.objectFit==="cover"?Math.max(w/displayW,h/displayH):Math.min(w/displayW,h/displayH);
      const cw=displayW*factor,ch=displayH*factor;
      const transform=(cs.transform==="none"?"":cs.transform+" ")+`scale(${zoom})`;
      const layout=JSON.stringify([video.offsetLeft,video.offsetTop,w,h,cw,ch,transform,cs.transformOrigin,cs.translate,cs.rotate,cs.scale,cs.filter,cs.opacity]);
      if(layout===this.lastLayout)return;this.lastLayout=layout;
      Object.assign(this.host.style,{left:video.offsetLeft+"px",top:video.offsetTop+"px",width:w+"px",height:h+"px",transform,transformOrigin:cs.transformOrigin,translate:cs.translate,rotate:cs.rotate,scale:cs.scale,borderRadius:cs.borderRadius});
      Object.assign(this.canvas.style,{left:(w-cw)/2+"px",top:(h-ch)/2+"px",width:cw+"px",height:ch+"px",filter:cs.filter,opacity:cs.opacity});
    }
    draw(frame,motion,settings,time){
      const width=frame.visibleRect.width,height=frame.visibleRect.height;
      if(this.canvas.width!==width||this.canvas.height!==height){this.canvas.width=width;this.canvas.height=height;}
      this.frame={displayWidth:frame.displayWidth,displayHeight:frame.displayHeight};
      this.sync(settings.zoom);
      const ctx=this.context,x=settings.subpixel?motion.mapX:Math.round(motion.mapX),y=settings.subpixel?motion.mapY:Math.round(motion.mapY);
      ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle="#000";ctx.fillRect(0,0,width,height);
      ctx.imageSmoothingEnabled=!!settings.subpixel;ctx.imageSmoothingQuality="low";
      ctx.drawImage(frame,-x,-y,width,height);
      this.canvas.dataset.frame=JSON.stringify({time,mapX:x,mapY:y,frame:motion.frame,valid:motion.valid});
      this.host.style.display="block";this.active=true;
    }
    hide(){this.host.style.display="none";this.active=false;}
    destroy(){this.host.remove();}
  }
  root.YTSteadyPipeline={createCore,exclusive,LumaReader,Renderer};
})(globalThis);
