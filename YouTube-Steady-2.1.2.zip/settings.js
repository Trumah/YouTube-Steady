/* User parameters retain DePan names and source-pixel units. GPL-2.0. */
(function(root){
  "use strict";
  const I=root.YTSteadyI18n||(typeof module!=="undefined"&&module.exports?require("./i18n.js"):null);
  const fields={
    zoom:{value:1.06,min:1,max:1.25,step:.01},
    cutoff:{value:1.25,min:.2,max:5,step:.05},
    damping:{value:1,min:.25,max:3,step:.05},
    dxmax:{value:128,min:0,max:512,step:1},
    dymax:{value:128,min:0,max:512,step:1},
    trust:{value:4,min:.1,max:30,step:.1},
    stab:{value:1,min:0,max:5,step:.1},
    winx:{value:512,min:64,max:1024,step:2},
    winy:{value:512,min:64,max:1024,step:2},
    estimateDx:{value:192,min:0,max:511,step:1},
    estimateDy:{value:192,min:0,max:511,step:1},
    subpixel:{value:1,min:0,max:1,step:1}
  };
  const defaults=Object.freeze({schema:3,language:"auto",enabled:true,...Object.fromEntries(Object.entries(fields).map(([k,v])=>[k,v.value]))});
  function normalize(value){
    const result={...defaults,language:I?I.normalizeChoice(value?.language):"auto",enabled:typeof value?.enabled==="boolean"?value.enabled:true};
    for(const [key,spec]of Object.entries(fields)){
      let n=typeof value?.[key]==="number"?value[key]:spec.value;
      if(!Number.isFinite(n))n=spec.value;
      n=Math.max(spec.min,Math.min(spec.max,n));
      if(["winx","winy"].includes(key))n=Math.floor(n/2)*2;
      else if(spec.step===1)n=Math.round(n);
      result[key]=Math.round(n*10000)/10000;
    }
    return result;
  }
  function effective(settings,width,height){
    const winx=Math.min(settings.winx,Math.floor(width/2)*2),winy=Math.min(settings.winy,Math.floor(height/2)*2);
    if(winx<32||winy<32)throw new Error("source-dimensions-too-small");
    return {winx,winy,estimateDx:Math.min(settings.estimateDx,winx/2-1),estimateDy:Math.min(settings.estimateDy,winy/2-1),
      left:Math.floor((width-winx)/2),top:Math.floor((height-winy)/2)};
  }
  const api={fields,defaults,normalize,effective};root.YTSteadySettings=api;
  if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(globalThis);
