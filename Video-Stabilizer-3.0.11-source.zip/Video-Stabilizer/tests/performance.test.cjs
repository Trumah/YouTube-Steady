"use strict";
const test=require("node:test"),assert=require("node:assert/strict"),{Monitor}=require("../extension/performance.js");
function stream(){const monitor=new Monitor(),s={now:2000,eligible:true,seeking:false,waiting:false,bufferAhead:5,outputFrames:0,sourceFrames:0,dropped:0,busyFrames:0,mediaTime:0,targetFps:60,jobMs:5,p95Ms:7};monitor.sample(s);return {monitor,s,step(patch={},ms=1000){Object.assign(s,patch);s.now+=ms;s.mediaTime+=ms/1000;s.outputFrames+=(patch.output??60)*ms/1000;s.sourceFrames+=(patch.frames??60)*ms/1000;s.dropped+=(patch.drop??0)*ms/1000;s.busyFrames+=(patch.busy??0)*ms/1000;return monitor.sample(s);}};}
test("successful output stays healthy despite recovered callback gaps and different source rates",()=>{
  for(const fps of [24,30,60,120]){const t=stream();for(let n=0;n<20;n++)assert.equal(t.step({targetFps:fps,output:fps,frames:fps,deliveryMisses:10000}).active,false);}
});
test("sustained processing deficit enters after five valid seconds and recovers only after ten healthy seconds",()=>{
  const t=stream();for(let n=0;n<4;n++)assert.equal(t.step({output:40,jobMs:20,p95Ms:24,busy:15}).active,false);
  const warning=t.step({output:40,jobMs:20,p95Ms:24,busy:15});assert.equal(warning.kind,"processing");assert.equal(warning.episode,1);
  for(let n=0;n<9;n++)assert.equal(t.step({output:60,jobMs:5,p95Ms:7,busy:0}).active,true);
  t.step({output:60,jobMs:5,p95Ms:7,busy:0});assert.equal(t.monitor.status().active,false);assert.equal(t.monitor.status().recoveredEpisode,1);
});
test("brief deficits, neutral recovery rates and discontinuous counters do not flicker warnings",()=>{
  const t=stream();for(let n=0;n<3;n++)t.step({output:40});for(let n=0;n<8;n++)t.step({output:60});assert.equal(t.monitor.status().active,false);
  for(let n=0;n<8;n++)t.step({output:40});assert.equal(t.monitor.status().kind,"unknown");
  for(let n=0;n<15;n++)t.step({output:55});assert.equal(t.monitor.status().active,true);
  t.step({outputFrames:-60,sourceFrames:-60,output:0,frames:0});assert.equal(t.monitor.status().active,true,"counter reset must not claim recovery");
});
test("source drops and low buffered data get distinct advice without blaming the network",()=>{
  const source=stream();for(let n=0;n<6;n++)source.step({output:50,drop:10});assert.equal(source.monitor.status().kind,"source");
  const buffering=stream();for(let n=0;n<5;n++)buffering.step({output:0,frames:0,waiting:true,bufferAhead:0});assert.equal(buffering.monitor.status().kind,"buffering");
  const decoding=stream();for(let n=0;n<6;n++)decoding.step({output:0,frames:0,waiting:true,bufferAhead:4});assert.equal(decoding.monitor.status().kind,"unknown");
});
test("a fixed target stays healthy when rate conversion loses source frames, while real output stalls still warn",()=>{
  const fixed=stream();
  for(let n=0;n<10;n++)assert.equal(fixed.step({fixedRate:true,targetFps:30,output:30,frames:78,drop:18}).active,false);
  for(let n=0;n<5;n++)fixed.step({output:18,frames:78,drop:18});
  assert.equal(fixed.monitor.status().kind,"source");
  const low=stream();for(let n=0;n<15;n++)assert.equal(low.step({fixedRate:true,targetFps:1,output:n%3===0?0:n%3===1?2:1}).active,false);
});
test("display-limited Original tolerates the expected dropped frames and identifies a real source shortfall",()=>{
  const display=stream();
  for(let n=0;n<10;n++)assert.equal(display.step({displayLimited:true,frames:78,drop:18}).active,false);
  for(let n=0;n<5;n++)display.step({output:48,frames:78,drop:30});
  assert.equal(display.monitor.status().kind,"source");
  for(let n=0;n<10;n++)display.step({frames:78,drop:18});
  assert.equal(display.monitor.status().active,false);
  const ordinary=stream();
  for(let n=0;n<5;n++)ordinary.step({output:56,frames:60,drop:4});
  assert.equal(ordinary.monitor.status().kind,"source");
});
test("pause, background and seek time do not count, while short looping seeks preserve valid evidence",()=>{
  const t=stream();for(let n=0;n<3;n++)t.step({output:40});t.monitor.suspend(t.s.now,true,1000);
  t.step({eligible:false,seeking:true,output:0,frames:0});t.step({eligible:true,seeking:false,output:40});for(let n=0;n<3;n++)t.step({output:40});assert.equal(t.monitor.status().active,true);
  const episode=t.monitor.status().episode;for(let n=0;n<20;n++)t.step({eligible:false,seeking:false,output:0,frames:0});assert.equal(t.monitor.status().active,true);assert.equal(t.monitor.status().episode,episode);
});
test("new settings clear old evidence and a later incident gets a new episode",()=>{
  const t=stream();for(let n=0;n<7;n++)t.step({output:40});assert.equal(t.monitor.status().episode,1);t.monitor.clear(t.s.now);assert.equal(t.monitor.status().active,false);
  for(let n=0;n<4;n++)assert.equal(t.step({output:40}).active,false);for(let n=0;n<5;n++)t.step({output:40});assert.equal(t.monitor.status().episode,2);
});
test("long scheduling gaps are excluded rather than converted to a performance incident",()=>{
  const t=stream();t.step({output:0},60000);for(let n=0;n<4;n++)assert.equal(t.step({output:60}).active,false);assert.equal(t.monitor.status().recoveredEpisode,0);
});
