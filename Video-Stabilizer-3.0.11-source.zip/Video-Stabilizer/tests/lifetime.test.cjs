"use strict";
const test=require("node:test"),assert=require("node:assert/strict"),fs=require("node:fs"),path=require("node:path"),vm=require("node:vm");
const S=require("../extension/settings.js"),R=require("../extension/regions.js"),F=require("../extension/profiles.js"),W=require("../extension/performance.js");
const controllerSource=fs.readFileSync(path.join(__dirname,"../extension/controller.js"),"utf8"),rendererSource=fs.readFileSync(path.join(__dirname,"../extension/renderer.js"),"utf8"),platformSource=fs.readFileSync(path.join(__dirname,"../extension/platform.js"),"utf8");
const wasm=fs.readFileSync(path.join(__dirname,"../extension/depan-core.wasm")),factory=require("../extension/depan-core.js");
const settle=()=>new Promise(resolve=>setImmediate(resolve));
function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};}
class Target{
  constructor(){this.listeners=new Map();}
  addEventListener(name,fn){if(!this.listeners.has(name))this.listeners.set(name,new Set());this.listeners.get(name).add(fn);}
  removeEventListener(name,fn){this.listeners.get(name)?.delete(fn);}
  emit(name,event={}){for(const fn of [...this.listeners.get(name)||[]])fn(event);}
  count(){return [...this.listeners.values()].reduce((n,set)=>n+set.size,0);}
}
function environment(options={}){
  const h={views:[],overlays:[],renderers:[],observers:[],resizeObservers:[],intervals:new Map(),timeouts:new Map(),callbacks:new Map(),animationFrames:new Map(),frames:[],drawn:[],analysisRates:[],writes:0,disposed:0,draws:0,loads:0,id:"test-extension",throwId:false};let timer=0;
  h.saved=S.normalize({...S.defaults,centerRatio:33,trust:6,stab:2,...options.settings});h.store={ytSteadySettings:h.saved,[F.keys.personal]:F.record(h.saved),...options.store};h.setCalls=[];h.rejectRead=!!options.rejectRead;
  h.document=new Target();h.document.documentElement={};h.document.hidden=false;h.window=new Target();
  h.video=new Target();Object.assign(h.video,{readyState:4,paused:true,seeking:false,ended:false,isConnected:true,currentSrc:"fixture",currentTime:3,videoWidth:1920,videoHeight:1080,playbackRate:1,
    getVideoPlaybackQuality:()=>({totalVideoFrames:90,droppedVideoFrames:0}),requestVideoFrameCallback:fn=>{const id=++timer;h.callbacks.set(id,fn);return id;},cancelVideoFrameCallback:id=>h.callbacks.delete(id)});
  h.player={querySelector:()=>h.video,classList:{contains:()=>false}};h.hasPlayer=options.hasPlayer!==false;
  h.document.querySelector=()=>h.hasPlayer?h.player:null;
  const event=()=>{const e=new Set();return {handlers:e,addListener:fn=>e.add(fn),removeListener:fn=>{if(h.throwRemove)throw Error("Extension context invalidated.");e.delete(fn);}};};
  const runtime={get id(){if(h.throwId)throw Error("Extension context invalidated.");return h.id;},getURL:name=>"chrome-extension://test-extension/"+name,onMessage:event()};
  const storage={onChanged:event(),local:{get:async names=>{if(h.rejectRead)throw Error("read failed");if(h.getHook)return h.getHook(names);if(options.storagePending)return options.storagePending.promise;return Object.fromEntries((Array.isArray(names)?names:[names]).filter(k=>k in h.store).map(k=>[k,structuredClone(h.store[k])]));},set:async value=>{
    h.writes++;h.setCalls.push(structuredClone(value));if(h.invalidateOnSave){h.id=undefined;throw Error("Extension context invalidated.");}if(h.rejectSave)throw Error("write failed");if(h.setPending)await h.setPending.promise;Object.assign(h.store,structuredClone(value));h.saved=h.store.ytSteadySettings;
  }}};
  const result=()=>({valid:true,frame:1,mapX:0,mapY:0,reason:0}),core={invalidate(){},activate(profile,area,fps){h.analysisRates.push(fps);},processSingle:result,processRegions:result};
  class UI{
    constructor(player,actions){this.actions=actions;this.host={dataset:{},removed:false,remove(){this.removed=true;}};this.elements={panel:{hidden:true},status:{textContent:""}};h.views.push(this);}
    refreshFields(value){this.fields={...value};}refreshEntry(){}translate(){}setEffective(){}layout(){}togglePanel(value){this.elements.panel.hidden=!value;}publish(value){this.state=value;}
    stageProfile(value){this.refreshFields({...this.actions.settings(),...F.snapshot(value)});this.actions.draft(this.fields,"all");}
  }
  class Reader{constructor(){this.format="Y";}reset(){}read(){return options.readPending?.promise||Promise.resolve();}readRegions(){return [];}}
  class Renderer{constructor(){this.active=false;this.removed=false;this.canvas=new Target();h.renderers.push(this);}draw(frame,motion,profile,time,retiming){assert.equal(frame.closed,0);if(h.blockDraw)throw Error("drawing failed");h.drawn.push({frame,time,retiming});h.draws++;this.retimed=!!retiming;this.active=true;this.visible=true;}sync(){}hide(){this.active=false;this.visible=false;}destroy(){this.removed=true;this.active=false;}}
  const pipeline={createCore:async(asset,signal)=>{h.loads++;h.signal=signal;h.asset=asset("depan-core.wasm");return options.corePending?options.corePending.promise:core;},exclusive:fn=>Promise.resolve().then(fn),dispose:()=>h.disposed++,LumaReader:Reader,Renderer};
  class Preview{constructor(){h.overlays.push(this);}show(){this.visible=true;}update(){}hide(){this.visible=false;}destroy(){this.hide();this.removed=true;}}
  h.context=vm.createContext({YTSteadySettings:S,YTSteadyProfiles:F,YTSteadyPerformance:W,YTSteadyPipeline:pipeline,YTSteadyPlayerUI:UI,YTSteadyOverlay:Preview,YTSteadyI18n:{code:"en",dir:"ltr",setLanguage(){},t:key=>key},chrome:{runtime,storage},
    location:{hostname:"www.youtube.com",pathname:"/watch",search:"?v=synthetic",href:"https://www.youtube.com/watch?v=synthetic"},document:h.document,window:h.window,URL,URLSearchParams,AbortController,performance:options.clock||performance,
    setTimeout:fn=>{const id=++timer;h.timeouts.set(id,fn);return id;},clearTimeout:id=>h.timeouts.delete(id),setInterval:fn=>{const id=++timer;h.intervals.set(id,fn);return id;},clearInterval:id=>h.intervals.delete(id),
    requestAnimationFrame:fn=>{const id=++timer;h.animationFrames.set(id,fn);return id;},cancelAnimationFrame:id=>h.animationFrames.delete(id),
    MutationObserver:class{constructor(fn){this.fn=fn;this.disconnected=false;h.observers.push(this);}observe(){}disconnect(){this.disconnected=true;}},
    ResizeObserver:class{constructor(fn){this.fn=fn;this.disconnected=false;h.resizeObservers.push(this);}observe(){}disconnect(){this.disconnected=true;}},
    VideoFrame:class{constructor(){if(h.blockCapture)throw Object.assign(Error("Frame not available yet"),{name:"InvalidStateError"});this.timestamp=h.frameTimestamp??(options.secondsTimestamp?Math.floor(h.video.currentTime):Math.round(h.video.currentTime*1000000));this.visibleRect={width:1920,height:1080};this.closed=0;h.frames.push(this);}close(){this.closed++;}}
  });
  if(options.browserOnly){h.context.browser=h.context.chrome;delete h.context.chrome;}
  if(options.hostname)h.context.location.hostname=options.hostname;
  vm.runInContext(platformSource,h.context);
  h.run=()=>vm.runInContext(controllerSource,h.context);h.tick=()=>{for(const fn of [...h.intervals.values()])fn();};h.flush=()=>{const tasks=[...h.timeouts.values()];h.timeouts.clear();for(const fn of tasks)fn();};h.external=values=>{const changes={};for(const [key,value]of Object.entries(values)){changes[key]={oldValue:h.store[key],newValue:value};if(value===undefined)delete h.store[key];else h.store[key]=structuredClone(value);}for(const fn of storage.onChanged.handlers)fn(changes,"local");};h.core=core;h.storage=storage;h.runtime=runtime;h.run();return h;
}
test("browser-only mobile context preserves Apply, reload, and invalidation recovery",async()=>{
  const h=environment({browserOnly:true,hostname:"m.youtube.com"});await settle();assert.equal(h.views.length,1);assert.equal(h.views[0].state.active,true);
  await h.views[0].actions.save({cutoff:.7},true);await settle();assert.equal(F.decode(h.store).applied.cutoff,.7);
  const fresh=environment({browserOnly:true,hostname:"m.youtube.com",store:h.store});await settle();assert.equal(fresh.views[0].state.cutoff,.7);
  h.id=undefined;h.tick();assertStopped(h);fresh.id=undefined;fresh.tick();assertStopped(fresh);
});
test("native fullscreen and picture-in-picture stop processing and resume without altering settings",async()=>{
  const h=environment();await settle();const saved=JSON.stringify(h.store),count=h.frames.length;
  h.video.webkitDisplayingFullscreen=true;h.video.emit("webkitbeginfullscreen");await settle();
  assert.equal(h.views[0].state.active,false);assert.equal(h.views[0].state.statusKey,"statusOriginalPresentation");assert.equal(h.callbacks.size,0);assert.equal(h.timeouts.size,0);
  h.tick();assert.equal(h.frames.length,count);assert.equal(h.views[0].state.performanceWarning.visible,false);
  h.video.webkitDisplayingFullscreen=false;h.video.emit("webkitendfullscreen");await settle();assert.equal(h.views[0].state.active,true);
  h.document.pictureInPictureElement=h.video;h.video.emit("enterpictureinpicture");assert.equal(h.views[0].state.active,false);
  h.document.pictureInPictureElement=null;h.video.emit("leavepictureinpicture");await settle();assert.equal(h.views[0].state.active,true);assert.equal(JSON.stringify(h.store),saved);assert.equal(h.writes,0);
  h.id=undefined;h.tick();assertStopped(h);
});
test("broken whole-second timestamps keep callback playback progressing and cancel the polling watchdog",async()=>{
  const h=environment({secondsTimestamp:true,browserOnly:true});await settle();h.video.paused=false;h.video.emit("play");const first=h.draws;
  for(let n=1;n<=8;n++){h.video.currentTime=3+n/30;fireFirst(h.callbacks,n*1000/30,{mediaTime:h.video.currentTime,presentedFrames:90+n});await settle();}
  h.tick();assert.equal(h.draws-first,8);assert.equal(h.views[0].state.scheduler,"video-frame-callback");assert.equal(h.timeouts.size,0);assert.equal(h.callbacks.size,1);assert.ok(h.frames.every(f=>f.closed===1));
  h.video.paused=true;h.video.emit("pause");h.id=undefined;h.tick();assertStopped(h);
});
function assertStopped(h){
  assert.ok(h.views.every(v=>v.host.removed));assert.ok(h.renderers.every(r=>r.removed&&!r.active));assert.equal(h.intervals.size,0);assert.equal(h.timeouts.size,0);assert.equal(h.callbacks.size,0);assert.equal(h.animationFrames.size,0);
  assert.ok(h.overlays.every(o=>o.removed&&!o.visible));
  assert.ok(h.observers.every(o=>o.disconnected));assert.ok(h.resizeObservers.every(o=>o.disconnected));assert.equal(h.video.count()+h.document.count()+h.window.count(),0);assert.equal(h.disposed,1);
}
function fireFirst(tasks,...args){const [id,callback]=tasks.entries().next().value;tasks.delete(id);callback(...args);return callback;}
test("fixed 30 fps captures and analyzes one frame per two display refreshes at 1.3×",async()=>{
  let now=0;const h=environment({clock:{now:()=>now},settings:{outputRate:30}});await settle();
  const view=h.views[0],baseline=h.draws,analysisBaseline=h.analysisRates.length,captureBaseline=h.frames.length;
  h.video.playbackRate=1.3;h.video.paused=false;h.video.emit("play");
  const drawnAt=[];
  for(let n=1;n<=120;n++){
    now=n*1000/60;h.video.currentTime=3+now*.0013;
    fireFirst(h.callbacks,now,{mediaTime:h.video.currentTime,presentedFrames:90+n});await settle();
    const before=h.draws;fireFirst(h.animationFrames,now);if(h.draws>before)drawnAt.push(n);
    assert.equal(h.frames.filter(frame=>!frame.closed).length,n%2?0:1);
  }
  h.tick();assert.equal(h.draws-baseline,60);assert.ok(drawnAt.slice(1).every((value,i)=>value-drawnAt[i]===2));
  assert.equal(h.analysisRates.length-analysisBaseline,61);assert.equal(h.frames.length-captureBaseline,61);
  assert.ok(h.drawn.every(({frame,time})=>frame.timestamp===Math.round(time*1e6)));
  assert.equal(view.state.displayHz,60);assert.equal(view.state.outputFps,30);assert.ok(Math.abs(view.state.analysisFps-30)<.5);
  assert.ok(Math.abs(view.state.mediaFps-30/1.3)<.01);
  const pending=h.frames.at(-1);h.video.paused=true;h.video.emit("pause");await settle();
  assert.equal(pending.closed,1);assert.equal(h.animationFrames.size,0);assert.equal(h.drawn.at(-1).frame.timestamp,pending.timestamp);
  h.id=undefined;h.tick();assertStopped(h);assert.ok(h.frames.every(frame=>frame.closed===1));
});
test("fixed 1 fps schedules work near the output slot and retains motion history across skipped media frames",async()=>{
  let now=0;const h=environment({clock:{now:()=>now},settings:{outputRate:1}});await settle();
  const view=h.views[0],captureBaseline=h.frames.length,drawBaseline=h.draws;
  h.video.playbackRate=1.3;h.video.paused=false;h.video.emit("play");
  for(let n=1;n<=185;n++){
    now=n*1000/60;h.video.currentTime=3+now*.0013;
    fireFirst(h.callbacks,now,{mediaTime:h.video.currentTime,presentedFrames:90+n});await settle();
    fireFirst(h.animationFrames,now);
  }
  h.tick();assert.equal(h.frames.length-captureBaseline,4);assert.equal(h.draws-drawBaseline,4);
  assert.equal(view.state.resets,1);assert.equal(view.state.error,false);assert.equal(view.state.outputFps,1);
  assert.ok(h.video.currentTime-h.drawn.at(-1).time<.15,"the frame should come from near its presentation slot");
  h.id=undefined;h.tick();assertStopped(h);assert.ok(h.frames.every(frame=>frame.closed===1));
});
test("fixed 30 fps retimes analyzed frames without more core calls and clears timing on rate change",async()=>{
  let now=0,media=3,frameNumber=0,lastTimestamp=null,frame=1,previous=3;
  const h=environment({clock:{now:()=>now},settings:{outputRate:30}});await settle();const view=h.views[0];
  h.core.processRegions=h.core.processSingle=()=>{
    const time=h.frameTimestamp/1e6,motion={valid:true,frame:++frame,dx:-200*(time-previous),dy:0,mapX:0,mapY:0,reason:0};previous=time;return motion;
  };
  h.video.playbackRate=1.3;h.video.paused=false;h.video.emit("play");
  async function advance(speed){
    const baseline=h.draws,captures=h.frames.length,work=h.analysisRates.length;
    for(let n=1;n<=300;n++){
      now+=1000/60;media+=speed/60;
      h.video.currentTime=media;h.frameTimestamp=Math.round((3+Math.floor((media-3)*60+1e-6)/60)*1e6);
      if(h.frameTimestamp!==lastTimestamp){
        lastTimestamp=h.frameTimestamp;
        fireFirst(h.callbacks,now,{mediaTime:h.frameTimestamp/1e6,presentedFrames:++frameNumber});await settle();
      }
      fireFirst(h.animationFrames,now);
    }
    h.tick();assert.equal(view.state.requestedFps,30);
    assert.ok(Math.abs(view.state.outputFps-view.state.requestedFps)<.6);
    assert.ok(h.frames.length-captures<=h.draws-baseline+3);
    assert.ok(h.analysisRates.length-work<=h.draws-baseline+1);
    const outputs=h.drawn.slice(baseline);
    assert.ok(outputs.filter(item=>item.retiming&&Math.abs(item.retiming.x)>.1).length>50);
    assert.equal(outputs[0].retiming,null);
  }
  await advance(1.3);
  h.video.playbackRate=.65;h.video.emit("ratechange");await advance(.65);
  h.id=undefined;h.tick();assertStopped(h);assert.ok(h.frames.every(frame=>frame.closed===1));
});
test("fixed pacing discards queued images on seek, restores the original on draw failure, and retries",async()=>{
  const h=environment({settings:{outputRate:30}});await settle();const view=h.views[0];
  h.video.paused=false;h.video.emit("play");h.video.currentTime=3.03;
  fireFirst(h.callbacks,20,{mediaTime:3.03,presentedFrames:91});await settle();
  const pending=h.frames.at(-1);assert.equal(pending.closed,0);
  h.video.seeking=true;h.video.emit("seeking");assert.equal(pending.closed,1);assert.equal(h.animationFrames.size,0);
  h.video.currentTime=10;h.video.seeking=false;h.video.emit("seeked");
  fireFirst(h.callbacks,40,{mediaTime:10,presentedFrames:92});await settle();
  h.blockDraw=true;fireFirst(h.animationFrames,40);
  assert.equal(view.state.error,true);assert.equal(view.state.active,false);assert.equal(h.animationFrames.size,0);assert.equal(h.callbacks.size,0);assert.ok(h.frames.every(frame=>frame.closed===1));
  h.blockDraw=false;view.actions.retryProcessing();
  fireFirst(h.callbacks,60,{mediaTime:10,presentedFrames:93});await settle();fireFirst(h.animationFrames,60);
  assert.equal(view.state.active,true);assert.equal(view.state.outputRate,30);assert.equal(h.drawn.at(-1).time,10);
  await view.actions.save({outputRate:0},true);assert.equal(h.animationFrames.size,0);assert.ok(h.frames.every(frame=>frame.closed===1));
  h.id=undefined;h.tick();assertStopped(h);
});
test("a saved 30 fps cap follows a 25 fps source without a false warning or a settings write",async()=>{
  let now=0;const h=environment({clock:{now:()=>now},settings:{outputRate:30}});await settle();
  const view=h.views[0],saved=JSON.stringify(h.store),quality={totalVideoFrames:0,droppedVideoFrames:0};
  h.video.getVideoPlaybackQuality=()=>quality;h.video.paused=false;h.video.emit("play");
  for(let tick=1;tick<=600;tick++){
    now=tick*1000/60;h.video.currentTime=3+now/1000;
    const index=Math.floor(now/40+1e-8);
    if(index>quality.totalVideoFrames){
      quality.totalVideoFrames=index;h.frameTimestamp=3000000+index*40000;
      fireFirst(h.callbacks,now,{mediaTime:h.frameTimestamp/1e6,presentedFrames:index});await settle();
    }
    fireFirst(h.animationFrames,now);if(tick%60===0)h.tick();
  }
  assert.equal(view.state.originalFps,25);assert.equal(view.state.sourcePlaybackFps,25);
  assert.ok(Math.abs(view.state.outputFps-25)<.3);assert.equal(view.state.performanceWarning.active,false);
  assert.equal(view.state.outputRate,30);assert.equal(h.writes,0);assert.equal(JSON.stringify(h.store),saved);
  h.video.playbackRate=1.3;h.video.emit("ratechange");h.tick();
  assert.equal(view.state.originalFps,25);assert.equal(view.state.sourcePlaybackFps,32.5);
  h.context.location.search="?v=next";h.tick();assert.equal(view.state.originalFps,0);assert.equal(view.state.outputRate,30);
  h.id=undefined;h.tick();assertStopped(h);assert.ok(h.frames.every(frame=>frame.closed===1));
});
test("Original with the panel closed checks 60 Hz output at 1.3×, warns on a deficit and recovers",async()=>{
  let now=0,tick=0;const h=environment({clock:{now:()=>now}});await settle();
  const view=h.views[0],quality={totalVideoFrames:0,droppedVideoFrames:0};h.video.getVideoPlaybackQuality=()=>quality;
  h.video.playbackRate=1.3;h.video.paused=false;h.video.emit("play");
  async function advance(seconds,missCallbacks=false){
    for(let n=0;n<seconds*60;n++){
      tick++;now=tick*1000/60;h.video.currentTime=3+now*.0013;
      quality.totalVideoFrames=Math.floor(tick*1.3+1e-6);quality.droppedVideoFrames=quality.totalVideoFrames-tick;
      h.frameTimestamp=3000000+Math.round(quality.totalVideoFrames*1000000/60);
      if(!missCallbacks||tick%4!==0){fireFirst(h.callbacks,now,{mediaTime:h.frameTimestamp/1e6,presentedFrames:tick,expectedDisplayTime:now+16});await settle();}
      if(h.animationFrames.size)fireFirst(h.animationFrames,now);
      if(tick%60===0)h.tick();
    }
  }
  assert.equal(view.elements.panel.hidden,true);
  await advance(10);
  assert.equal(view.state.sourcePlaybackFps,78);assert.equal(view.state.displayHz,60);
  assert.ok(Math.abs(view.state.performanceWarning.targetFps-60)<.01);
  assert.equal(view.state.outputFps,60);assert.equal(view.state.performanceWarning.active,false);
  await advance(5,true);assert.equal(view.state.performanceWarning.kind,"unknown");
  await advance(10);assert.equal(view.state.performanceWarning.active,false);
  assert.equal(view.state.outputRate,0);assert.equal(h.writes,0);
  h.id=undefined;h.tick();assertStopped(h);assert.ok(h.frames.every(frame=>frame.closed===1));
});
test("persistent output deficit reaches the warning UI without applying settings or resetting processing",async()=>{
  let now=0;const h=environment({clock:{now:()=>now}});await settle();const view=h.views[0],saved=JSON.stringify(h.store),profile=F.snapshot(view.state),q={totalVideoFrames:90,droppedVideoFrames:0};h.video.getVideoPlaybackQuality=()=>q;h.video.paused=false;h.video.emit("play");
  for(let second=0;second<8;second++){
    for(let n=1;n<=60;n++){
      now=second*1000+n*1000/60;
      if(n%4===0){h.video.currentTime=3+now/1000;h.frameTimestamp=Math.round(h.video.currentTime*1000000);q.totalVideoFrames+=2;fireFirst(h.callbacks,now,{mediaTime:h.video.currentTime,presentedFrames:q.totalVideoFrames,expectedDisplayTime:now+16});await settle();}
      if(h.animationFrames.size)fireFirst(h.animationFrames,now);
    }
    h.tick();
  }
  assert.equal(view.state.performanceWarning.kind,"unknown");assert.equal(view.state.performanceWarning.active,true);assert.equal(h.writes,0);assert.equal(JSON.stringify(h.store),saved);assert.ok(F.equal(view.state,profile));
  const resets=view.state.resets;view.actions.cancel();assert.equal(view.state.resets,resets);assert.equal(view.state.performanceWarning.active,true,"closing a clean panel must not reset the warning or analysis");
  h.video.paused=true;h.video.emit("pause");now+=60000;h.tick();assert.equal(view.state.performanceWarning.active,true);assert.equal(h.writes,0);
  await view.actions.save({enabled:false});assert.equal(view.state.performanceWarning.active,false);h.id=undefined;h.tick();assertStopped(h);
});
test("frame watchdog recovers absent video callbacks using native timestamps without processing duplicates",async()=>{
  const h=environment();await settle();const baseline=h.draws;h.video.paused=false;h.video.emit("play");
  for(const timestamp of [3016667,3033333,3050000]){h.frameTimestamp=timestamp;fireFirst(h.timeouts);await settle();assert.equal(h.callbacks.size,1);assert.equal(h.timeouts.size,1);}
  assert.equal(h.draws,baseline+3);fireFirst(h.timeouts);await settle();assert.equal(h.draws,baseline+3,"a second poll of one source frame cannot advance motion history");
  fireFirst(h.callbacks,performance.now(),{mediaTime:900,presentedFrames:1,expectedDisplayTime:performance.now()+16});await settle();assert.equal(h.draws,baseline+3,"late callback metadata cannot relabel or repeat the current source frame");
  h.tick();const state=h.views[0].state;assert.equal(state.mediaTime,3.05);assert.equal(state.fallbackFrames,3);assert.ok(state.duplicateFrames>=2);assert.ok(h.frames.every(f=>f.closed===1));
  const stale=h.timeouts.values().next().value;h.video.paused=true;h.video.emit("pause");assert.equal(h.timeouts.size,0);assert.equal(h.callbacks.size,0);const captures=h.frames.length;stale();await settle();assert.equal(h.frames.length,captures,"a cancelled timer cannot capture a paused frame");
});
test("frame watchdog stops for seeking, hidden pages, failures and disable, then resumes without duplicated work",async()=>{
  const h=environment();await settle();h.video.paused=false;h.video.emit("play");const running=()=>{assert.equal(h.timeouts.size,1);assert.equal(h.callbacks.size,1);},stopped=()=>{assert.equal(h.timeouts.size,0);assert.equal(h.callbacks.size,0);};running();
  h.video.seeking=true;h.video.emit("seeking");stopped();h.video.seeking=false;h.video.emit("seeked");running();
  h.document.hidden=true;h.document.emit("visibilitychange");stopped();h.document.hidden=false;h.document.emit("visibilitychange");running();
  h.renderers[0].canvas.emit("contextlost");stopped();h.views[0].actions.retryProcessing();await settle();running();
  await h.views[0].actions.save({enabled:false});stopped();await h.views[0].actions.save({enabled:true});await settle();running();
  h.id=undefined;h.tick();assertStopped(h);
});
test("a busy asynchronous capture stays bounded while watchdog ticks and closes after invalidation",async()=>{
  const pending=deferred(),h=environment({readPending:pending,settings:{mode:"single",sampleRatio:100}});await settle();assert.equal(h.frames.length,1);h.video.paused=false;h.video.emit("play");
  for(let i=0;i<4;i++)fireFirst(h.timeouts);assert.equal(h.frames.length,1);assert.equal(h.timeouts.size,1);assert.equal(h.callbacks.size,1);
  h.id=undefined;h.tick();pending.resolve();await settle();assertStopped(h);assert.equal(h.frames[0].closed,1);assert.equal(h.draws,0);
});
test("icon visibility and position save without resetting analysis; toolbar messages reopen a hidden entry",async()=>{
  const h=environment();await settle();const view=h.views[0],before=view.state.resets,draws=h.draws;
  await view.actions.save({iconHidden:true,iconPosition:{x:.3,y:.2}});assert.equal(view.state.resets,before);assert.equal(h.draws,draws);assert.equal(F.decode(h.store).preferences.iconHidden,true);assert.deepEqual(F.decode(h.store).preferences.iconPosition,{x:.3,y:.2});
  view.elements.panel.hidden=true;let reply;for(const handler of h.runtime.onMessage.handlers)handler({type:"yt-steady-panel"},{},value=>reply=value);
  assert.equal(reply.found,true);assert.equal(view.elements.panel.hidden,false);assert.equal(F.decode(h.store).preferences.iconHidden,true);assert.equal(view.state.resets,before);
});
test("extension disable removes paused UI, output, observers and callbacks; stale SPA events cannot resurrect it",async()=>{
  const h=environment();await settle();assert.equal(h.views.length,1);assert.ok(h.renderers[0].active);const saved=JSON.stringify(h.saved);
  h.id=undefined;h.tick();assertStopped(h);assert.ok(h.signal.aborted);assert.equal(h.writes,0);assert.equal(JSON.stringify(h.saved),saved);
  h.id="test-extension";h.document.emit("yt-navigate-finish");h.observers[0].fn();h.flush();h.tick();await settle();assert.equal(h.views.length,1);assertStopped(h);
});
test("invalidation during playback cancels the pending frame callback and closes every captured frame",async()=>{
  const h=environment();await settle();h.video.paused=false;h.video.emit("play");assert.equal(h.callbacks.size,1);
  h.id=undefined;h.video.emit("play");await settle();assertStopped(h);assert.ok(h.frames.every(f=>f.closed===1));
});
test("throwing invalidated Chrome getters and listener removals still clean the player",async()=>{
  const h=environment();await settle();h.throwId=h.throwRemove=true;assert.doesNotThrow(()=>h.tick());assertStopped(h);
});
test("disable while settings load is pending cannot create a late UI",async()=>{
  const pending=deferred(),h=environment({storagePending:pending});assert.equal(h.views.length,0);
  h.id=undefined;h.observers[0].fn();pending.resolve({ytSteadySettings:h.saved});await settle();assert.equal(h.views.length,0);assertStopped(h);
});
test("disable while WASM loads aborts loading and ignores its late result",async()=>{
  const pending=deferred(),h=environment({corePending:pending});await settle();assert.equal(h.loads,1);h.id=undefined;h.tick();assertStopped(h);
  pending.resolve(h.core);await settle();assert.equal(h.draws,0);assert.equal(h.views.length,1);assert.ok(h.signal.aborted);
});
test("disable during asynchronous frame readback closes the frame without drawing stale output",async()=>{
  const pending=deferred(),h=environment({readPending:pending,settings:{mode:"single",sampleRatio:100}});await settle();assert.equal(h.frames.length,1);assert.equal(h.frames[0].closed,0);
  h.id=undefined;h.tick();pending.resolve();await settle();assertStopped(h);assert.equal(h.draws,0);assert.equal(h.frames[0].closed,1);
});
test("an invalidated save stops the old context instead of presenting a live unsaved panel",async()=>{
  const h=environment();await settle();h.invalidateOnSave=true;await h.views[0].actions.save({language:"fr"});await settle();assertStopped(h);assert.equal(h.saved.centerRatio,33);
  await h.views[0].actions.save({language:"de"});assert.equal(h.writes,1);
});
test("ordinary save errors remain visible and recover without removing the interface",async()=>{
  const h=environment();await settle();h.rejectSave=true;await h.views[0].actions.save({language:"fr"});await settle();assert.equal(h.views[0].state.statusKey,"statusSaveFailed");assert.equal(h.views[0].host.removed,false);
  h.rejectSave=false;await h.views[0].actions.retryStorage();await settle();assert.equal(F.decode(h.store).preferences.language,"fr");assert.notEqual(h.views[0].elements.status.textContent,"statusSaveFailed");
});
test("player compensation off/on keeps its entry and custom settings; a fresh context restores the same settings",async()=>{
  const h=environment();await settle();await h.views[0].actions.save({enabled:false});await settle();assert.equal(h.views[0].host.removed,false);assert.equal(h.views[0].state.active,false);
  h.views[0].actions.draft({...h.views[0].state,cutoff:.7},"enabled");assert.equal(h.overlays[0].visible,false,"draft synchronization must not recreate the preview while disabled");
  await h.views[0].actions.save({enabled:true});await settle();assert.equal(h.views[0].state.active,true);assert.equal(h.views[0].state.centerRatio,33);
  h.video.videoWidth=1440;assert.equal(h.views[0].actions.dimensions().width,h.views[0].state.area.sourceWidth,"fields use analyzed source dimensions, not an anamorphic display width");
  h.id=undefined;h.tick();const fresh=environment({settings:h.saved});await settle();assert.equal(fresh.views.length,1);assert.equal(fresh.views[0].state.centerRatio,33);assert.equal(fresh.views[0].state.trust,6);assert.equal(fresh.views[0].state.active,true);
});
test("apply persists confirmed settings while cancel never changes My default or applied values",async()=>{
  const h=environment();await settle();const v=h.views[0],original=JSON.stringify(h.store[F.keys.personal]);
  await v.actions.save({centerRatio:44,zoom:1.005},true);await settle();assert.equal(v.state.centerRatio,44);assert.equal(h.writes,1);assert.equal(JSON.stringify(h.store[F.keys.personal]),original);assert.equal(F.decode(h.store).applied.centerRatio,44);
  const resets=v.state.resets;v.actions.draft(null,"zoom");assert.equal(v.state.profileDirty,true);v.actions.cancel();assert.equal(v.state.profileDirty,false);assert.equal(v.state.resets,resets);assert.equal(v.fields.zoom,1.005);
  await v.actions.save({language:"fr",iconHidden:true});v.actions.cancel();await settle();assert.equal(v.state.centerRatio,44);assert.equal(v.state.language,"fr");assert.equal(v.state.iconHidden,true);assert.equal(F.decode(h.store).personal.centerRatio,33);
});
test("Save as my default refuses drafts and stores only an explicitly applied snapshot",async()=>{
  const h=environment();await settle();const v=h.views[0],draft=S.normalize({...v.state,centerRatio:44,cutoff:.7});v.actions.draft(draft,"centerRatio");assert.equal(v.state.centerRatio,33);
  await v.actions.saveDefault(draft);assert.equal(h.writes,0);assert.equal(v.state.centerRatio,33);assert.equal(v.state.profileDirty,true);
  await v.actions.save(draft,true);await settle();const appliedResets=v.state.resets;await v.actions.saveDefault();assert.equal(v.state.centerRatio,44);assert.equal(v.state.cutoff,.7);assert.equal(v.state.profileDirty,false);assert.ok(F.equal(F.decode(h.store).personal,draft));assert.deepEqual(Object.keys(h.store[F.keys.personal]),["format","profile"]);assert.equal(v.state.resets,appliedResets);
  const writes=h.writes,resets=v.state.resets;await v.actions.saveDefault();assert.equal(h.writes,writes);assert.equal(v.state.resets,resets);
  v.actions.draft(null,"zoom");await v.actions.saveDefault();assert.equal(h.writes,writes,"an unresolved draft cannot silently save earlier values");
});
test("saving removes an old backup while restoring the current default remains local",async()=>{
  const h=environment();await settle();const v=h.views[0],old=JSON.stringify(h.saved);
  h.store[F.keys.personal].previous=F.snapshot({...S.defaults,centerRatio:22});const resets=v.state.resets;await v.actions.saveDefault();assert.equal(h.writes,1);assert.equal(h.store[F.keys.personal].previous,undefined);assert.equal(F.decode(h.store).personal.centerRatio,33);assert.equal(v.state.resets,resets);
  await v.actions.save({centerRatio:44},true);await settle();const writes=h.writes,appliedResets=v.state.resets;v.actions.useDefault();assert.equal(v.state.centerRatio,44);assert.equal(v.fields.centerRatio,33);assert.equal(v.state.profileDirty,true);assert.equal(v.state.resets,appliedResets);
  v.actions.cancel();assert.equal(v.fields.centerRatio,44);assert.equal(v.state.profileDirty,false);v.actions.useDefault();await v.actions.save(v.fields,true);await settle();assert.equal(v.state.centerRatio,33);assert.equal(h.writes,writes+1);assert.equal(JSON.stringify(h.saved),old);
});
test("another tab's My default is used only by an explicit restore and Apply",async()=>{
  const h=environment();await settle();const v=h.views[0];await v.actions.save({centerRatio:44},true);await settle();const before=v.state.resets;
  h.external({[F.keys.personal]:F.record({...S.defaults,centerRatio:66,cutoff:.6,compensationLimit:5}),[F.keys.language]:"ja"});assert.equal(v.state.centerRatio,44);assert.equal(F.decode(h.store).personal.cutoff,.6);assert.equal(F.decode(h.store).personal.compensationLimit,5);assert.equal(v.state.language,"ja");assert.equal(v.state.resets,before);
  h.video.currentSrc="quality-change";h.video.emit("loadedmetadata");await settle();assert.equal(v.state.centerRatio,44);
  h.context.location.search="?v=another";h.window.emit("popstate");h.flush();await settle();assert.equal(v.state.centerRatio,44);assert.equal(h.writes,1);
  v.actions.useDefault();assert.equal(v.state.centerRatio,44);assert.equal(v.fields.centerRatio,66);await v.actions.save(v.fields,true);assert.equal(F.decode(h.store).applied.centerRatio,66);
});
test("refresh and new tabs restore the last Apply without requiring Save as my default",async()=>{
  const h=environment();await settle();await h.views[0].actions.save({centerRatio:44,enabled:false},true);await settle();const first=environment({store:h.store});await settle();assert.equal(first.views[0].state.centerRatio,44);assert.equal(first.views[0].state.enabled,false);assert.equal(F.decode(h.store).personal.centerRatio,33);
  await h.views[0].actions.saveDefault();const second=environment({store:h.store});await settle();assert.equal(second.views[0].state.centerRatio,44);assert.equal(second.views[0].state.enabled,false);
});
test("another tab's Apply is adopted on navigation without replacing active settings or drafts",async()=>{
  const h=environment();await settle();const v=h.views[0];await v.actions.save({centerRatio:44},true);v.actions.draft({...v.state,cutoff:.7},"cutoff");const resets=v.state.resets;
  h.external({[F.keys.applied]:F.record({...S.defaults,centerRatio:66,cutoff:.8})});assert.equal(v.state.centerRatio,44);assert.equal(v.state.profileDirty,true);assert.equal(v.state.resets,resets);
  h.context.location.search="?v=next";h.window.emit("popstate");h.flush();await settle();assert.equal(v.state.centerRatio,66);assert.equal(v.state.cutoff,.8);assert.equal(v.state.profileDirty,false);
});
test("failed Apply stays active across navigation and retries its snapshot without accepting a draft",async()=>{
  const h=environment();await settle();const v=h.views[0];h.rejectSave=true;await v.actions.save({centerRatio:44,cutoff:.7},true);assert.equal(v.state.centerRatio,44);assert.equal(v.state.statusKey,"statusSaveFailed");assert.equal(v.state.retryStorage,true);assert.equal(h.store[F.keys.applied],undefined);
  h.context.location.search="?v=next";h.window.emit("popstate");h.flush();await settle();assert.equal(v.state.centerRatio,44);assert.equal(v.state.retryStorage,true);
  v.actions.draft({...v.state,centerRatio:55},"centerRatio");const resets=v.state.resets;h.rejectSave=false;await v.actions.retryStorage();assert.equal(F.decode(h.store).applied.centerRatio,44);assert.equal(v.state.centerRatio,44);assert.equal(v.state.profileDirty,true);assert.equal(v.state.resets,resets);assert.equal(v.state.retryStorage,false);
  const fresh=environment({store:h.store});await settle();assert.equal(fresh.views[0].state.centerRatio,44);assert.equal(fresh.views[0].state.cutoff,.7);
});
test("queued Apply snapshots retain the newest choice across a slow save and navigation",async()=>{
  const h=environment();await settle();const v=h.views[0];h.setPending=deferred();const first=v.actions.save({centerRatio:44},true);await settle();const second=v.actions.save({centerRatio:55},true);
  h.context.location.search="?v=next";h.window.emit("popstate");h.flush();await settle();assert.equal(v.state.centerRatio,55);h.setPending.resolve();await first;await second;assert.equal(v.state.centerRatio,55);assert.equal(F.decode(h.store).applied.centerRatio,55);assert.equal(F.decode(h.store).personal.centerRatio,33);
});
test("unreadable storage stays untouched through navigation and Apply until a successful retry",async()=>{
  const h=environment({rejectRead:true,store:{[F.keys.applied]:F.record({...S.defaults,centerRatio:66})}});await settle();const v=h.views[0],original=JSON.stringify(h.store);
  h.context.location.search="?v=next";h.window.emit("popstate");h.flush();await settle();assert.equal(v.state.enabled,false);assert.equal(h.writes,0);
  await v.actions.save({centerRatio:44,enabled:true},true);assert.equal(v.state.centerRatio,44);assert.equal(JSON.stringify(h.store),original);assert.equal(h.writes,0);
  h.rejectRead=false;await v.actions.retryStorage();assert.equal(v.state.centerRatio,44);assert.equal(F.decode(h.store).applied.centerRatio,44);assert.equal(F.decode(h.store).personal.centerRatio,33);
});
test("read recovery restores last Apply instead of My default",async()=>{
  const h=environment({rejectRead:true,store:{[F.keys.applied]:F.record({...S.defaults,centerRatio:66,enabled:false})}});await settle();h.rejectRead=false;await h.views[0].actions.retryStorage();assert.equal(h.views[0].state.centerRatio,66);assert.equal(h.views[0].state.enabled,false);assert.equal(h.writes,0);
});
test("immediate Enable persists only confirmed numeric settings while a draft is pending",async()=>{
  const h=environment();await settle();const v=h.views[0];v.actions.draft({...v.state,cutoff:.7},"cutoff");await v.actions.save({enabled:false});assert.equal(F.decode(h.store).applied.enabled,false);assert.equal(F.decode(h.store).applied.cutoff,S.defaults.cutoff);assert.equal(F.decode(h.store).personal.enabled,true);
  const fresh=environment({store:h.store});await settle();assert.equal(fresh.views[0].state.enabled,false);assert.equal(fresh.views[0].state.cutoff,S.defaults.cutoff);
});
test("failed personal saves keep the active profile and can be retried",async()=>{
  const h=environment();await settle();const v=h.views[0];await v.actions.save({centerRatio:44},true);await settle();h.rejectSave=true;await v.actions.saveDefault();await settle();assert.equal(v.state.defaultSaveState,"failed");assert.equal(v.state.defaultSaving,false);assert.equal(v.state.active,true);assert.equal(v.state.centerRatio,44);assert.equal(F.decode(h.store).personal.centerRatio,33);
  const resets=v.state.resets;h.rejectSave=false;await v.actions.saveDefault();assert.equal(v.state.defaultSaveState,"saved");assert.equal(F.decode(h.store).personal.centerRatio,44);assert.equal(v.state.resets,resets);
});
test("an unreadable stored profile cannot be overwritten and explicit retry restores it",async()=>{
  const h=environment({rejectRead:true});await settle();const v=h.views[0];assert.equal(v.state.defaultAvailable,false);assert.equal(v.state.active,false);assert.equal(v.state.statusKey,"profileLoadFailed");await v.actions.saveDefault();assert.equal(h.writes,0);
  h.rejectRead=false;await v.actions.retryStorage();await settle();assert.equal(v.state.defaultAvailable,true);assert.equal(v.state.centerRatio,33);assert.equal(v.state.active,true);assert.equal(h.writes,0);
});
test("a late personal save records the clicked snapshot without replacing a new video's settings",async()=>{
  const h=environment();await settle();const v=h.views[0];await v.actions.save({centerRatio:44},true);await settle();h.setPending=deferred();const saving=v.actions.saveDefault();await settle();assert.equal(v.state.defaultSaving,true);
  h.context.location.search="?v=next";h.window.emit("popstate");h.flush();await settle();assert.equal(v.state.centerRatio,44);h.setPending.resolve();await saving;await settle();assert.equal(F.decode(h.store).personal.centerRatio,44);assert.equal(v.state.centerRatio,44);assert.equal(v.state.defaultSaveState,"");
});
test("storage changes during an outstanding read are not replaced by its stale result",async()=>{
  const h=environment();await settle();const v=h.views[0];await v.actions.save({centerRatio:44},true);await settle();const pending=deferred(),stale=structuredClone(h.store);h.getHook=()=>pending.promise;const saving=v.actions.saveDefault();await settle();
  h.external({[F.keys.personal]:F.record({...S.defaults,centerRatio:66}),[F.keys.language]:"fr"});h.getHook=null;pending.resolve(stale);await saving;assert.equal(F.decode(h.store).personal.centerRatio,44);assert.equal(h.store[F.keys.personal].previous,undefined);assert.equal(v.state.language,"fr");assert.equal(v.state.centerRatio,44);
});
test("a late save preserves newer drafts and does not label them saved",async()=>{
  const h=environment();await settle();const v=h.views[0];await v.actions.save({centerRatio:44},true);await settle();h.setPending=deferred();const saving=v.actions.saveDefault();await settle();
  v.actions.draft({...v.state,centerRatio:55},"centerRatio");h.setPending.resolve();await saving;await settle();assert.equal(F.decode(h.store).personal.centerRatio,44);assert.equal(v.state.centerRatio,44);assert.equal(v.state.profileDirty,true);assert.equal(v.state.defaultSaveState,"");
  v.actions.cancel();assert.equal(v.fields.centerRatio,44);assert.equal(v.state.profileDirty,false);
});
test("queued preference writes keep the newest optimistic value and stop after invalidation",async()=>{
  const h=environment();await settle();const v=h.views[0],resets=v.state.resets;h.setPending=deferred();const first=v.actions.save({iconPosition:{x:.2,y:.2}});await settle();const second=v.actions.save({iconPosition:{x:.8,y:.8}});assert.equal(v.state.iconPosition.x,.8);h.setPending.resolve();await first;await second;assert.equal(F.decode(h.store).preferences.iconPosition.x,.8);assert.equal(v.state.resets,resets);
  h.setPending=deferred();const accepted=v.actions.save({language:"fr"});await settle();const queued=v.actions.save({language:"ja"}),writes=h.writes;h.id=undefined;h.tick();h.setPending.resolve();await accepted;await queued;assert.equal(h.writes,writes);assertStopped(h);
});
test("processing retry recovers confirmed settings without saving or accepting a draft",async()=>{
  const h=environment();await settle();const v=h.views[0];h.renderers[0].canvas.emit("contextlost");assert.equal(v.state.error,true);assert.equal(v.state.active,false);
  const resets=v.state.resets;v.actions.draft({...v.state,centerRatio:44},"centerRatio");v.actions.retryProcessing();assert.equal(v.state.error,true);assert.equal(v.state.resets,resets);
  v.actions.cancel();v.actions.retryProcessing();await settle();assert.equal(v.state.error,false);assert.equal(v.state.active,true);assert.equal(v.state.centerRatio,33);assert.equal(h.writes,0);
});
const wasmDataSource=fs.readFileSync(path.join(__dirname,"../extension/depan-wasm-data.js"),"utf8");
const noAsset=()=>{throw Error("The browser must not resolve a WASM resource URL");};
function browserLoader(compile=WebAssembly.compile){
  const metrics={factories:0,compiles:0,decodes:0,fetches:0};
  const sandbox={window:{},atob,fetch(){metrics.fetches++;throw Error("Cross-origin WASM fetch is forbidden in this test");},WebAssembly:{compile:async bytes=>{metrics.compiles++;return compile(bytes);},Instance:WebAssembly.Instance},YTSteadyRegions:R,YTDePanModule:args=>{metrics.factories++;assert.equal(typeof args.instantiateWasm,"function");assert.equal(args.locateFile,undefined);return factory(args);}};
  vm.createContext(sandbox);vm.runInContext(wasmDataSource,sandbox);
  const bundle=sandbox.YTSteadyWasmData;assert.ok(Object.isFrozen(bundle));
  const data={...bundle,getBytes(){metrics.decodes++;return bundle.getBytes();}};sandbox.YTSteadyWasmData=data;
  vm.runInContext(rendererSource,sandbox);return {P:sandbox.YTSteadyPipeline,metrics,sandbox,data};
}
test("browser core starts from identical bundled bytes with URL resolution and fetch forbidden",async()=>{
  const {P,metrics,data}=browserLoader(bytes=>{assert.deepEqual(Buffer.from(bytes),wasm);return WebAssembly.compile(bytes);});
  assert.equal(data.byteLength,wasm.length);assert.equal(data.sha256,require("../src/core-build.json").wasmSha256);
  const c=await P.createCore(noAsset),next=await P.createCore(noAsset);assert.equal(c.module._ys_api_version(),6);assert.equal(c.module,next.module);
  assert.deepEqual(metrics,{factories:1,compiles:1,decodes:1,fetches:0});
});
test("missing bundled core reports an incomplete update and a retry can recover without fetching",async()=>{
  const {P,metrics,sandbox,data}=browserLoader();sandbox.YTSteadyWasmData=undefined;
  await assert.rejects(P.createCore(noAsset),/core-version-mismatch-reload-extension/);assert.equal(metrics.compiles,0);
  sandbox.YTSteadyWasmData=data;assert.ok(await P.createCore(noAsset));assert.equal(metrics.fetches,0);
});
test("an incompatible bundle format is rejected before decoding",async()=>{
  const {P,metrics,sandbox,data}=browserLoader();sandbox.YTSteadyWasmData={...data,format:2};
  await assert.rejects(P.createCore(noAsset),/core-version-mismatch-reload-extension/);assert.equal(metrics.decodes,0);assert.equal(metrics.compiles,0);
  sandbox.YTSteadyWasmData=data;assert.ok(await P.createCore(noAsset));assert.equal(metrics.fetches,0);
});
test("invalid bundled WASM bytes fail visibly and do not poison a later retry",async()=>{
  const {P,metrics,sandbox,data}=browserLoader();sandbox.YTSteadyWasmData={...data,getBytes:()=>new Uint8Array([0])};
  await assert.rejects(P.createCore(noAsset),WebAssembly.CompileError);assert.equal(metrics.factories,0);
  sandbox.YTSteadyWasmData=data;assert.ok(await P.createCore(noAsset));assert.equal(metrics.fetches,0);
});
test("truncated bundle decoding stops before compilation and remains retryable",async()=>{
  const {P,metrics,sandbox}=browserLoader();sandbox.atob=()=>"";
  await assert.rejects(P.createCore(noAsset),/wasm-bundle-length-mismatch/);assert.equal(metrics.compiles,0);assert.equal(metrics.factories,0);
  sandbox.atob=atob;assert.ok(await P.createCore(noAsset));assert.equal(metrics.fetches,0);
});
test("an already cancelled load neither decodes nor compiles and does not block a fresh load",async()=>{
  const {P,metrics}=browserLoader(),signal=new AbortController();signal.abort();
  await assert.rejects(P.createCore(noAsset,signal.signal),/wasm-load-cancelled/);assert.deepEqual(metrics,{factories:0,compiles:0,decodes:0,fetches:0});
  assert.ok(await P.createCore(noAsset));
});
test("invalidation during compilation prevents instantiation and allows a fresh load",async()=>{
  const pending=deferred(),signal=new AbortController();let first=true;const {P,metrics}=browserLoader(bytes=>first?(first=false,pending.promise):WebAssembly.compile(bytes));
  const loading=P.createCore(noAsset,signal.signal);await settle();signal.abort();pending.resolve(await WebAssembly.compile(wasm));await assert.rejects(loading,/wasm-load-cancelled/);assert.equal(metrics.factories,0);assert.ok(await P.createCore(noAsset));assert.equal(metrics.fetches,0);
});
test("a disposed loader's late compilation failure cannot discard a newer successful module",async()=>{
  const pending=deferred();let first=true;const {P,metrics}=browserLoader(bytes=>first?(first=false,pending.promise):WebAssembly.compile(bytes));
  const old=P.createCore(noAsset);P.dispose();const fresh=await P.createCore(noAsset);pending.reject(Error("old compilation failed"));await assert.rejects(old,/old compilation failed/);
  assert.equal((await P.createCore(noAsset)).module,fresh.module);assert.equal(metrics.compiles,2);assert.equal(metrics.factories,1);assert.equal(metrics.fetches,0);
});
test("simultaneous browser consumers share one decoding and compilation",async()=>{
  const pending=deferred(),{P,metrics}=browserLoader(()=>pending.promise);
  const first=P.createCore(noAsset),second=P.createCore(noAsset);await settle();assert.equal(metrics.decodes,1);assert.equal(metrics.compiles,1);
  pending.resolve(await WebAssembly.compile(wasm));const [a,b]=await Promise.all([first,second]);assert.equal(a.module,b.module);assert.equal(metrics.factories,1);assert.equal(metrics.fetches,0);
});

test("paused source replacement retries a temporarily unavailable frame without losing settings",async()=>{
  const h=environment();await settle();const v=h.views[0],profile=F.snapshot(v.state);h.blockCapture=true;h.video.currentSrc="quality-replacement";h.video.emit("loadeddata");await settle();assert.equal(v.state.reason,"waiting-for-frame");assert.equal(v.state.active,false);const resets=v.state.resets;
  h.blockCapture=false;h.tick();await settle();assert.equal(v.state.active,true);assert.equal(h.renderers[0].visible,true);assert.ok(F.equal(v.state,profile));assert.equal(v.state.resets,resets);assert.equal(h.writes,0);
  const draws=h.draws;h.tick();await settle();assert.equal(h.draws,draws,"a valid paused frame is not processed repeatedly");h.id=undefined;h.tick();assertStopped(h);
});
test("buffered interpolation reuses retained endpoints and releases them on discontinuity",()=>{
  const {P,sandbox}=browserLoader(),rect={width:1280,height:720},copies=[],draws=[],fallbacks=[];
  let now=0;
  sandbox.performance={now:()=>now};
  const renderer=Object.create(P.Renderer.prototype);
  renderer.video={currentTime:0,playbackRate:1.3};
  renderer.interpolationFrames=[];
  renderer.interpolator={draw(a,b,fraction){draws.push([a.frame,b.frame,fraction]);return true;}};
  renderer.drawCanvas=(frame,x,y)=>fallbacks.push([frame.time,x,y]);
  function present(slot,time,visibleRect=rect){
    now=slot;renderer.video.currentTime=8+slot*.0013;
    const frame={time,visibleRect,clone(){
      const clone={time,visibleRect,closed:0,close(){this.closed++;}};
      copies.push(clone);return clone;
    }};
    return renderer.drawBuffered({frame,time,x:1,y:2},1000/30,slot,true);
  }
  assert.equal(present(0,7.98).gpu,false);
  const buffered=present(1000/30,8.03);
  assert.ok(Math.abs(buffered.time-8)<1e-8);
  assert.equal(buffered.gpu,true);
  assert.ok(Math.abs(draws[0][2]-.4)<1e-8);
  assert.equal(draws[0][1],copies[1]);
  renderer.interpolator.draw=()=>false;
  const fallback=present(2000/30,8.07);
  assert.equal(fallback.gpu,false);assert.equal(fallback.time,8.03);
  assert.deepEqual(fallbacks.at(-1),[8.03,1,2]);
  assert.deepEqual(copies.map(f=>f.closed),[1,0,0]);
  assert.equal(present(100,34).gpu,false,"do not draw across a discontinuity");
  assert.deepEqual(copies.map(f=>f.closed),[1,1,1,0]);
  renderer.resetInterpolation();
  assert.ok(copies.every(f=>f.closed===1));
  assert.equal(renderer.interpolationFrames.length,0);
});
test("WebGPU imports RGB snapshots of decoded frames and releases them when reset",()=>{
  const source=fs.readFileSync(path.join(__dirname,"../extension/interpolation.js"),"utf8");
  const snapshots=[],imports=[];
  let input;
  const rgbCanvas={getContext:()=>({drawImage(frame){input=frame;},isContextLost:()=>false})};
  const sandbox=vm.createContext({
    VideoFrame:class{
      constructor(canvas,{timestamp}){assert.equal(canvas,rgbCanvas);this.input=input;this.timestamp=timestamp;this.format="RGBX";this.closed=0;snapshots.push(this);}
      close(){this.closed++;}
    },
    GPUBufferUsage:{STORAGE:1,UNIFORM:2,COPY_DST:4}
  });
  vm.runInContext(source,sandbox);
  const pass={setPipeline(){},setBindGroup(){},dispatchWorkgroups(){},draw(){},end(){}};
  const queue={writeBuffer(){},submit(){},onSubmittedWorkDone(){return Promise.resolve();}};
  const device={
    queue,lost:new Promise(()=>{}),addEventListener(){},destroy(){},createSampler(){},createBuffer(){},createBindGroup(){},
    importExternalTexture({source}){imports.push(source);},
    createCommandEncoder(){return {beginComputePass:()=>pass,beginRenderPass:()=>pass,finish(){}};}
  };
  const context={getCurrentTexture:()=>({createView(){}}),unconfigure(){}};
  const canvas={ownerDocument:{createElement:()=>rgbCanvas}};
  const gpu=new sandbox.YTSteadyInterpolation(canvas,device,context,Array(4).fill({getBindGroupLayout(){}}),{},false);
  const makeFrame=(format,timestamp)=>({format,timestamp,visibleRect:{width:1920,height:1080}});
  const a=makeFrame("NV12",1),b=makeFrame("NV12",2),c=makeFrame("BGRA",3);
  const endpoint=frame=>({frame,x:0,y:0,time:frame.timestamp});
  assert.ok(gpu.draw(endpoint(a),endpoint(b),.5));
  assert.ok(gpu.draw(endpoint(b),endpoint(c),.5));
  assert.deepEqual(imports,[snapshots[0],snapshots[1],snapshots[1],c]);
  assert.deepEqual(snapshots.map(frame=>[frame.input,frame.timestamp,frame.closed]),[[a,1,1],[b,2,0]]);
  gpu.resetFrames();
  assert.equal(snapshots[1].closed,1);
  assert.equal(gpu.rgbFrames.size,0);
  gpu.destroy();
  assert.ok(snapshots.every(frame=>frame.closed===1));
});
