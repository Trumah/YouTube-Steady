"use strict";
const test=require("node:test"),assert=require("node:assert/strict");
const P=require("../extension/platform.js"),{iconPlacement}=require("../extension/ui.js");
test("native microsecond frame identity wins over a stale callback and watchdog clock",()=>{
  const c=new P.FrameClock();assert.equal(c.time(2033000,{mediaTime:2}),2033000);assert.equal(c.mode,"native");
  assert.equal(c.time(2066000,{fallback:true,mediaTime:99}),2066000);assert.equal(c.time(0,{mediaTime:0}),0);assert.equal(c.mode,"native");
});
test("whole-second frame defect switches to video callbacks without inventing watchdog frames",()=>{
  const c=new P.FrameClock();assert.equal(c.time(2,{mediaTime:2.029,presentedFrames:61}),2029000);assert.equal(c.mode,"callback");
  assert.equal(c.time(2,{fallback:true}),null);assert.equal(c.time(2,{mediaTime:2.064,presentedFrames:62}),2064000);
  assert.equal(c.time(2,{mediaTime:2.5},true),2500000);assert.equal(c.time(2,{}),null);
  assert.equal(c.time(2600000,{mediaTime:2.6}),2600000);assert.equal(c.mode,"native","valid native frame identity restores the watchdog after a source transition");
});
test("source cadence uses media time and counts dropped frames without mistaking display delivery for the stream",()=>{
  const source=new P.SourceCadence();
  for(let second=0;second<=4;second++){
    for(let n=0;n<30;n++)source.observe((n%3===0?2:1)/60,true);
    source.sample(second*1.3,second*78);
  }
  assert.equal(source.fps,60);
  source.suspend();assert.equal(source.fps,60);
  source.sample(800,5000);assert.equal(source.fps,60);
  source.reset();assert.equal(source.fps,0);
  for(let n=0;n<25;n++)source.observe(.04,true);
  source.sample(0,1);source.sample(1,26);assert.equal(source.fps,25);
  source.reset();
  for(let n=0;n<12;n++)source.observe(1001/30000,false);
  assert.equal(source.fps,29.97);
});
test("fixed cadence aligns refresh multiples and carries fractional timing without bursts",()=>{
  for(const [hz,fps]of [[60,15],[60,30],[59.94,30],[60,60],[60,120],[120,120],[60,27],[60,1]]){
    const cadence=new P.OutputCadence(),slots=[];
    for(let n=0;n<hz*20;n++)if(cadence.due(n*1000/hz,fps)&&n>hz)slots.push(n);
    const measured=hz*(slots.length-1)/(slots.at(-1)-slots[0]);assert.ok(Math.abs(measured-Math.min(fps,hz))<.15);
    if((hz===60&&fps!==27)||hz===59.94||hz===120){
      const every=Math.max(1,Math.round(hz/fps));assert.ok(slots.slice(1).every((value,i)=>value-slots[i]===every));
    }
    assert.equal(cadence.due(30000,fps),true);assert.equal(cadence.due(30000,fps),false);
    cadence.reset();assert.equal(cadence.refreshHz,0);assert.equal(cadence.due(10,fps),true);
  }
});
test("display refresh measurement survives pacing resets and follows a new display",()=>{
  const cadence=new P.OutputCadence();
  for(let n=0;n<10;n++)cadence.due(n*1000/60,30);
  cadence.resetSlots();assert.ok(Math.abs(cadence.refreshHz-60)<.0001);
  assert.equal(cadence.nextSlot,null);assert.equal(cadence.mediaAnchor,null);
  for(let n=0;n<10;n++)cadence.observe(1000+n*1000/120);
  assert.ok(Math.abs(cadence.refreshHz-120)<.0001);
});
test("camera translation aligns irregular source steps to fixed media times at 1.3×",()=>{
  const clock=new P.OutputCadence(),mediaStart=12,speed=1.3,velocity=[120,-84];
  const limits={limitX:100,limitY:100};let previous=null,outputs=0,maxError=0;
  for(let tick=0;tick<120;tick++){
    const now=tick*1000/60;
    if(!clock.due(now,30))continue;
    const time=mediaStart+Math.round(now*speed*.06)/60,target=clock.mediaTarget(time,speed,.05);
    if(previous!==null){
      const span=time-previous;
      const motion={valid:true,dx:-velocity[0]*span,dy:-velocity[1]*span,span,mapX:1,mapY:-2,previousMapX:1,previousMapY:-2};
      const correction=P.motionRetime(motion,target,time,limits);
      maxError=Math.max(maxError,...velocity.map((v,axis)=>Math.abs(v*time+(correction?.[axis===0?"x":"y"]||0)-v*target)));
    }
    previous=time;outputs++;
  }
  assert.equal(outputs,60);assert.ok(maxError<.0001);
  clock.reset();assert.equal(clock.due(15000,30),true);assert.equal(clock.mediaTarget(60,1,.05),60);
});
test("retiming skips unreliable vectors, long gaps, nonfinite motion and shifts outside compensation",()=>{
  const motion={valid:true,dx:-12,dy:4,span:.04,mapX:1,mapY:1,previousMapX:1,previousMapY:1};
  const limits={limitX:20,limitY:20},correction=P.motionRetime(motion,3.01,3,limits);
  assert.ok(Math.abs(correction.x-3)<.001&&Math.abs(correction.y+1)<.001);
  for(const change of [{valid:false},{span:.3},{dx:Infinity},{dx:-120}])assert.equal(P.motionRetime({...motion,...change},3.01,3,limits),null);
  assert.equal(P.motionRetime(motion,3.03,3,limits),null);
});
test("platform packages retain least permissions, exact script order and privacy declarations",()=>{
  const {extensionFiles}=require("../src/build-platforms.cjs"),manifests={};
  for(const target of ["chromium","firefox","safari"]){const files=extensionFiles(target),m=JSON.parse(files.get("manifest.json"));manifests[target]=m;assert.deepEqual(m.permissions,["storage"]);assert.equal(m.content_scripts[0].js[0],"platform.js");assert.ok(files.get("popup.html").toString().includes('src="platform.js"'));assert.ok(!m.background);}
  assert.equal(manifests.chromium.manifest_version,3);assert.equal(manifests.firefox.manifest_version,2);assert.ok(manifests.firefox.browser_action);assert.equal(manifests.firefox.action,undefined);
  assert.deepEqual(manifests.firefox.browser_specific_settings.gecko.data_collection_permissions,{required:["none"]});assert.deepEqual(manifests.firefox.content_scripts,manifests.chromium.content_scripts);
  assert.equal(manifests.safari.minimum_chrome_version,undefined);assert.equal(manifests.safari.manifest_version,3);
});
test("native browser promises are preferred; unrelated page chrome objects are not extension APIs",()=>{
  const chrome={runtime:{id:"chrome"},storage:{local:{}}},browser={runtime:{id:"gecko"},storage:{local:{}}};
  assert.equal(P.browserAPI({chrome,browser}),browser);assert.equal(P.browserAPI({chrome}),chrome);
  assert.equal(P.browserAPI({chrome:{runtime:{}}}),null);
  assert.equal(P.browserAPI({get browser(){throw Error("invalidated");},chrome}),chrome);
});
test("only desktop and mobile YouTube watch players are eligible",()=>{
  let calls=0;const video={},player={querySelector:()=>video},document={querySelector:selector=>{calls++;assert.equal(selector,"#movie_player");return player;}};
  for(const hostname of ["www.youtube.com","m.youtube.com"]){const location={hostname,pathname:"/watch",search:"?v=test&list=list"};assert.equal(P.watchIdentity(location),"test");assert.equal(P.findPlayer(document,location).video,video);}
  for(const location of [{hostname:"www.youtube.com",pathname:"/shorts/test",search:""},{hostname:"m.youtube.com",pathname:"/watch",search:""},{hostname:"other.example",pathname:"/watch",search:"?v=test"}])assert.equal(P.findPlayer(document,location),null);
  assert.equal(calls,2);
});
test("native video presentation is distinguished from whole-player fullscreen",()=>{
  const video={};assert.equal(P.originalPresentation(video,{fullscreenElement:{}}),false);
  for(const field of ["fullscreenElement","webkitFullscreenElement","pictureInPictureElement"])assert.equal(P.originalPresentation(video,{[field]:video}),true);
  for(const mode of ["fullscreen","picture-in-picture"])assert.equal(P.originalPresentation({webkitPresentationMode:mode},{}),true);
  assert.equal(P.originalPresentation({webkitPresentationMode:"inline"},{}),false);
  assert.equal(P.originalPresentation({remote:{state:"connected"}},{}),true);
  assert.equal(P.originalPresentation({remote:{state:"disconnected"}},{}),false);
});
test("44px touch entry preserves normalized position and clears the control strip",()=>{
  for(const [w,h,toolbar]of [[360,203,153],[412,232,182],[915,412,362]])for(const p of [null,{x:0,y:0},{x:1,y:1},{x:.5,y:.5}]){
    const r=iconPlacement(w,h,toolbar,p,44);assert.ok(r.x>=12&&r.x+44<=w-12);assert.ok(r.y>=12&&r.y+44<=toolbar-8);
  }
});
