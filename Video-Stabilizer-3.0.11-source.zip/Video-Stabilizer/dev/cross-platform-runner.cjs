"use strict";
// Synthetic engine verification. This runner never opens an existing browser
// profile and never labels desktop WebKit as iOS/Safari hardware verification.
const fs=require("node:fs"),path=require("node:path"),os=require("node:os"),{spawn}=require("node:child_process");
const root=path.resolve(__dirname,".."),version=require("../package.json").version,out=path.join(root,"work","cross-platform-"+version);
const toolRoot=process.env.STEADY_TOOL_ROOT||path.join(out,"tools/node_modules");
const pw=require(fs.existsSync(path.join(toolRoot,"playwright"))?path.join(toolRoot,"playwright"):"playwright");
const port=Number(process.env.PORT||8793),url=`http://127.0.0.1:${port}/`,targets=(process.argv.find(a=>a.startsWith("--targets="))?.slice(10)||"chromium,firefox,webkit,chromium-touch,firefox-touch,webkit-touch").split(",");
const report={version,host:{platform:os.platform(),arch:os.arch()},scope:"synthetic browser engines; mobile viewport emulation is not a mobile OS test",runs:[]};
const reportName=process.env.STEADY_REPORT_NAME||"engine-tests";if(!/^[a-z0-9-]+$/.test(reportName))throw Error("Invalid report name");
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function save(){fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,reportName+".json"),JSON.stringify(report,null,2)+"\n");}
function state(page){return page.evaluate(()=>JSON.parse(document.getElementById("yt-steady-controls")?.dataset.state||"{}"));}
async function run(target){
  const touch=target.endsWith("-touch"),name=target.replace("-touch",""),engine=name==="chrome"||name==="edge"?"chromium":name;
  const run={target,checks:{},pageErrors:[]};report.runs.push(run);let browser;
  const check=(name,pass,details)=>{run.checks[name]={pass,...details};};
  try{
    browser=await pw[engine].launch({headless:true,...(name==="chrome"?{channel:"chrome"}:name==="edge"?{channel:"msedge"}:{})});
    run.browserVersion=browser.version();
    const context=await browser.newContext({viewport:touch?{width:390,height:844}:{width:1360,height:1000},hasTouch:touch,...(touch&&engine!=="firefox"?{isMobile:true}:{}),locale:"en-US"});
    const page=await context.newPage();page.setDefaultTimeout(20000);page.on("pageerror",e=>run.pageErrors.push(e.message));
    await page.goto(url,{waitUntil:"load"});
    run.capabilities=await page.evaluate(()=>({userAgent:navigator.userAgent,VideoFrame:typeof VideoFrame,videoCallback:typeof HTMLVideoElement.prototype.requestVideoFrameCallback,popover:typeof HTMLElement.prototype.showPopover,coarse:matchMedia("(pointer: coarse)").matches}));
    const supported=run.capabilities.VideoFrame==="function"&&run.capabilities.videoCallback==="function";
    if(!supported){
      run.limitation="This engine build lacks media frame APIs; only UI, WASM loading and safe fallback are verified.";
      await page.waitForFunction(()=>JSON.parse(document.getElementById("yt-steady-controls")?.dataset.state||"{}").error);
      const unsupported=await state(page);check("unsupported_engine_restores_original",unsupported.statusKey==="errorUnsupported"&&!unsupported.active);
      const core=await page.evaluate(async()=>{const c=await YTSteadyPipeline.createCore(name=>new URL(name,location.href).href);return {api:c.module._ys_api_version(),heap:c.module.HEAPU8.length};});
      check("wasm_core_loads",core.api===6,{core});
    }
    if(supported){
    if(!fs.existsSync(path.join(root,"dev/fixture-v2.webm")))await page.evaluate(()=>prepare());
    await page.waitForFunction(()=>{const v=document.querySelector("video");return v?.readyState>=2&&document.getElementById("yt-steady-controls");});
    await page.evaluate(async()=>{document.querySelector("video").muted=true;await document.querySelector("video").play();});
    await page.waitForFunction(()=>{const s=JSON.parse(document.getElementById("yt-steady-controls").dataset.state);return s.active||s.error;});
    const initial=await state(page);check("frame_processing",initial.active&&!initial.error,{state:initial});
    if(!initial.active)throw Error("Frame pipeline failed: "+initial.errorDetail+" / "+initial.statusKey);
    await page.evaluate(()=>document.querySelector("video").pause());
    }
    if(touch){
      await page.evaluate(()=>{const player=document.getElementById("movie_player"),outer=document.createElement("div"),controls=document.createElement("div");outer.id="player-container-id";outer.style.position="relative";player.replaceWith(outer);outer.append(player);player.style.zIndex="0";controls.id="player-control-container";controls.style.cssText="position:absolute;inset:0;z-index:2";outer.append(controls);});
      await page.waitForFunction(()=>document.getElementById("yt-steady-controls").parentElement.id==="player-container-id");
      check("mobile_control_host_escapes_native_overlay",true);
    }
    await page.locator("#entry").click();await page.locator("#cutoff").fill("0.7");await page.locator("#close").click();
    check("close_cancels_draft",(await state(page)).cutoff===.5&&!(await state(page)).profileDirty);
    await page.locator("#entry").click();await page.locator("#cutoff").fill("0.7");await page.locator("#apply").click();
    await page.waitForFunction(()=>JSON.parse(document.getElementById("yt-steady-controls").dataset.state).cutoff===.7);
    await page.reload({waitUntil:"load"});await page.waitForFunction(()=>JSON.parse(document.getElementById("yt-steady-controls")?.dataset.state||"{}").cutoff===.7);
    check("apply_survives_reload",(await state(page)).cutoff===.7);
    await page.locator("#entry").click();await page.locator("#defaults").click();await page.locator("#apply").click();
    const locales=[];
    for(const language of ["en","zh_TW","zh_CN","ja","ko","de","fr","es","pt_BR","ru","hi","ar"]){
      await page.evaluate(language=>{const l=document.getElementById("yt-steady-controls").shadowRoot.getElementById("language");l.value=language;l.dispatchEvent(new Event("change",{bubbles:true}));},language);await delay(60);
      locales.push(await page.evaluate(language=>{const s=document.getElementById("yt-steady-controls").shadowRoot,p=s.getElementById("panel");return {language,overflow:p.scrollWidth>p.clientWidth+1,title:s.getElementById("panelTitle").textContent,apply:s.getElementById("apply").textContent};},language));
    }
    check("twelve_locale_panel_layout",locales.every(l=>!l.overflow&&l.title&&l.apply),{locales});
    if(touch){
      for(const [orientation,viewport]of [["portrait",{width:390,height:844}],["landscape",{width:844,height:390}]]){
        await page.setViewportSize(viewport);await delay(250);
        const layout=await page.evaluate(()=>{const s=document.getElementById("yt-steady-controls").shadowRoot,p=s.getElementById("panel"),r=p.getBoundingClientRect(),v=visualViewport;return {left:r.left,top:r.top,right:r.right,bottom:r.bottom,vw:v.width,vh:v.height,topLayer:p.matches(":popover-open"),overflow:p.scrollWidth>p.clientWidth+1};});
        check("touch_panel_"+orientation,layout.topLayer&&!layout.overflow&&layout.left>=0&&layout.top>=0&&layout.right<=layout.vw+1&&layout.bottom<=layout.vh+1,{layout});
      }
      await page.setViewportSize({width:390,height:844});
      await page.waitForFunction(()=>{const p=document.getElementById("yt-steady-controls").shadowRoot.getElementById("panel"),r=p.getBoundingClientRect();return r.left>=0&&r.right<=visualViewport.width+1&&r.bottom<=visualViewport.height+1;});
      await page.screenshot({path:path.join(out,target+".png")});
    }
    await page.locator("#close").click();
    if(supported){
    await page.evaluate(async()=>{await seekTest();await recoveryTest();await lifecycleTest();});
    run.playback=await page.evaluate(()=>JSON.parse(document.getElementById("results").textContent));
    for(const [key,value]of Object.entries(run.playback.checks))check(key,value.pass,{details:value});
    if(!touch){
      await page.evaluate(()=>pixelTest());run.pixels=await page.evaluate(()=>JSON.parse(document.getElementById("results").textContent));
      for(const [key,value]of Object.entries(run.pixels.checks))check(key,value.pass,{details:value});
    }
    if(process.argv.includes("--cadence")){
      await page.evaluate(()=>document.getElementById("test-cadence").click());
      await page.waitForFunction(()=>!document.getElementById("test-cadence").disabled,{},{timeout:30000});
      run.cadence=await page.evaluate(()=>JSON.parse(document.getElementById("results").textContent).cadence);
      const measured=run.cadence?.[1];check("cadence_without_pixel_readback",!!measured&&measured.dropped<=4&&measured.state.outputFps>=29,{samples:run.cadence});
    }
    }
    run.finalState=await state(page);await page.screenshot({path:path.join(out,target+"-final.png")});
  }catch(error){run.error=error.message;check("suite_completed",false,{error:error.message});}
  finally{await browser?.close();run.pass=!run.error&&Object.values(run.checks).every(x=>x.pass);run.status=!run.pass?"failed":run.limitation?"limited":"passed";save();console.log(JSON.stringify({target,pass:run.pass,status:run.status,failed:Object.entries(run.checks).filter(([,v])=>!v.pass).map(([k])=>k),error:run.error}));}
}
(async()=>{
  fs.mkdirSync(out,{recursive:true});
  const server=spawn(process.execPath,[path.join(root,"dev/server.cjs")],{cwd:root,env:{...process.env,PORT:String(port)},windowsHide:true,stdio:["ignore","pipe","pipe"]});
  let log="";server.stdout.on("data",b=>{log+=b;});server.stderr.on("data",b=>{log+=b;});
  try{for(let n=0;!log.includes("test server:");n++){if(n>100||server.exitCode!==null)throw Error("Test server did not start: "+log);await delay(100);}for(const target of targets)await run(target);}
  finally{server.kill();}
  if(report.runs.some(r=>!r.pass))process.exitCode=1;
})().catch(error=>{console.error(error);save();process.exitCode=1;});
