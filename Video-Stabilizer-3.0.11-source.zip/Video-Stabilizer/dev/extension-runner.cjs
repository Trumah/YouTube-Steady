"use strict";
// Installs the generated package in a fresh test profile. Firefox uses its
// supported temporary-addon API; signature verification remains enabled.
const fs=require("node:fs"),path=require("node:path"),{pathToFileURL}=require("node:url"),os=require("node:os");
const root=path.resolve(__dirname,".."),version=require("../package.json").version,out=path.join(root,"work","cross-platform-"+version);
const tools=process.env.STEADY_TOOL_ROOT||(fs.existsSync(path.join(out,"tools/node_modules"))?path.join(out,"tools/node_modules"):path.join(root,"node_modules"));
const pw=require(fs.existsSync(path.join(tools,"playwright"))?path.join(tools,"playwright"):"playwright");
const targets=(process.argv.find(a=>a.startsWith("--targets="))?.slice(10)||"chromium,chromium-touch,firefox,firefox-touch").split(","),report={version,host:os.platform(),scope:"temporary installed extension; public YouTube; isolated unauthenticated desktop test profiles",runs:[]};
const state=page=>page.evaluate(()=>JSON.parse(document.getElementById("yt-steady-controls")?.dataset.state||"{}"));
function save(){fs.writeFileSync(path.join(out,"extension-tests.json"),JSON.stringify(report,null,2)+"\n");}
async function play(page){
  await page.evaluate(()=>{const v=document.querySelector("#movie_player video");v.muted=true;v.play().catch(()=>{});});
  if(await page.evaluate(()=>{const v=document.querySelector("#movie_player video");return v.paused||v.readyState<2;})){
    try{await page.locator("#movie_player .ytp-large-play-button").click({timeout:5000});}
    catch(error){if(await page.evaluate(()=>document.querySelector("#movie_player video").paused))throw error;}
  }
}
async function run(target){
  const touch=target.endsWith("-touch"),engine=target.replace("-touch","");
  const userAgent=engine==="firefox"?"Mozilla/5.0 (Android 16; Mobile; rv:159.0) Gecko/159.0 Firefox/159.0":"Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/158.0.0.0 Mobile Safari/537.36";
  const contextOptions={viewport:touch?{width:390,height:844}:{width:1360,height:900},locale:"en-US",...(touch?{hasTouch:true,userAgent}:{}),...(touch&&engine!=="firefox"?{isMobile:true}:{})};
  const result={target,checks:{},errors:[],...(touch?{mobileScope:"mobile user agent and touch emulation on desktop OS, not Android hardware"}:{})};report.runs.push(result);let browser,context,remote;
  const check=(name,pass,details)=>{result.checks[name]={pass,...details};save();};
  try{
    if(engine==="firefox"){
      const mod=await import(pathToFileURL(path.join(tools,"web-ext/lib/firefox/remote.js"))),port=await mod.findFreeTcpPort();
      browser=await pw.firefox.launch({headless:true,args:["-start-debugger-server",String(port)],firefoxUserPrefs:{"devtools.debugger.remote-enabled":true,"devtools.debugger.prompt-connection":false,"devtools.debugger.force-local":true,"xpinstall.signatures.required":true}});
      remote=await mod.connectWithMaxRetries({port,maxRetries:100,retryInterval:100});
      const installed=await remote.installTemporaryAddon(path.join(out,"stage/firefox"),false);result.addon=installed.addon;
      context=await browser.newContext(contextOptions);
    }else{
      const dir=path.join(out,"stage/chromium"),profile=fs.mkdtempSync(path.join(out,"chromium-profile-"));result.profile=path.basename(profile);
      context=await pw.chromium.launchPersistentContext(profile,{headless:true,channel:"chromium",...contextOptions,args:[`--disable-extensions-except=${dir}`,`--load-extension=${dir}`]});
    }
    let page=await context.newPage();page.setDefaultTimeout(30000);page.on("pageerror",e=>result.errors.push(e.message));
    for(const host of [touch?"m.youtube.com":"www.youtube.com"]){
      console.log(JSON.stringify({target,stage:"navigate",host}));
      await page.goto(`https://${host}/watch?v=XkmFDMPE4L0`,{waitUntil:"domcontentloaded",timeout:60000});
      await page.waitForFunction(()=>document.getElementById("yt-steady-controls"));
      const identity=await page.evaluate(()=>({url:location.href,mobile:!!document.querySelector("#movie_player.ytp-mweb-player"),userAgent:navigator.userAgent,coarse:matchMedia("(pointer: coarse)").matches}));
      check(host+"_page_identity",new URL(identity.url).hostname===host&&(host!=="m.youtube.com"||identity.mobile),{identity});
      if(!result.checks[host+"_page_identity"].pass)throw Error("Unexpected YouTube page variant: "+identity.url);
      await play(page);
      console.log(JSON.stringify({target,stage:"play-requested",video:await page.evaluate(()=>{const v=document.querySelector("#movie_player video");return {ready:v.readyState,network:v.networkState,paused:v.paused,error:v.error?.message};})}));
      await page.waitForFunction(()=>JSON.parse(document.getElementById("yt-steady-controls").dataset.state).outputFrames>20,{},{timeout:45000});
      const playing=await state(page);check(host+"_processing",playing.version===version&&playing.active&&!playing.error,{url:page.url(),state:playing});
      await page.evaluate(()=>document.querySelector("#movie_player video").pause());
      await page.locator("#yt-steady-controls").locator("#entry").click();await page.locator("#yt-steady-controls").locator("#cutoff").fill("0.7");await page.locator("#yt-steady-controls").locator("#close").click();check(host+"_cancel",(await state(page)).cutoff===.5);
      await page.locator("#yt-steady-controls").locator("#entry").click();await page.locator("#yt-steady-controls").locator("#cutoff").fill("0.7");await page.locator("#yt-steady-controls").locator("#apply").click();await page.waitForTimeout(400);
      await page.reload({waitUntil:"domcontentloaded"});await page.waitForFunction(()=>JSON.parse(document.getElementById("yt-steady-controls")?.dataset.state||"{}").cutoff===.7);
      check(host+"_storage_reload",(await state(page)).cutoff===.7);
      await page.locator("#yt-steady-controls").locator("#entry").click();await page.locator("#yt-steady-controls").locator("#defaults").click();await page.locator("#yt-steady-controls").locator("#apply").click();await page.locator("#yt-steady-controls").locator("#close").click();
      await play(page);
      await page.waitForFunction(()=>JSON.parse(document.getElementById("yt-steady-controls").dataset.state).active);
      await page.evaluate(()=>document.getElementById("yt-steady-output").dispatchEvent(new Event("contextlost")));
      const failed=await state(page);check(host+"_canvas_failure",failed.error&&!failed.active);
      await page.locator("#yt-steady-controls").locator("#entry").click();await page.locator("#yt-steady-controls").locator("#retryProcessing").click();await page.waitForFunction(()=>JSON.parse(document.getElementById("yt-steady-controls").dataset.state).active);
      check(host+"_retry",!(await state(page)).error);await page.locator("#yt-steady-controls").locator("#close").click();
      await page.screenshot({path:path.join(out,target+"-"+host+".png")});await page.evaluate(()=>document.querySelector("#movie_player video").pause());
    }
  }catch(error){result.error=error.message;check("suite_completed",false,{error:error.message});}
  finally{remote?.disconnect();await context?.close();await browser?.close();result.pass=Object.values(result.checks).every(c=>c.pass);save();console.log(JSON.stringify({target,pass:result.pass,error:result.error}));}
}
(async()=>{fs.mkdirSync(out,{recursive:true});for(const target of targets)await run(target);if(report.runs.some(r=>!r.pass))process.exitCode=1;})().catch(e=>{console.error(e);save();process.exitCode=1;});
