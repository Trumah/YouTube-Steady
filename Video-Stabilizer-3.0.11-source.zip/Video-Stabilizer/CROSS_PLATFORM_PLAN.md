# Video Stabilizer 跨平台移植計劃與驗收

建立日期：2026-11-09。基準為本機 2.9.7；移植版本暫定 3.0.0。本計劃依使用者授權執行，遇到實測障礙時修正方法與範圍，並保留尚未完成的驗收。

## 目標與完成定義

將既有 YouTube 即時平移防震移植至桌面 Chrome 的 macOS、Linux、ChromeOS，並提供 Firefox 桌面／Android 及 Safari macOS／iPhone 的共用程式與獨立封裝。Edge 桌面／Android 納入相容性驗證。功能在瀏覽器的 YouTube 網頁執行；不介入官方 YouTube App。

每一平台須分別記錄程式完成、安裝、實際 YouTube、失敗恢復、持續播放與交付狀態。瀏覽器引擎模擬、縮窄視窗、單元測試或套件檢查，均不能代替該作業系統的完整驗收。未取得必要設備或帳號的項目保持待驗，不據此宣告整體完成。

保留中央單區、R85／Q30／S30／C15、cutoff 0.5 Hz、damping 0.3、中央優先關、trust4／stab1、1.00 倍及雙線性插值。效能不足顯示實測警告，不擅自降低 Q 或停用。容量不足、不可讀影格及畫布失效須恢復原圖並可重試。

## 範圍與資源

| 目標 | 交付方式 | 可用驗證方式 | 必要限制 |
| --- | --- | --- | --- |
| Windows Chrome | 現有擴充功能共用來源 | 獨立設定檔、真實 Chrome、合成與 YouTube | 不重載使用者正在播放的正式副本 |
| macOS／Linux／ChromeOS Chrome | 同一 Chromium 套件 | 可取得的虛擬機器與獨立瀏覽器；不足時保留待驗 | Windows 上的 Chrome 不代表其他 OS 驗收 |
| Edge 桌面 | 同一 Chromium 套件 | 獨立設定檔與 Edge | 正式支援聲明依驗證結果 |
| Firefox 桌面 | Firefox 專用 manifest 與 ZIP | 獨立 Firefox／合成流程；安裝測試另記 | 未簽署 ZIP 不是一般使用者可永久安裝的正式版 |
| Android Firefox | Firefox Android 套件 | Sony XQ-EC72／Android 16 實機 | 先以獨立測試版瀏覽器避免影響既有使用資料 |
| Android Edge | Chromium 共用來源 | 已安裝的 Edge；先確認開發安裝能力 | 發布入口、可安裝性與影格處理分別驗證 |
| Safari macOS／iPhone | Safari Web Extension 資源包 | WebKit 引擎測試；Apple 環境取得後補原生安裝 | WebKit on Windows 不是 Safari／iPhone 模擬器 |

使用者目前只有 Android 實機，其餘平台以虛擬機器或模擬環境為資源方向。本機有 Chrome、Edge、ADB 連線；未安裝 WSL、Firefox，未確認 Apple Developer 或 Mozilla 發布帳號。工具限安裝於專案工作目錄；不先更動主機 OS、重開機或修改使用者瀏覽器設定。

## 共用架構

1. 保留現有 C++／FFTW WebAssembly 位元組與演算法。先處理相容性，不同時重寫防震核心。
2. 加入小型平台介面，統一 browser／chrome API 選擇、設定儲存、訊息及擴充功能失效處理。保留最後 Apply 與 My default 的既有語意。
3. 分離 YouTube 播放器辨識，支援 www.youtube.com 與 m.youtube.com 的 watch 頁面。依實際 DOM 選擇播放器，避免誤抓縮圖、廣告或背景影片；Shorts、嵌入頁及其他網站不自動擴張為支援範圍。
4. 影格處理仍以同一 captured VideoFrame 分析與輸出。對 API、時間戳、色彩格式、畫布及 WebAssembly 載入做能力檢查；不以另一時間的影片畫面代替原影格。
5. 手機面板使用觸控可操作尺寸及可見視窗範圍；橫直向、視覺視窗縮放、虛擬鍵盤與播放器尺寸變動後重新排版。入口及開關仍放在播放器／擴充功能本身。
6. 原生影片全螢幕、子母畫面及遠端播放若無法顯示防震畫布，回到原圖並明確提示；退出後自動恢復。iPhone 第一階段以頁面內／橫向滿版為驗證目標，原生全螢幕防震列為獨立障礙，不假稱與桌面完全相同。
7. 共用來源產生 Chromium、Firefox 與 Safari 的 manifest／資源包，封裝差異不散落在演算法中。各包包含相符授權、來源及校驗碼。

## 執行階段

| 階段 | 工作與順序 | 完成條件 | 狀態 |
| --- | --- | --- | --- |
| P0 基準與保護 | 保存本次會修改檔案的基準、既有附件摘要；執行現有測試 | 原 120 項測試通過；不覆寫既有附件 | 完成：原 120 項通過，基準與 69 個附件摘要已保存 |
| P1 相容介面 | API 選擇、播放器辨識、載入能力、呈現狀態 | Chrome 回歸、Firefox API、手機辨識及失效恢復測試通過 | 完成：130 項程式測試通過，含時間戳異常及恢復 |
| P2 手機介面 | 觸控、面板、旋轉、視窗、原生播放模式切換 | 直／橫向、12 語含 RTL、草稿取消與套用保存可用 | 引擎與真實行動頁模擬通過；手機實機依使用者指示待驗 |
| P3 多平台封裝 | 自動產生三種包與可重建來源；Mozilla 靜態檢查 | manifest 合法、腳本順序正確、無測試介面或私密資料 | 三種候選包完成；Mozilla 0 錯誤，2 項既有樣板警告已檢查 |
| P4 引擎回歸 | Chrome、Edge、Firefox、WebKit 的合成影片／故障／介面流程 | 實際畫素、防震、跳轉、換片、保存與恢復通過；完整保留失敗原因 | 功能與畫素檢查通過；Firefox 無畫面速度門檻未過，WebKit 影片 API 不足 |
| P5 Android 實機 | 臨時擴充功能、YouTube 行動頁、安裝／重開／升級、持續播放 | 完成下列手機驗收矩陣；實測結果附裝置與版本 | 使用者要求延後；已備妥獨立 Firefox Nightly |
| P6 其他 OS | 取得合法可用虛擬環境；執行同一流程 | 每一 OS 的功能證據與模擬限制可辨識 | 未取得可執行的目標 OS 環境；不得以 Windows 引擎測試替代 |
| P7 Apple 發布條件 | Safari API、原生呈現、GPL 散布條款、帳號／簽署 | 技術與授權條件分別確認；必要時取得額外授權或修正依賴 | 待 Apple 環境／帳號及 GPL 散布條件確認 |
| P8 交付與復原 | 解壓來源重建／重測、全差異審查、文件／來源／附件摘要一致 | 可安裝版本、限制、復原步驟與剩餘驗收明確；正式發布另按授權執行 | 候選來源解壓後 130 項重測通過；完成本機交付查核，正式發布未啟動 |

## 驗收矩陣

所有可執行平台共用下列案例；結果須註明平台、瀏覽器版本、包的 SHA256、實機或模擬、測試媒體及時間。

- 安裝與生命週期：新裝啟動、重整、新分頁、站內換片、暫停後停用／更新、關閉分頁；不得留下重複 UI、計時器、原生記憶體或舊畫布。
- 播放流程：原生播放／暫停、前後跳轉、解析度切換、播放速度、廣告原圖及廣告結束恢復、全螢幕進出。
- 設定：Enable 即時切換，Apply 僅有草稿變更時可用；最後套用跨分頁／重開保留；My default 明確載入草稿；保存預設不代替 Apply；關閉／Esc／入口關閉取消草稿。
- 畫面：合成已知位移的實際畫素比對，確保同一影格分析與輸出；1.00 倍與雙線性插值維持；區域疊圖不污染輸出。
- 失敗：WebAssembly 載入失敗後 Retry、不可讀影格、容量不足、Canvas context lost、來源短暫未就緒、儲存讀寫失敗及分頁隱藏後恢復。
- 手機：直向與橫向、觸控拖移、面板捲動、輸入鍵盤、瀏覽器工具列伸縮、鎖定／解鎖與背景返回；不修改其他 App。
- 多語：12 語、長標籤、RTL、小視窗；提示與錯誤仍可讀，Apply／取消／重試可操作。
- 效能：預設下 720p30 與 1080p30 各持續至少 15 分鐘；記錄來源／輸出 fps、平均與 P95 處理時間、掉幀、記憶體及可取得的溫度／電量。相同片段比較防震開／關。60fps、4K 另測，不以單次短跑承諾。
- 效能驗收：優先維持接近來源速率；有持續輸出不足時檢查警告與操作回應。若預設在裝置上不具可用性，該解析度列為未通過，先分析取樣、FFT、畫布各階段，再決定必要優化。

## 障礙與修正原則

| 障礙 | 處理順序 | 不能當作完成的替代方案 |
| --- | --- | --- |
| Firefox／Safari API 不同 | 使用原生 Promise API、最小相容介面、再做故障測試 | 只通過語法／靜態檢查 |
| 行動 YouTube 結構不同 | 檢查真實頁面、保存去識別的必要結構、修正辨識及回歸案例 | 只增加網址匹配或強迫桌面模式 |
| 原生全螢幕移除畫布 | 顯示原圖與限制、退出後恢復；另驗證可行輸出管線 | 顯示 Active 但實際播放原圖 |
| 影片 API 或 WebAssembly 不可用 | 明確能力檢查、恢復原圖；調整最低版本 | 繞過 CSP、DRM 或放寬網站權限 |
| 手機過熱／耗電／效能不足 | 分階段量測；必要時背景計算與減少複製 | 靜默降低 Q、降低解析度或停止防震 |
| 缺 OS／Apple 環境 | 先完成其他工作，查可用虛擬／遠端環境；列出精確必要條件 | 將桌面 WebKit 當成 iPhone 已測 |
| 缺發布帳號／簽署 | 產出可審查包與操作說明，等待帳號步驟 | 關閉簽章驗證或宣稱可公開安裝 |
| GPL 與 App Store 條款未釐清 | 核對當前條款與上游權利；必要時額外授權／更換依賴 | 單改自己的 LICENSE 或下載連結 |

## 交付及復原

新增計劃書與必要原始碼／測試，更新 PROJECT_STATUS.md 的本輪摘要。機器可讀驗收集中在 validation/cross-platform-3.0.0.json；安裝包、來源包與 SHA256 放 dist 的新版本目錄，私人測試設定檔與裝置紀錄留 work/cross-platform-3.0.0，不進公開包。

保存本輪檔案基準與摘要。修復時只還原本輪變更；不得 git reset／clean 使用者既有修改。正式商店、公開網站及既有版本附件維持，直到對應平台完成驗收且有正式發布授權。驗證包採獨立設定檔或測試版瀏覽器，測完僅清理本輪建立的程序、轉送與暫存。

## 官方依據

- [Chrome 行動裝置的擴充功能限制](https://support.google.com/chrome_webstore/answer/1698338?hl=en-en)
- [Firefox Android 開發與 API 限制](https://extensionworkshop.com/documentation/develop/developing-extensions-for-firefox-for-android/)
- [跨瀏覽器 WebExtensions API](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API)
- [Firefox manifest 平台設定](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/browser_specific_settings)
- [Safari Web Extension 網頁打包與 TestFlight](https://developer.apple.com/documentation/safariservices/packaging-and-distributing-safari-web-extensions-with-app-store-connect)
- [iPhone Fullscreen API 追蹤](https://bugs.webkit.org/show_bug.cgi?id=206854)
- [Playwright 瀏覽器引擎與實際瀏覽器的差別](https://playwright.dev/docs/browsers)
- [Apple 散布條款](https://www.apple.com/legal/internet-services/itunes/us/terms.html)；專案上游授權見 NOTICE.txt、LICENSE.txt 及 FFTW-COPYRIGHT.txt。

## 執行紀錄與計劃修正

- 2026-11-09：移植前 120 項程式測試通過。確認 Android XQ-EC72／Android 16 可透過 ADB 連線，已安裝 Chrome／Edge；Firefox 尚未安裝。使用者確認只有 Android 實機，其他目標改採可取得的虛擬環境；保留 Apple／其他 OS 的實際驗收門檻。
- 2026-11-09：依使用者最新指示「先完成程式，手機稍後測試」，P5 手機播放／旋轉／持續效能驗收延後。官方 Firefox Nightly 162.0a1 已作為獨立測試 App 安裝，APK 的 Mozilla 簽章驗證通過，未完成初次設定及擴充功能安裝。手機既有子母畫面未關閉。
- 2026-11-09：Firefox 測試程序在工具隔離環境啟動失敗，改經正常程序環境使用暫存設定檔後成功。Windows WebKit 引擎缺少 VideoFrame 與 requestVideoFrameCallback，不能驗收影片處理；改分別檢查介面／能力不足恢復，保留 Apple 影片實測待驗。Chrome／Firefox 的原 2.9.7 在相同無畫面測試亦有畫素取樣數／速度門檻未過，因此先修正獨立 RAF 取樣器錯過輸出影格的問題，不降低防震畫素門檻。
- 2026-11-09：追查發現 Firefox 159 在 new VideoFrame(video) 回傳整數秒，例如影片 2.029 秒回傳 2，Chrome 則回傳 2029000 微秒。加入 FrameClock 能力偵測，只在單位異常時使用影片回呼 mediaTime，並停用沒有可靠影格身分的重複輪詢；正常原生時間戳恢復時回到既有 watchdog。分析與繪出仍使用同一個 VideoFrame。回歸另測一般 Chrome 延遲回呼不得取代有效原生時間戳。
- 2026-11-09：桌面瀏覽器直接開啟 m.youtube.com 會轉回 www.youtube.com；先前該輪結果僅算桌面驗證。實際套件測試加入手機 User-Agent、觸控環境、最終 hostname 與 ytp-mweb-player 檢查，重新驗收行動頁面。

- 2026-11-09：真正的 Firefox 行動頁控制層位於 movie_player 外側，原入口會被攔截。控制介面改掛在同一播放器外框並對齊原播放器；影片樣式、分析及輸出位置保留。加入遮罩下實際點擊測試，Chromium／Firefox 行動環境及 WebKit 介面回歸通過。
- 2026-11-09：桌面 Chromium／Firefox 與兩種真正行動頁模擬共 24 項安裝後流程通過；最終 URL、行動播放器及觸控模式均有核對。手機頁每次重整後透過原生播放按鈕重新開始，不等待可能永久 pending 的 play Promise。
- 2026-11-09：工作目錄與候選來源 ZIP 各 130 項測試通過。Chrome／Edge 的合成畫素與配對通過。Firefox 畫素與配對通過，但本機無畫面 1080p 測得約 20.7 fps，未達 29 fps 持續播放門檻，保持 Q30 並顯示效能警告；未將其寫成完整性能驗收。69 個舊附件位元組不變。最終包與來源／網站／SHA256 位於 dist/3.0.0，交付驗證保存在 work/cross-platform-3.0.0/delivery-audit.json。
