Chrome Web Store materials for Video Stabilizer

listing.json contains the 12 complete descriptions, permission explanations
and review instructions. Titles and summaries come from the packaged locale
catalogs. The materials use the tested Chromium installation archive.

Prepare the upload files from the repository root:
  node src/store/prepare.cjs

The command verifies the tested install ZIP's SHA-256 before copying it
to the version-specific materials directory. It also exports each listing,
privacy fields, reviewer instructions and the staged website's privacy policy.
It does not rebuild or overwrite any published ZIP.

Artwork uses the existing vector logo. A development-only Sharp installation
is kept inside the ignored work directory:
  npm install --prefix work/chrome-web-store/deps --no-save --package-lock=false sharp@0.35.5
  node src/store/build-artwork.cjs

Outputs: icon128.png (transparent padding), promo-small.png (440x280) and
promo-marquee.png (1400x560). Promotional PNGs have no alpha channel.

The two 1280x800 JPEG screenshots show the unchanged extension's actual
controls and region overlay over self-authored local demonstration footage.
The preview source is demo.html / demo.css / demo.js, served only on loopback:
  node src/store/preview-server.cjs
  http://127.0.0.1:8778/
They are not signed-in YouTube screenshots or performance benchmarks.

Create package-check.json from actual ZIP/source comparisons in the materials directory.
Verify the ZIP, artwork, public release hashes and live website/policy files:
  node src/store/verify.cjs
Program-test results are carried forward from the recorded test run; this
verification command does not run npm test or submit anything to the store.

Upload only the install ZIP and the declared image assets. work/ also holds
private browser evidence and development dependencies, not public uploads.
Owner sign-in, public contact-email verification and trader declaration are
completed in Google's UI. No credentials or contact email belong in this kit.

The website policy is maintained in site/privacy.html and site/privacy.css.
The root copies are the live main:/ GitHub Pages layout. The site/source
packaging scripts include these files for future releases. Existing versioned
release attachments remain sealed; website-only policy changes do not modify
the original corresponding source archive for the unchanged extension binary.
