"use strict";
// Platform manifests are generated from one runtime. No signing credentials,
// browser profiles, device logs or test adapters enter the install packages.
const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto"),zlib=require("node:zlib"),assert=require("node:assert/strict");
const root=path.resolve(__dirname,".."),hash=bytes=>crypto.createHash("sha256").update(bytes).digest("hex");
function manifestFor(base,target){
  assert.ok(["chromium","firefox","safari"].includes(target));const m=structuredClone(base);
  if(target!=="chromium")delete m.minimum_chrome_version;
  if(target==="firefox"){
    // Mozilla currently recommends MV2 on Android; this extension needs no
    // background worker. Host access follows the install-time content script.
    m.manifest_version=2;m.browser_action=m.action;delete m.action;
    m.content_security_policy=m.content_security_policy.extension_pages;
    m.browser_specific_settings={gecko:{id:"video-stabilizer@trumah.github.io",strict_min_version:"140.0",data_collection_permissions:{required:["none"]}},gecko_android:{strict_min_version:"142.0"}};
  }
  return m;
}
function walk(dir){
  return fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name,"en")).flatMap(entry=>{
    assert.ok(!entry.isSymbolicLink(),"Do not package symlinks");const p=path.join(dir,entry.name);
    return entry.isDirectory()?walk(p):[p];
  });
}
function extensionFiles(target){
  const dir=path.join(root,"extension"),files=new Map(walk(dir).map(p=>[path.relative(dir,p).replaceAll("\\","/"),fs.readFileSync(p)]));
  const m=manifestFor(JSON.parse(files.get("manifest.json")),target);files.set("manifest.json",Buffer.from(JSON.stringify(m,null,2)+"\n"));
  for(const name of m.content_scripts.flatMap(s=>s.js))assert.ok(files.has(name),"Missing content script: "+name);
  assert.equal(m.content_scripts[0].js[0],"platform.js");
  assert.deepEqual(m.permissions,["storage"]);
  assert.deepEqual(m.content_scripts[0].matches,["https://www.youtube.com/*","https://m.youtube.com/*"]);
  for(const name of files.keys())assert.ok(!/(?:^|\/)(?:dev|tests|work)|\.local\.|\.log$/i.test(name),"Unexpected install file: "+name);
  return files;
}
const crcTable=Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
function crc32(bytes){let crc=0xffffffff;for(const b of bytes)crc=crcTable[(crc^b)&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
function zip(files){
  const locals=[],central=[];let offset=0;
  for(const [name,bytes]of [...files].sort(([a],[b])=>a<b?-1:a>b?1:0)){
    assert.ok(!name.startsWith("/")&&!name.split("/").includes(".."));
    const filename=Buffer.from(name),packed=zlib.deflateRawSync(bytes,{level:9}),crc=crc32(bytes),local=Buffer.alloc(30);
    local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(8,8);local.writeUInt16LE(33,12);
    local.writeUInt32LE(crc,14);local.writeUInt32LE(packed.length,18);local.writeUInt32LE(bytes.length,22);local.writeUInt16LE(filename.length,26);
    locals.push(local,filename,packed);const header=Buffer.alloc(46);header.writeUInt32LE(0x02014b50);header.writeUInt16LE(20,4);header.writeUInt16LE(20,6);header.writeUInt16LE(0x800,8);header.writeUInt16LE(8,10);header.writeUInt16LE(33,14);
    header.writeUInt32LE(crc,16);header.writeUInt32LE(packed.length,20);header.writeUInt32LE(bytes.length,24);header.writeUInt16LE(filename.length,28);header.writeUInt32LE(offset,42);central.push(header,filename);offset+=local.length+filename.length+packed.length;
  }
  assert.ok(files.size<65536);const directory=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(files.size,8);end.writeUInt16LE(files.size,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
  return Buffer.concat([...locals,directory,end]);
}
function sourceFiles(){
  const names=["package.json","package-lock.json","AGENTS.md","CROSS_PLATFORM_PLAN.md","PROJECT_STATUS.md","README.md","README.txt","README-build.txt","TRANSLATING.txt","PUBLISHING.txt","RELEASE.txt","使用說明.txt","LICENSE.txt","NOTICE.txt","FFTW-COPYRIGHT.txt","EMSCRIPTEN-LICENSE.txt",".gitignore",".gitattributes"];
  for(const dir of ["extension","src","tests","dev","site","validation"])names.push(...walk(path.join(root,dir)).map(p=>path.relative(root,p).replaceAll("\\","/")));
  return new Map(names.filter(name=>fs.existsSync(path.join(root,name))&&!/\.(?:webm|mp4)$|\.local\./i.test(name)).map(name=>["Video-Stabilizer/"+name,fs.readFileSync(path.join(root,name))]));
}
function writeImmutable(file,bytes){
  if(fs.existsSync(file)){assert.equal(hash(fs.readFileSync(file)),hash(bytes),"Refusing to replace a sealed artifact: "+file);return;}
  fs.writeFileSync(file,bytes,{flag:"wx"});
}
function build(stageOnly=false,prepare=false){
  const version=JSON.parse(fs.readFileSync(path.join(root,"extension/manifest.json"))).version;
  assert.equal(require(path.join(root,"package.json")).version,version);
  const stage=path.join(root,"work","cross-platform-"+version,"stage"),out=prepare?path.join(root,"work","cross-platform-"+version,"candidate"):path.join(root,"dist",version),packages=new Map();
  for(const target of ["chromium","firefox","safari"]){
    const files=extensionFiles(target),dir=path.join(stage,target);
    for(const [name,bytes]of files){const p=path.join(dir,name);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,bytes);}
    packages.set(`Video-Stabilizer-${version}-${target}${target==="safari"?"-resources":""}.zip`,zip(files));
  }
  if(stageOnly)return {version,stage,targets:["chromium","firefox","safari"]};
  packages.set(`Video-Stabilizer-${version}-source.zip`,zip(sourceFiles()));
  const html=Buffer.from(`<!doctype html><html lang="zh-Hant"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Video Stabilizer ${version} 跨平台測試版</title><style>body{font:16px/1.7 system-ui;max-width:800px;margin:32px auto;padding:0 20px}a{color:#145a9b}li{margin:10px 0}</style><h1>Video Stabilizer ${version} 跨平台測試版</h1><p>所有功能免費，自願單次贊助，沒有訂閱。本頁為本機交付包；各平台驗收狀態以來源中的 CROSS_PLATFORM_PLAN.md 與 validation/cross-platform-${version}.json 為準。</p><p>Firefox ZIP 尚須 Mozilla 簽署才能供一般使用者永久安裝。Safari ZIP 是待 Apple 打包的資源，並非已簽署的 App。手機 Chrome 與官方 YouTube App 不支援此擴充功能。</p><ul>${[...packages.keys()].map(name=>`<li><a href="${name}">${name}</a></li>`).join("")}<li><a href="SHA256SUMS.txt">SHA256 校驗碼</a></li></ul><p>原生影片全螢幕、子母畫面與遠端播放使用原圖，返回網頁後恢復防震。不要同時啟用兩份擴充功能。</p></html>\n`);
  const downloadSums=[...packages].map(([name,bytes])=>`${hash(bytes)}  ${name}`).join("\n")+"\n";
  // The website archive is self-contained: its download links remain valid
  // after extraction into an empty directory, including the matching source.
  packages.set(`Video-Stabilizer-${version}-website.zip`,zip(new Map([["index.html",html],["SHA256SUMS.txt",Buffer.from(downloadSums)],...packages])));
  fs.mkdirSync(out,{recursive:true});for(const [name,bytes]of packages)writeImmutable(path.join(out,name),bytes);
  writeImmutable(path.join(out,"index.html"),html);
  const sums=[...packages].map(([name,bytes])=>`${hash(bytes)}  ${name}`).join("\n")+"\n";writeImmutable(path.join(out,"SHA256SUMS.txt"),Buffer.from(sums));
  return {version,out,artifacts:[...packages].map(([name,bytes])=>({name,bytes:bytes.length,sha256:hash(bytes)}))};
}
if(require.main===module)console.log(JSON.stringify(build(process.argv.includes("--stage"),process.argv.includes("--prepare")),null,2));
module.exports={manifestFor,extensionFiles,zip,build};
