/* App-owned regression: bundled core startup, denied raw-WASM fetch and retry. */
(function(){
  "use strict";
  const $=id=>document.getElementById(id),wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  const state=()=>JSON.parse($("yt-steady-controls")?.dataset.state||"{}"),ui=()=>$("yt-steady-controls").shadowRoot;
  const P=YTSteadyPipeline,F=YTSteadyProfiles,initialData=globalThis.YTSteadyWasmData;
  const output=document.createElement("pre");output.id="wasm-results";output.textContent="Bundled core tests not run.";$("results").before(output);
  const button=document.createElement("button");button.id="test-wasm-bundle";button.textContent=initialData?"Test bundled core without network":"Restore missing bundle and retry";document.querySelector(".actions").append(button);
  const until=async(fn,limit=12000)=>{const begin=performance.now();while(!fn()){if(performance.now()-begin>limit)throw Error("Timed out waiting for bundled core");await wait(30);}};
  button.addEventListener("click",async()=>{
    button.disabled=true;const v=document.querySelector("video"),originalFetch=globalThis.fetch,stored=YTSteadyTestProfiles.capture();
    const report={version:YTSteadySupport.version,environment:navigator.userAgent,missingAtStartup:!initialData,checks:{}},check=(name,pass,detail={})=>{report.checks[name]={pass,...detail};output.textContent=JSON.stringify(report,null,2);};
    let originalData=globalThis.YTSteadyWasmData,attemptedFetches=0;
    const noAsset=()=>{throw Error("A browser core must not resolve a WASM URL");};
    try{
      await until(()=>!!$("yt-steady-controls")&&v.readyState>=2);v.pause();const before=F.snapshot(state());
      if(!initialData){
        await until(()=>state().error);check("missing_bundle_restores_original",!state().active&&state().statusKey==="errorVersion"&&$("yt-steady-surface")?.style.display!=="block",{statusKey:state().statusKey});
        await new Promise((resolve,reject)=>{const script=document.createElement("script");script.src="/depan-wasm-data.js";script.onload=resolve;script.onerror=()=>reject(Error("Could not restore test bundle"));document.head.append(script);});
        originalData=globalThis.YTSteadyWasmData;ui().getElementById("retryProcessing").click();await v.play();await until(()=>state().active&&!state().error&&state().outputFrames>=3);v.pause();
        check("restored_bundle_retries_without_changing_profile",F.equal(before,state())&&state().active&&!state().error);
      }else{
        await v.play();await until(()=>state().active&&!state().error&&state().outputFrames>=3);v.pause();
        check("packaged_startup_outputs_frames",state().active&&state().coreLoader==="bundled-bytes",{coreLoader:state().coreLoader});
      }
      const data=globalThis.YTSteadyWasmData,bytes=data.getBytes(),digest=await crypto.subtle.digest("SHA-256",bytes),hex=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,"0")).join("");
      check("decoded_bytes_match_packaged_hash",bytes.length===data.byteLength&&hex===data.sha256,{bytes:bytes.length,sha256:hex});
      globalThis.fetch=()=>{attemptedFetches++;return Promise.reject(Error("Network fetch forbidden by core test"));};
      P.dispose();const core=await P.createCore(noAsset),cached=await P.createCore(noAsset);
      check("cold_core_compiles_with_fetch_forbidden",core.module._ys_api_version()===6&&attemptedFetches===0);
      check("compiled_core_is_reused",cached.module===core.module);
      P.dispose();globalThis.YTSteadyWasmData=undefined;let missing="";try{await P.createCore(noAsset);}catch(error){missing=error.message;}
      check("missing_data_does_not_fall_back_to_a_url",missing==="core-version-mismatch-reload-extension"&&attemptedFetches===0);
      globalThis.YTSteadyWasmData=data;check("missing_data_retry_recovers",(await P.createCore(noAsset)).module._ys_api_version()===6);
      P.dispose();globalThis.YTSteadyWasmData={...data,getBytes:()=>new Uint8Array([0])};let invalid=false;try{await P.createCore(noAsset);}catch(error){invalid=error instanceof WebAssembly.CompileError;}
      check("invalid_data_fails_without_network",invalid&&attemptedFetches===0);
      globalThis.YTSteadyWasmData=data;check("invalid_data_retry_recovers",(await P.createCore(noAsset)).module._ys_api_version()===6);
      const jumps=[2,8,1,7,3,9,0,6];
      for(const time of jumps){v.currentTime=time;await until(()=>!v.seeking);const count=state().outputFrames;await v.play();await until(()=>state().active&&!state().error&&state().outputFrames>=count+3);v.pause();}
      check("repeated_seeks_remain_active_without_fetch",state().active&&!state().error&&attemptedFetches===0,{jumps});
      check("confirmed_profile_and_storage_are_preserved",F.equal(before,state())&&JSON.stringify(YTSteadyTestProfiles.capture())===JSON.stringify(stored));
      const status=await (await originalFetch("/wasm-load-status")).json();report.network=status;
      check("raw_wasm_route_was_never_requested",status.blocked&&status.rawWasmRequests===0,{attemptedFetches});
    }catch(error){check("unexpected_error",false,{message:error.message,status:state().statusKey});}
    finally{globalThis.fetch=originalFetch;globalThis.YTSteadyWasmData=originalData;v.pause();button.disabled=false;report.complete=true;output.textContent=JSON.stringify(report,null,2);}
  });
})();
