/* Synthetic-page bounds and movable-icon regression. No installed profile is used. */
(function(){
  "use strict";
  const $=id=>document.getElementById(id),wait=ms=>new Promise(r=>setTimeout(r,ms)),ui=()=>$("yt-steady-controls").shadowRoot,state=()=>JSON.parse($("yt-steady-controls").dataset.state);
  const button=document.createElement("button");button.id="test-limits";button.textContent="測試參數界限與可移動圖示";document.querySelector(".actions").append(button);
  const reopen=document.createElement("button");reopen.id="test-return";reopen.textContent="測試工具列返回設定";document.querySelector(".actions").append(reopen);
  // The real chrome.runtime message route is covered independently in lifetime
  // tests. This local adapter exercises the same panel with a hidden entry.
  reopen.addEventListener("click",()=>{if(ui().getElementById("panel").hidden)ui().getElementById("entry").click();});
  const output=document.createElement("pre");output.id="limits-results";output.textContent="Limits/icon tests not run.";$("results").before(output);
  const field=(name,value)=>{const e=ui().getElementById(name);e.value=typeof value==="number"?YTSteadyI18n.input(value):value;e.dispatchEvent(new Event("input",{bubbles:true}));};
  const mode=value=>{const e=ui().getElementById("mode");e.value=value;e.dispatchEvent(new Event("change",{bubbles:true}));};
  const importProfile=p=>YTSteadyTestProfiles.apply(p);
  async function until(fn,ms=10000){const start=performance.now();while(!fn()){if(performance.now()-start>ms)throw Error("condition timed out: "+fn.toString());await wait(30);}}
  const apply=async()=>{YTSteadyTestProfiles.applyCurrent();await until(()=>state().active&&!state().error);await wait(60);};
  const pointer=(type,x,y,id=91)=>ui().getElementById("entry").dispatchEvent(new PointerEvent(type,{bubbles:true,composed:true,isPrimary:true,pointerId:id,button:0,clientX:x,clientY:y}));
  const key=(value,shiftKey=false)=>ui().getElementById("entry").dispatchEvent(new KeyboardEvent("keydown",{key:value,shiftKey,bubbles:true,composed:true}));
  button.addEventListener("click",async()=>{
    button.disabled=true;const originalStorage=YTSteadyTestProfiles.capture(),S=YTSteadySettings,I=YTSteadyI18n,original=S.normalize(state()),video=document.querySelector("video"),player=$("movie_player"),style=player.getAttribute("style"),wasPaused=video.paused;
    const bar=document.createElement("div");bar.className="ytp-chrome-bottom";bar.style.cssText="position:absolute;left:0;right:0;bottom:0;height:78px;pointer-events:none";player.append(bar);
    const report={version:YTSteadySupport.version,environment:navigator.userAgent,visibility:document.visibilityState,checks:{}};
    const check=(name,pass,detail={})=>{report.checks[name]={pass,...detail};output.textContent=JSON.stringify(report,null,2);};
    try{
      await video.play();await until(()=>state().active&&!state().error);video.pause();importProfile({...S.defaults,language:"zh_TW"});YTSteadyTestProfiles.systemDefaults();await until(()=>state().active&&!state().error);reopen.click();ui().getElementById("advanced").open=true;
      const saved=localStorage.getItem("ytSteadySettings"),resets=state().resets;
      const values={centerRatio:0,sampleRatio:.5,searchRange:1,compensationLimit:120,zoom:1.005,cutoff:.01,damping:0,trust:35.05,stab:7.55};mode("x");for(const [name,value]of Object.entries(values))field(name,value);
      check("expanded_values_remain_draft_until_apply",state().zoom===1&&state().resets===resets&&localStorage.getItem("ytSteadySettings")===saved);await apply();
      check("precise_and_expanded_values_apply_without_rounding",Object.entries(values).every(([name,value])=>state()[name]===value)&&state().area.regions.map(r=>r.id).join()==="0,2,6,8"&&state().schema===9);
      field("damping",.92);ui().getElementById("damping").dispatchEvent(new KeyboardEvent("keydown",{key:"ArrowUp",bubbles:true}));check("precise_number_keyboard_keeps_fractional_offset",I.parseNumber(ui().getElementById("damping").value).value===.97&&state().damping===0);field("damping",0);
      check("C_above_100_remains_independent_of_search",state().area.limitX===2304&&state().searchRange===1&&Number(ui().getElementById("compensationLimitSlider").value)===100&&I.parseNumber(ui().getElementById("compensationLimit").value).value===120);
      field("zoom",32);await apply();const exact=ui().getElementById("zoom").value,stored=localStorage.getItem("ytSteadySettings");ui().getElementById("zoomSlider").focus();
      check("focusing_common_slider_keeps_outside_precise_value",Number(ui().getElementById("zoomSlider").value)===4&&ui().getElementById("zoom").value===exact&&state().zoom===32&&localStorage.getItem("ytSteadySettings")===stored);
      field("sampleRatio",.0001);field("compensationLimit",204800);field("cutoff",120);field("damping",S.fields.damping.max);await apply();
      check("minimum_Q_reports_real_sample_floor",state().sampleRatio===.0001&&state().area.samplingRaised&&state().area.regions.every(r=>r.analysisWidth===8&&r.analysisHeight===8)&&ui().getElementById("sampleHint").textContent.includes(I.t("samplingMinimum",{samples:8})));
      check("source_C_ceiling_preserves_saved_request",state().compensationLimit===204800&&state().area.limitX===65536&&state().area.compensationLimited&&ui().getElementById("limitHint").textContent.includes(I.number(state().area.effectiveCompensation,4)));
      check("cutoff_ceiling_and_full_float_damping_are_finite",state().cutoff===120&&state().effectiveCutoff===state().mediaFps/2&&state().damping===S.fields.damping.max&&Number.isFinite(state().mapX)&&Number.isFinite(state().mapY)&&ui().getElementById("cutoffHint").textContent.includes(I.number(state().effectiveCutoff,4)));
      for(const value of [32768,.0001,.5,1.005]){field("zoom",value);await apply();const b=$("yt-steady-surface").getBoundingClientRect();check("zoom_"+value+"_has_finite_geometry_and_correct_matte",state().zoom===value&&Number.isFinite(b.width)&&b.width>0&&getComputedStyle($("yt-steady-matte")).display===(value<1?"block":"none"),{width:b.width,height:b.height});}
      field("zoom",.5);await apply();ui().getElementById("enabled").click();await until(()=>!state().active);
      check("reduced_output_disable_clears_matte_and_surface",getComputedStyle($("yt-steady-matte")).display==="none"&&getComputedStyle($("yt-steady-surface")).display==="none");
      ui().getElementById("enabled").click();await until(()=>state().active);check("reduced_output_enable_restores_matte",getComputedStyle($("yt-steady-matte")).display==="block");
      $("yt-steady-output").dispatchEvent(new Event("contextlost"));await until(()=>state().error);check("reduced_output_failure_reveals_original",!state().active&&getComputedStyle($("yt-steady-matte")).display==="none");
      await apply();check("reduced_output_retry_has_one_live_matte",state().active&&!state().error&&document.querySelectorAll("#yt-steady-matte").length===1&&getComputedStyle($("yt-steady-matte")).display==="block");
      const good=localStorage.getItem("ytSteadySettings");field("zoom",0);ui().getElementById("apply").click();await wait(40);check("zero_zoom_is_rejected_without_touching_active_settings",localStorage.getItem("ytSteadySettings")===good&&state().active&&ui().getElementById("zoom").getAttribute("aria-invalid")==="true");field("zoom",1);
      mode("cross");ui().getElementById("apply").click();await wait(40);check("R_zero_cross_is_rejected_before_processing",state().mode==="x"&&state().active&&!state().error&&ui().getElementById("centerRatio").getAttribute("aria-invalid")==="true");
      YTSteadyTestProfiles.systemDefaults();await until(()=>state().active&&state().mode===S.defaults.mode&&state().centerRatio===S.defaults.centerRatio);ui().getElementById("close").click();
      let entry=ui().getElementById("entry"),r=entry.getBoundingClientRect(),strip=bar.getBoundingClientRect();check("default_icon_clears_actual_control_strip",r.bottom<=strip.top-7.5,{entry:{top:r.top,bottom:r.bottom},controlsTop:strip.top});
      await video.play();const first=state().outputFrames;await until(()=>state().outputFrames>first+8);const before=state(),beforeStore=localStorage.getItem("ytSteadySettings");r=entry.getBoundingClientRect();
      pointer("pointerdown",r.x+17,r.y+17);pointer("pointermove",r.x-180,r.y-100);
      check("drag_preview_does_not_save_or_reset_motion",localStorage.getItem("ytSteadySettings")===beforeStore&&state().resets===before.resets);
      pointer("pointerup",r.x-180,r.y-100);entry.dispatchEvent(new MouseEvent("click",{bubbles:true,composed:true,detail:1}));await wait(200);
      check("drag_saves_position_without_click_or_playback_reset",!!state().iconPosition&&state().iconPosition.x<1&&state().iconPosition.y<1&&ui().getElementById("panel").hidden&&state().resets===before.resets&&state().outputFrames>before.outputFrames,{position:state().iconPosition});
      const committed=localStorage.getItem("ytSteadySettings"),position=JSON.stringify(state().iconPosition);r=entry.getBoundingClientRect();pointer("pointerdown",r.x+17,r.y+17);pointer("pointermove",r.x-100,r.y-60);pointer("pointercancel",r.x-100,r.y-60);
      check("cancelled_drag_restores_saved_position",localStorage.getItem("ytSteadySettings")===committed&&JSON.stringify(state().iconPosition)===position);
      r=entry.getBoundingClientRect();pointer("pointerdown",r.x+17,r.y+17);pointer("pointermove",r.x-80,r.y-50);key("Escape");check("Escape_cancels_drag_without_saving",localStorage.getItem("ytSteadySettings")===committed&&JSON.stringify(state().iconPosition)===position);
      let escaped=0;const escapedKey=()=>escaped++;document.addEventListener("keydown",escapedKey);const oldX=state().iconPosition.x;key("ArrowLeft");document.removeEventListener("keydown",escapedKey);
      check("keyboard_move_is_saved_and_isolated_from_player",state().iconPosition.x<oldX&&escaped===0);key("Home");check("Home_restores_auto_position",state().iconPosition===null);
      key("ArrowLeft",true);const pref=JSON.stringify(state().iconPosition);reopen.click();YTSteadyTestProfiles.systemDefaults();await until(()=>state().active);
      check("processing_defaults_keep_icon_preference",JSON.stringify(state().iconPosition)===pref);
      for(const [name,position]of [["corner",{x:0,y:0}],["center",{x:.5,y:.5}]]){importProfile({...S.normalize(state()),iconPosition:position});await wait(40);const panel=ui().getElementById("panel").getBoundingClientRect(),icon=entry.getBoundingClientRect(),overlap=Math.max(0,Math.min(panel.right,icon.right)-Math.max(panel.left,icon.left))*Math.max(0,Math.min(panel.bottom,icon.bottom)-Math.max(panel.top,icon.top));check("moved_icon_and_panel_do_not_overlap_"+name,entry.hidden||overlap===0,{iconHiddenForCompactPanel:entry.hidden,overlap,icon:{x:icon.x,y:icon.y,width:icon.width,height:icon.height},panel:{x:panel.x,y:panel.y,width:panel.width,height:panel.height},maxHeight:ui().getElementById("panel").style.maxHeight,player:{width:player.clientWidth,height:player.clientHeight},position:state().iconPosition});}
      field("zoom",1.2);const priorResets=state().resets;ui().getElementById("showIcon").click();check("hide_keeps_playback_and_numeric_draft",state().iconHidden&&entry.hidden&&state().active&&state().resets===priorResets&&I.parseNumber(ui().getElementById("zoom").value).value===1.2);
      ui().getElementById("close").click();reopen.click();check("local_toolbar_return_adapter_opens_hidden_icon_settings",!ui().getElementById("panel").hidden&&entry.hidden);await apply();check("closing_discards_draft_but_keeps_hidden_icon_preference",state().zoom===S.defaults.zoom&&state().iconHidden&&entry.hidden&&!state().profileDirty);
      const showResets=state().resets;ui().getElementById("showIcon").click();ui().getElementById("close").click();check("show_icon_restores_entry_without_reset",!state().iconHidden&&!entry.hidden&&state().resets===showResets);reopen.click();
      ui().getElementById("resetIcon").click();check("reset_position_button_restores_auto_only",state().iconPosition===null&&!state().iconHidden);
      ui().getElementById("close").click();for(const [w,h]of [[320,180],[640,640],[1080,608]]){player.style.width=w+"px";player.style.height=h+"px";await wait(100);r=entry.getBoundingClientRect();strip=bar.getBoundingClientRect();const b=player.getBoundingClientRect();check("icon_stays_inside_after_resize_"+w+"x"+h,r.left>=b.left&&r.right<=b.right&&r.top>=b.top&&r.bottom<=strip.top-7.5);}
      video.pause();$("status").textContent="參數界限與圖示測試完成";
    }catch(error){check("unexpected_error",false,{error:error.message});$("status").textContent="界限／圖示測試失敗："+error.message;}
    finally{bar.remove();video.pause();if(style===null)player.removeAttribute("style");else player.setAttribute("style",style);YTSteadyTestProfiles.restore(originalStorage);if(!wasPaused)await video.play();button.disabled=false;}
  });
})();
