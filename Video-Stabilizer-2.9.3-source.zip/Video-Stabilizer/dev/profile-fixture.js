/* Local fixture adapter only. It is never installed as a content script. */
(function(){
  "use strict";
  const F=YTSteadyProfiles,S=YTSteadySettings,keys=Object.values(F.keys),ui=()=>document.getElementById("yt-steady-controls")?.shadowRoot;
  function putRaw(key,value){if(value===null)localStorage.removeItem(key);else localStorage.setItem(key,value);window.dispatchEvent(new StorageEvent("storage",{key,newValue:value}));}
  const put=(key,value)=>putRaw(key,value===undefined?null:JSON.stringify(value));
  function applyCurrent(){const e=ui();if(!e)return;if(!e.getElementById("apply").disabled)e.getElementById("apply").click();else if(!e.getElementById("retryProcessing").hidden)e.getElementById("retryProcessing").click();}
  function systemDefaults(){ui()?.getElementById("defaults").click();applyCurrent();}
  function apply(value){const profile=S.normalize(value);put(F.keys.personal,F.record(profile));for(const [key,v]of Object.entries(F.preferenceWrites(profile)))put(key,v);ui()?.getElementById("useMyDefault").click();applyCurrent();}
  const capture=()=>({raw:Object.fromEntries(keys.map(k=>[k,localStorage.getItem(k)])),active:S.normalize(JSON.parse(document.getElementById("yt-steady-controls").dataset.state))});
  function restore(saved){apply(saved.active);for(const key of keys)putRaw(key,saved.raw[key]??null);}
  const stored=()=>JSON.stringify(Object.fromEntries(keys.map(k=>[k,localStorage.getItem(k)])));
  globalThis.YTSteadyTestProfiles={put,apply,applyCurrent,systemDefaults,capture,restore,stored};
})();
