/* Local synthetic UI regression for native ranges and shared visual mapping. */
(function(){
  "use strict";
  const $=id=>document.getElementById(id),wait=ms=>new Promise(r=>setTimeout(r,ms)),ui=()=>$("yt-steady-controls").shadowRoot,state=()=>JSON.parse($("yt-steady-controls").dataset.state),preview=()=>$("yt-steady-preview"),geom=()=>JSON.parse(preview().dataset.geometry||"{}");
  const button=document.createElement("button");button.id="test-sliders";button.textContent="測試滑桿與同色框線";document.querySelector(".actions").append(button);
  const output=document.createElement("pre");output.id="slider-results";output.textContent="Slider tests not run.";$("results").before(output);
  const field=(name,value)=>{const el=ui().getElementById(name);el.value=String(value);el.dispatchEvent(new Event("input",{bubbles:true}));};
  const slide=(name,value)=>{const el=ui().getElementById(name+"Slider");el.value=String(name==="cutoff"?Math.log(value/YTSteadySettings.sliderSpec(name).min)/Math.log(YTSteadySettings.sliderSpec(name).max/YTSteadySettings.sliderSpec(name).min):value);el.dispatchEvent(new Event("input",{bubbles:true}));};
  const key=(name,value,shiftKey=false)=>ui().getElementById(name+"Slider").dispatchEvent(new KeyboardEvent("keydown",{key:value,shiftKey,bubbles:true,composed:true}));
  async function until(fn,ms=9000){const t=performance.now();while(!fn()){if(performance.now()-t>ms)throw Error("condition timed out");await wait(30);}}
  const language=code=>{const e=ui().getElementById("language");e.value=code;e.dispatchEvent(new Event("change",{bubbles:true}));};
  const importProfile=p=>YTSteadyTestProfiles.apply(p);
  button.addEventListener("click",async()=>{
    button.disabled=true;const originalStorage=YTSteadyTestProfiles.capture(),original=state(),video=document.querySelector("video"),wasPaused=video.paused,report={version:YTSteadySupport.version,environment:navigator.userAgent,checks:{},colors:[]};let escapedKeys=0;
    const onKey=()=>escapedKeys++,check=(name,pass,details={})=>{report.checks[name]={pass,...details};output.textContent=JSON.stringify(report,null,2);};
    try{
      video.pause();YTSteadyTestProfiles.systemDefaults();await until(()=>state().active&&!state().error);if(ui().getElementById("panel").hidden)ui().getElementById("entry").click();ui().getElementById("advanced").open=true;
      const ranges=[...ui().querySelectorAll('input[type="range"]')];
      check("nine_numeric_sliders_with_labels_and_bounds",ranges.length===9&&ranges.every(r=>{const name=r.id.replace(/Slider$/,""),spec=YTSteadySettings.sliderSpec(name);return !!ui().getElementById(r.getAttribute("aria-labelledby"))&&(name==="cutoff"?Number(r.min)===0&&Number(r.max)===1&&r.step==="any":Number(r.min)===spec.min&&Number(r.max)===spec.max&&Number(r.step)===spec.step)&&r.dir==="ltr";}));
      const originalStore=localStorage.getItem("ytSteadySettings"),resetCount=state().resets;
      const common=["compensationLimit","cutoff"],advanced=["mode","centerRatio","sampleRatio","zoom"],C=state().compensationLimit,logSlider=ui().getElementById("cutoffSlider"),period=()=>ui().getElementById("cutoffPeriod").textContent;
      check("cutoff_and_C_common_geometry_in_advanced",common.every(n=>!ui().getElementById(n).closest("#advanced"))&&advanced.every(n=>!!ui().getElementById(n).closest("#advanced")));
      const positions=[];for(const hz of [.001,.01,.1,1]){field("cutoff",hz);positions.push(Number(logSlider.value));}
      check("equal_frequency_ratios_have_equal_travel",positions.every((p,i)=>i<2||Math.abs((p-positions[i-1])-(positions[1]-positions[0]))<1e-10),{positions});
      logSlider.value="0.5";logSlider.dispatchEvent(new Event("input",{bubbles:true}));check("slider_midpoint_is_geometric_mean",YTSteadyI18n.parseNumber(ui().getElementById("cutoff").value).value===.0224&&state().cutoff===YTSteadySettings.defaults.cutoff&&state().compensationLimit===C);
      const smooth=[];for(const p of [.01,.02,.03]){logSlider.value=String(p);logSlider.dispatchEvent(new Event("input",{bubbles:true}));smooth.push(Number(logSlider.value)===p);}check("low_frequency_pointer_travel_does_not_snap_back",smooth.every(Boolean));key("cutoff","Home");for(let n=0;n<4;n++)key("cutoff","ArrowRight");check("low_frequency_keyboard_accumulates_log_steps",Math.abs(Number(logSlider.value)-.04)<1e-10&&YTSteadyI18n.parseNumber(ui().getElementById("cutoff").value).value===.0002);
      field("cutoff",2);check("period_is_reciprocal_in_seconds",period()===YTSteadyI18n.t("cutoffPeriod",{seconds:YTSteadyI18n.number(.5,1)}));
      field("cutoff",1);check("whole_seconds_have_no_decimal",period()===YTSteadyI18n.t("cutoffPeriod",{seconds:YTSteadyI18n.number(1,0)}));field("cutoff",.6);check("period_above_one_second_rounds_to_integer",period()===YTSteadyI18n.t("cutoffPeriod",{seconds:YTSteadyI18n.number(2,0)}));
      field("cutoff",1);key("cutoff","ArrowRight");const expected=Math.round(Math.pow(50000,.01)*10000)/10000;check("cutoff_keyboard_moves_in_log_space",YTSteadyI18n.parseNumber(ui().getElementById("cutoff").value).value===expected&&logSlider.getAttribute("aria-valuetext").includes("Hz"));
      key("cutoff","Home");const minimum=YTSteadyI18n.parseNumber(ui().getElementById("cutoff").value).value;key("cutoff","End");check("log_keyboard_endpoints_remain_positive",minimum===.0001&&YTSteadyI18n.parseNumber(ui().getElementById("cutoff").value).value===5);
      field("cutoff",12.3456);logSlider.focus();check("precise_Hz_above_slider_range_is_preserved",YTSteadyI18n.parseNumber(ui().getElementById("cutoff").value).value===12.3456&&Number(logSlider.value)===1&&period()===YTSteadyI18n.t("cutoffPeriod",{seconds:"<"+YTSteadyI18n.number(.1,1)}));
      field("cutoff",0);ui().getElementById("apply").click();check("invalid_cutoff_keeps_original_and_finite_period",state().cutoff===YTSteadySettings.defaults.cutoff&&state().compensationLimit===C&&period().includes("—")&&ui().getElementById("cutoff").getAttribute("aria-invalid")==="true");slide("cutoff",1);
      const geometryValues=advanced.map(n=>ui().getElementById(n).value);ui().getElementById("advanced").open=false;check("collapsing_advanced_keeps_values_and_output",advanced.every((n,i)=>ui().getElementById(n).value===geometryValues[i])&&state().active&&state().resets===resetCount);ui().getElementById("advanced").open=true;
      field("zoom",0);ui().getElementById("advanced").open=false;ui().getElementById("apply").click();check("invalid_hidden_field_reopens_advanced",ui().getElementById("advanced").open&&state().zoom===1);field("zoom",1);

      field("centerRatio",33.3333);check("precise_text_updates_slider_without_rounding",ui().getElementById("centerRatio").value==="33.3333"&&Number(ui().getElementById("centerRatioSlider").value)===33.3333);
      slide("centerRatio",37.45);check("slider_updates_number_and_preview",YTSteadyI18n.parseNumber(ui().getElementById("centerRatio").value).value===37&&geom().focus==="centerRatio"&&geom().draft&&state().centerRatio===YTSteadySettings.defaults.centerRatio);
      field("centerRatio",33.3333);key("centerRatio","ArrowRight");check("keyboard_nudge_keeps_precise_offset",Math.abs(Number(ui().getElementById("centerRatioSlider").value)-34.3333)<1e-8);
      key("compensationLimit","End");const upper=Number(ui().getElementById("compensationLimitSlider").value);key("compensationLimit","Home");const lower=Number(ui().getElementById("compensationLimitSlider").value);key("compensationLimit","ArrowRight",true);
      check("keyboard_bounds_and_shift_steps",upper===100&&lower===0&&Number(ui().getElementById("compensationLimitSlider").value)===2.5);key("compensationLimit","PageUp");check("page_keys_use_ten_steps",Number(ui().getElementById("compensationLimitSlider").value)===5);
      document.addEventListener("keydown",onKey);key("searchRange","ArrowRight");document.removeEventListener("keydown",onKey);check("slider_keys_do_not_reach_player_shortcuts",escapedKeys===0);
      field("zoom",1.14);field("zoom",0);ui().getElementById("apply").click();check("invalid_text_keeps_last_valid_slider",Number(ui().getElementById("zoomSlider").value)===1.14&&ui().getElementById("zoom").getAttribute("aria-invalid")==="true"&&state().zoom===1);
      slide("zoom",1.1);check("slider_can_repair_invalid_text",Number(ui().getElementById("zoomSlider").value)===1.1&&!ui().getElementById("zoom").hasAttribute("aria-invalid"));
      check("draft_changes_do_not_save_or_reset_motion",localStorage.getItem("ytSteadySettings")===originalStore&&state().resets===resetCount);
      language("fr");await wait(80);field("searchRange","2,75");check("decimal_comma_syncs_ascii_slider",Number(ui().getElementById("searchRangeSlider").value)===2.75&&ui().getElementById("searchRangeSlider").getAttribute("aria-valuetext").includes("2,75"));
      language("ar");await wait(80);field("zoom","١٫١٧");check("arabic_input_and_rtl_slider",Number(ui().getElementById("zoomSlider").value)===1.17&&getComputedStyle(ui().getElementById("zoomSlider")).direction==="ltr");language("zh_TW");await wait(80);
      for(const [name,target,property]of [["centerRatio",'.cell[data-id="4"]',"stroke"],["sampleRatio",".sample","fill"],["searchRange",".search","stroke"],["compensationLimit",".limit","stroke"],["zoom",".crop","stroke"]]){
        const range=ui().getElementById(name+"Slider");range.focus();await wait(25);
        const label=getComputedStyle(ui().getElementById(name+"Label")).color,accent=getComputedStyle(range).accentColor,mark=getComputedStyle(preview().shadowRoot.querySelector(target))[property],title=getComputedStyle(preview().shadowRoot.querySelector('#phase [data-focus]')).color,legend=getComputedStyle(preview().shadowRoot.querySelector('[data-parameter="'+name+'"]').closest('bdi')).color;
        report.colors.push({name,label,accent,mark,title,legend,match:label===accent&&accent===mark&&mark===title&&title===legend});
      }
      check("five_parameter_colors_match_sliders_legend_and_geometry",report.colors.every(c=>c.match),{colors:report.colors});
      YTSteadyTestProfiles.systemDefaults();await until(()=>state().active);const committed=localStorage.getItem("ytSteadySettings"),resets=state().resets;ui().getElementById("centerRatioSlider").focus();
      check("focusing_a_control_previews_without_dirtying",!geom().draft&&state().statusKey!=="statusPending"&&localStorage.getItem("ytSteadySettings")===committed);
      await wait(5150);check("preview_expires_while_slider_remains_focused",preview().dataset.visible==="false");
      ui().getElementById("centerRatioSlider").dispatchEvent(new PointerEvent("pointerdown",{bubbles:true,composed:true}));
      check("clicking_focused_control_replays_without_saving",preview().dataset.visible==="true"&&!geom().draft&&localStorage.getItem("ytSteadySettings")===committed);
      video.currentTime=0;await until(()=>!video.seeking);await video.play();await until(()=>state().outputFrames>=8);
      const before=state().outputFrames,dragResets=state().resets;
      for(let value=20;value<=50;value++){slide("centerRatio",value);await wait(20);}await until(()=>state().outputFrames>before);
      check("continuous_input_stream_preserves_playback_and_storage",state().active&&!state().error&&state().resets===dragResets&&state().outputFrames>before&&localStorage.getItem("ytSteadySettings")===committed,{frames:state().outputFrames-before});
      ui().getElementById("apply").click();await until(()=>state().active&&state().outputFrames>=10&&state().regions.inliers>0);video.pause();await wait(100);ui().getElementById("zoomSlider").focus();ui().getElementById("centerRatioSlider").focus();
      const accepted=preview().shadowRoot.querySelector('.cell[data-state="inlier"]'),dot=preview().shadowRoot.querySelector('.state-marker[data-state="inlier"]'),rColor=getComputedStyle(ui().getElementById("centerRatioLabel")).color;
      check("accepted_region_status_does_not_replace_R_outline_color",!!accepted&&!!dot&&getComputedStyle(accepted).stroke===rColor&&getComputedStyle(dot).fill!==rColor);
      slide("centerRatio",40);slide("sampleRatio",35);slide("searchRange",7.5);slide("compensationLimit",4);slide("zoom",1.1);ui().getElementById("apply").click();await until(()=>state().active&&state().centerRatio===40);
      check("apply_updates_current_video_without_replacing_default",state().sampleRatio===35&&state().searchRange===7.5&&state().compensationLimit===4&&state().zoom===1.1&&localStorage.getItem("ytSteadySettings")===committed);
      YTSteadyTestProfiles.systemDefaults();await until(()=>state().active);check("reset_synchronizes_number_and_slider",["centerRatio","sampleRatio","searchRange","compensationLimit","zoom"].every(name=>Number(ui().getElementById(name+"Slider").value)===YTSteadySettings.defaults[name]&&YTSteadyI18n.parseNumber(ui().getElementById(name).value).value===YTSteadySettings.defaults[name]));
      check("only_region_definition_is_available",state().schema===9&&state().area.searchMode==="regional"&&!ui().getElementById("useSimple"));
      $("status").textContent="滑桿與同色框線測試完成";
    }catch(error){check("unexpected_error",false,{error:error.message});$("status").textContent="滑桿測試失敗："+error.message;}
    finally{document.removeEventListener("keydown",onKey);video.pause();YTSteadyTestProfiles.restore(originalStorage);if(!wasPaused)await video.play();button.disabled=false;}
  });
})();
