/* App-owned browser regression; run via the visible test button. */
(function(){
  "use strict";
  const $=id=>document.getElementById(id),pause=ms=>new Promise(r=>setTimeout(r,ms));
  const state=()=>JSON.parse($("yt-steady-controls")?.dataset.state||"{}"),ui=()=>$("yt-steady-controls").shadowRoot;
  async function until(fn,ms=8000){const start=performance.now();while(!fn()){if(performance.now()-start>ms)throw Error("Timed out");await pause(30);}}
  async function language(code){const select=ui().getElementById("language");select.value=code;select.dispatchEvent(new Event("change",{bubbles:true}));await pause(70);}
  function field(name,value){const input=ui().getElementById(name);input.value=value;input.dispatchEvent(new Event("input",{bubbles:true}));}
  $("test-i18n").addEventListener("click",async()=>{
    const button=$("test-i18n"),player=$("movie_player"),video=player.querySelector("video"),I=YTSteadyI18n,S=YTSteadySettings;
    const report={version:YTSteadySupport.version,environment:navigator.userAgent,checks:{},locales:[],compact:[]};
    const show=()=>{$("i18n-results").textContent=JSON.stringify(report,null,2);};
    const check=(name,pass,detail={})=>{report.checks[name]={pass,...detail};show();};
    const originalStyle=player.getAttribute("style"),originalLoop=video.loop,originalStorage=YTSteadyTestProfiles.capture();let original;
    button.disabled=true;$("i18n-status").textContent="Testing languages, input, playback and compact layout…";
    try{
      await until(()=>video.readyState>=2&&!!$("yt-steady-controls"));original=state();video.loop=true;
      if(!ui().getElementById("enabled").checked)ui().getElementById("enabled").click();
      if(ui().getElementById("panel").hidden)ui().getElementById("entry").click();
      video.currentTime=0;await until(()=>!video.seeking);const freshFrames=state().outputFrames;await video.play();await until(()=>state().active&&state().outputFrames>=freshFrames+6);
      field("zoom","1,12");const before=state(),beforeTime=video.currentTime;ui().getElementById("advanced").open=true;
      for(const locale of I.languages){
        await language(locale.code);ui().getElementById("showRegions").click();const s=state(),panel=ui().getElementById("panel"),rect=panel.getBoundingClientRect(),bounds=player.getBoundingClientRect();
        const bandHint=$("yt-steady-preview").shadowRoot.getElementById("detail").textContent.includes(I.t("compensationBandHint"));ui().getElementById("searchRange").dispatchEvent(new PointerEvent("pointerdown",{bubbles:true}));const searchGeometry=JSON.parse($("yt-steady-preview").dataset.geometry),searchExample=searchGeometry.searchRanges.find(r=>r.id===4)||searchGeometry.searchRanges[0];
        report.locales.push({code:locale.code,locale:s.locale,dir:$("yt-steady-controls").dir,label:ui().getElementById("apply").textContent,zoomDraft:ui().getElementById("zoom").value,
          periodTranslated:ui().getElementById("cutoffPeriod").textContent===I.t("cutoffPeriod",{seconds:1/s.cutoff<.1?"<"+I.number(.1,1):I.number(1/s.cutoff,1/s.cutoff<1?1:0)}),
          cutoffCommon:!ui().getElementById("cutoff").closest("#advanced"),
          cutoffLabelsFit:(()=>{const r=["strengthHeavy","strengthMedium","strengthLight"].map(id=>ui().getElementById(id).getBoundingClientRect());return r.every((a,i)=>r.every((b,j)=>i===j||a.right<=b.left+1||b.right<=a.left+1||a.bottom<=b.top+1||b.bottom<=a.top+1));})(),
          profileLabels:["strengthLight","strengthMedium","strengthHeavy","saveMyDefault","useMyDefault"].every(key=>ui().getElementById(key).textContent===I.t(key))&&ui().getElementById("defaults").textContent===I.t("generalDefaults")&&ui().querySelector("#advanced > summary").textContent===I.t("advanced"),
          bandHint,searchGuide:$("yt-steady-preview").shadowRoot.getElementById("detail").textContent.includes(I.t("searchArrowHint",{region:I.number(searchExample.id+1),x:I.number(searchExample.dx,1),y:I.number(searchExample.dy,1)})),
          noOverflow:panel.scrollWidth<=panel.clientWidth+1,insidePlayer:rect.left>=bounds.left-1&&rect.right<=bounds.right+1&&rect.top>=bounds.top-1&&rect.bottom<=bounds.bottom+1,
          correct:s.locale===locale.code&&$("yt-steady-controls").dir===locale.dir&&ui().getElementById("apply").textContent===I.t("applyCurrent")&&I.parseNumber(ui().getElementById("zoom").value).value===1.12&&s.zoom===before.zoom&&s.statusKey==="statusPending"});
      }
      const after=state();check("all_12_languages",report.locales.length===12&&report.locales.every(x=>x.correct&&x.noOverflow&&x.insidePlayer),{count:report.locales.length});
      check("profile_actions_translated_in_all_12_languages",report.locales.every(x=>x.profileLabels));check("one_common_cutoff_and_nonoverlapping_labels",report.locales.every(x=>x.cutoffCommon&&x.cutoffLabelsFit));
      check("period_is_localized_in_all_12_languages",report.locales.every(x=>x.periodTranslated));
      check("C_band_explanation_in_all_12_languages",report.locales.every(x=>x.bandHint));check("regional_search_guide_in_all_12_languages",report.locales.every(x=>x.searchGuide));
      check("language_keeps_playback_and_motion",after.resets===before.resets&&after.outputFrames>before.outputFrames&&video.currentTime>beforeTime&&!video.paused,{before:before.resets,after:after.resets,frames:after.outputFrames-before.outputFrames});
      await language("ar");field("zoom","١٫١٢");field("cutoff","٠٫٧٠");field("damping","١٫٢");ui().getElementById("apply").click();
      await until(()=>state().zoom===1.12&&state().cutoff===.7&&state().damping===1.2&&state().active);
      check("arabic_numeric_apply",true,{zoom:state().zoom,cutoff:state().cutoff,damping:state().damping});
      field("zoom","٠");ui().getElementById("apply").click();await pause(60);
      check("localized_range_guard",state().zoom===1.12&&ui().getElementById("zoom").getAttribute("aria-invalid")==="true"&&!!ui().getElementById("zoom").validationMessage,{message:ui().getElementById("zoom").validationMessage});
      await language("fr");check("invalid_draft_survives_language",I.parseNumber(ui().getElementById("zoom").value).value===0&&ui().getElementById("zoom").getAttribute("aria-invalid")==="true"&&state().zoom===1.12,{draft:ui().getElementById("zoom").value,message:ui().getElementById("zoom").validationMessage});
      YTSteadyTestProfiles.systemDefaults();await until(()=>state().active&&!state().error);
      $("yt-steady-output").dispatchEvent(new Event("contextlost"));await pause(60);const errorResets=state().resets;
      await language("ar");check("error_translates_without_retry",state().error&&!state().active&&state().resets===errorResets&&state().statusKey==="errorCanvas"&&ui().getElementById("status").textContent===I.t("errorCanvas"));
      ui().getElementById("retryProcessing").click();await until(()=>state().active&&!state().error);check("retry_recovers_output_without_parameter_changes",ui().getElementById("apply").disabled);
      player.style.width="320px";player.style.height="180px";ui().getElementById("advanced").open=true;
      for(const code of ["de","ru","ar","hi"]){
        await language(code);ui().getElementById("showRegions").click();const panel=ui().getElementById("panel"),rect=panel.getBoundingClientRect(),bounds=player.getBoundingClientRect(),preview=$("yt-steady-preview"),host=preview.getBoundingClientRect(),legend=preview.shadowRoot.getElementById("legend").getBoundingClientRect();
        const labels=["strengthHeavy","strengthMedium","strengthLight"].map(id=>ui().getElementById(id).getBoundingClientRect());
        report.compact.push({code,cutoffLabelsFit:labels.every((a,i)=>labels.every((b,j)=>i===j||a.right<=b.left+1||b.right<=a.left+1||a.bottom<=b.top+1||b.bottom<=a.top+1)),width:panel.clientWidth,height:panel.clientHeight,scrollWidth:panel.scrollWidth,
          legendFits:legend.left>=host.left-1&&legend.right<=host.right+1&&legend.top>=host.top-1&&legend.bottom<=host.bottom+1,legendHeight:legend.height,
          insidePlayer:rect.left>=bounds.left-1&&rect.right<=bounds.right+1&&rect.top>=bounds.top-1&&rect.bottom<=bounds.bottom+1,noOverflow:panel.scrollWidth<=panel.clientWidth+1});
      }
      const searchCompact=[];for(const code of ["de","ru","ar","hi"]){await language(code);field("searchRange","50");const h=$("yt-steady-preview").getBoundingClientRect(),l=$("yt-steady-preview").shadowRoot.getElementById("legend").getBoundingClientRect();searchCompact.push({code,inside:l.left>=h.left-1&&l.right<=h.right+1&&l.top>=h.top-1&&l.bottom<=h.bottom+1});field("searchRange","25");}report.searchCompact=searchCompact;check("limited_search_guide_fits_compact_video",searchCompact.every(x=>x.inside));
      check("compact_320x180_rtl_and_long_labels",report.compact.every(x=>x.insidePlayer&&x.noOverflow&&x.cutoffLabelsFit));
      check("C_band_legend_fits_compact_video",report.compact.every(x=>x.legendFits));
      check("source_video_css_preserved",video.style.transform==="translateZ(0px)"&&video.style.translate==="3px 2px"&&video.style.scale==="1");
      $("i18n-status").textContent="UI regression completed";
    }catch(error){check("unexpected_error",false,{message:error.message});$("i18n-status").textContent="UI regression failed: "+error.message;}
    finally{
      video.pause();video.loop=originalLoop;if(originalStyle===null)player.removeAttribute("style");else player.setAttribute("style",originalStyle);
      if(original)YTSteadyTestProfiles.restore(originalStorage);
      button.disabled=false;show();
    }
  });
})();
