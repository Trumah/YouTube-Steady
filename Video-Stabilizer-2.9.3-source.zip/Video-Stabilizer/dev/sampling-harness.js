/* App-owned percentage/overlay benchmark and bounded overload regression. */
(function(){
  "use strict";
  const $=id=>document.getElementById(id),wait=ms=>new Promise(r=>setTimeout(r,ms)),ui=()=>$("yt-steady-controls").shadowRoot;
  const state=()=>JSON.parse($("yt-steady-controls")?.dataset.state||"{}");
  const button=document.createElement("button");button.id="test-sampling";button.textContent="測試取樣比例與四角圖文";document.querySelector(".actions").append(button);
  const slow=document.createElement("button");slow.id="test-workload";slow.textContent="測試高負擔選擇與恢復";document.querySelector(".actions").append(slow);
  for(const id of ["sampling-results","workload-results"]){const pre=document.createElement("pre");pre.id=id;pre.textContent="Not run";$("results").before(pre);}
  async function until(fn,timeout=10000){const start=performance.now();while(!fn()){if(performance.now()-start>timeout)throw Error("condition timed out");await wait(40);}}
  const motion=n=>({x:Math.round((5*Math.sin(n*1.61)+2*Math.cos(n*.73))*2),y:Math.round(4*Math.sin(n*1.19)*2)});
  button.addEventListener("click",async()=>{
    button.disabled=true;const v=document.querySelector("video"),paused=v.paused;v.pause();
    const report={version:YTSteadySupport.version,environment:navigator.userAgent,cases:[],checks:{},scope:"Captured synthetic frames; timings are analysis only, not continuous playback."},show=()=>$("sampling-results").textContent=JSON.stringify(report,null,2);
    const S=YTSteadySettings,P=YTSteadyPipeline,reader=new P.LumaReader(),canvas=document.createElement("canvas"),ctx=canvas.getContext("2d",{alpha:false}),world=makeWorld();
    let core;
    try{
      core=await P.createCore(name=>"/"+name);
      const cases=[[640,360],[854,480],[1280,720],[1920,1080],[3840,2160]].flatMap(([width,height])=>[25,50,100].map(q=>({width,height,q,mode:"cross"})));
      cases.push(...[[640,360],[1920,1080],[3840,2160]].map(([width,height])=>({width,height,q:25,mode:"x"})));
      await P.exclusive(async()=>{for(const item of cases){
        $("status").textContent=`Q=${item.q}% · ${item.width}×${item.height} · ${item.mode}`;
        canvas.width=item.width;canvas.height=item.height;const s=S.normalize({...S.defaults,mode:item.mode,sampleRatio:item.q}),p=S.plan(s,item.width,item.height),sx=item.width/1920,sy=item.height/1080;
        core.invalidate();core.activate(s,p,30);let previous;const errors=[],times=[],confident=[];
        for(let n=0;n<18;n++){
          const camera=motion(n);ctx.setTransform(sx,0,0,sy,0,0);ctx.drawImage(world,-320+camera.x,-200+camera.y);
          // Four fixed news panels occupy the corner cells; the moving scene
          // remains visible in the center and all four edge-middle cells.
          for(const [x,y]of [[0,0],[1440,0],[0,810],[1440,810]]){
            ctx.fillStyle="#132538";ctx.fillRect(x,y,480,270);ctx.fillStyle="#26d8ce";ctx.fillRect(x+12,y+12,456,38);
            ctx.fillStyle="#fff";ctx.font="bold 33px monospace";ctx.fillText("NEWS 24 LIVE",x+18,y+90);ctx.fillText("WEATHER +27",x+18,y+136);ctx.fillText("MARKET 120.5",x+18,y+182);ctx.fillText("MON  11:24",x+18,y+228);
          }
          const frame=new VideoFrame(canvas,{timestamp:n*33333});
          try{const start=performance.now(),m=core.processRegions(reader.readRegions(frame,p),p,s);times.push(performance.now()-start);if(n&&m.valid)errors.push(Math.hypot(m.dx/sx+camera.x-previous.x,m.dy/sy+camera.y-previous.y));confident.push(m.regions.inliers);previous=camera;}finally{frame.close();}
          if(n%3===0)await wait(0);
        }
        const sorted=times.slice().sort((a,b)=>a-b),rms=errors.length?Math.sqrt(errors.reduce((sum,x)=>sum+x*x,0)/errors.length):null;
        report.cases.push({...item,valid:errors.length,total:17,motionErrorRms:rms,meanAnalysisMs:times.reduce((a,b)=>a+b,0)/times.length,p95AnalysisMs:sorted[Math.floor(sorted.length*.95)],estimated:p.work,samples:p.regions.map(r=>({id:r.id,width:r.analysisWidth,height:r.analysisHeight})),heapMiB:core.module.HEAPU8.byteLength/1048576,inliers:confident});show();
      }});
      const crosses=report.cases.filter(c=>c.mode==="cross");
      report.checks.crossFindsCameraMotion=crosses.every(c=>c.valid>=14&&c.motionErrorRms<2);
      report.checks.cornerOverlayNegativeControl=report.cases.filter(c=>c.mode==="x").every(x=>x.valid<14||report.cases.find(c=>c.mode==="cross"&&c.width===x.width&&c.q===25).motionErrorRms<x.motionErrorRms*.5);
      report.checks.fullSourceSampling=report.cases.filter(c=>c.q===100).every(c=>c.samples.find(r=>r.id===4).width===c.width/2&&c.samples.find(r=>r.id===4).height===c.height/2);
      report.checks.workIncreasesWithQ=[[640,360],[854,480],[1280,720],[1920,1080],[3840,2160]].every(([w])=>{const a=report.cases.filter(c=>c.mode==="cross"&&c.width===w);return a[0].estimated.relativeMax<a[1].estimated.relativeMax&&a[1].estimated.relativeMax<a[2].estimated.relativeMax;});
      $("status").textContent="取樣比例與角標測試完成";show();
    }catch(error){report.checks.unexpectedError=false;report.error=error.message;show();}
    finally{reader.reset();ui().getElementById("apply").click();button.disabled=false;if(!paused)await v.play();}
  });
  slow.addEventListener("click",async()=>{
    slow.disabled=true;const P=YTSteadyPipeline,S=YTSteadySettings,I=YTSteadyI18n,v=document.querySelector("video"),originalStorage=YTSteadyTestProfiles.capture(),saved=P.LumaReader.prototype.read;
    const report={version:YTSteadySupport.version,injectedReadDelayMs:300,scope:"Bounded deliberate CPU delay, not a performance benchmark.",checks:{}};
    const show=()=>$("workload-results").textContent=JSON.stringify(report,null,2);
    const select=(id,value)=>{const el=ui().getElementById(id);el.value=value;el.dispatchEvent(new Event("change",{bubbles:true}));};
    const field=(id,value)=>{const el=ui().getElementById(id);el.value=I.input(value);el.dispatchEvent(new Event("input",{bubbles:true}));};
    try{
      v.pause();ui().getElementById("defaults").click();select("mode","single");field("centerRatio",100);field("sampleRatio",100);ui().getElementById("apply").click();
      P.LumaReader.prototype.read=async function(...args){await saved.apply(this,args);const until=performance.now()+300;while(performance.now()<until){};};
      v.currentTime=0;await until(()=>!v.seeking);await v.play();await until(()=>state().overBudget&&JSON.parse($("yt-steady-output")?.dataset.frame||"{}").frame>=12,12000);
      report.running=state();report.checks.slowMessageVisible=state().statusKey==="statusSlow";v.pause();await wait(150);
      const stressed=state();report.stressed=stressed;report.checks.choiceKept=stressed.sampleRatio===100&&stressed.samplingMode==="relative";
      report.checks.processingContinues=stressed.active&&!stressed.error&&stressed.overBudget;
      report.checks.slowFramesKeepReference=JSON.parse($("yt-steady-output").dataset.frame).frame>=12;
      P.LumaReader.prototype.read=saved;ui().getElementById("defaults").click();await v.play();await wait(1500);v.pause();await wait(100);
      report.recovered=state();report.checks.lowerRatioRecovers=state().active&&!state().error&&!state().overBudget&&state().sampleRatio===S.defaults.sampleRatio;show();$("status").textContent="高負擔選擇與恢復測試完成";
    }catch(error){report.checks.unexpectedError=false;report.error=error.message;show();}
    finally{
      P.LumaReader.prototype.read=saved;v.pause();
      // Restore both the active local profile and independent default/UI keys.
      YTSteadyTestProfiles.restore(originalStorage);slow.disabled=false;
    }
  });
})();
