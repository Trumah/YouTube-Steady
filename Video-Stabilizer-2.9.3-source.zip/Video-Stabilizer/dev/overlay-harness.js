/* App-owned synthetic UI regression; never touches an installed extension. */
(function(){
  "use strict";
  const $=id=>document.getElementById(id),wait=ms=>new Promise(r=>setTimeout(r,ms)),ui=()=>$("yt-steady-controls").shadowRoot,state=()=>JSON.parse($("yt-steady-controls").dataset.state),overlay=()=>$("yt-steady-preview"),geometry=()=>JSON.parse(overlay().dataset.geometry||"{}");
  const button=document.createElement("button");button.id="test-overlay";button.textContent="測試簡化參數與5秒預覽";document.querySelector(".actions").append(button);
  const output=document.createElement("pre");output.id="overlay-results";output.textContent="Overlay tests not run.";$("results").before(output);
  const field=(id,value)=>{const el=ui().getElementById(id);el.value=String(value);el.dispatchEvent(new Event("input",{bubbles:true}));};
  const select=(id,value)=>{const el=ui().getElementById(id);el.value=value;el.dispatchEvent(new Event("change",{bubbles:true}));};
  async function until(fn,ms=9000){const t=performance.now();while(!fn()){if(performance.now()-t>ms)throw Error("condition timed out: "+fn.toString());await wait(30);}}
  const bounds=poly=>({left:Math.min(...poly.map(p=>p.x)),top:Math.min(...poly.map(p=>p.y)),right:Math.max(...poly.map(p=>p.x)),bottom:Math.max(...poly.map(p=>p.y))});
  const band=()=>overlay().shadowRoot.querySelector(".limit"),filled=(x,y)=>band().isPointInFill(new DOMPoint(x,y));
  const importProfile=p=>YTSteadyTestProfiles.apply(p);
  button.addEventListener("click",async()=>{
    button.disabled=true;const originalStorage=YTSteadyTestProfiles.capture(),video=document.querySelector("video"),player=$("movie_player"),original=state(),style=player.getAttribute("style"),videoStyle=video.getAttribute("style"),wasPaused=video.paused;
    const report={version:YTSteadySupport.version,environment:navigator.userAgent,checks:{}};
    const check=(name,pass,detail={})=>{report.checks[name]={pass,...detail};output.textContent=JSON.stringify(report,null,2);};
    try{
      video.pause();importProfile({...YTSteadySettings.defaults,mode:"cross",centerRatio:50,sampleRatio:25,searchRange:25,compensationLimit:3,cutoff:1,damping:.9});await until(()=>state().active&&!state().error);if(ui().getElementById("panel").hidden)ui().getElementById("entry").click();
      check("old_axis_controls_removed",["winx","winy","estimateDx","estimateDy","dxmax","dymax","windowLayout","searchMode","units"].every(id=>!ui().getElementById(id)));
      check("new_profile_is_regional",state().parameterModel==="unified"&&state().area.searchMode==="regional"&&Math.abs(state().area.limitX/1920-state().area.limitY/1080)<1e-8);
      field("centerRatio",33.3333);let g=geometry();
      check("R_preview_is_draft",state().centerRatio===50&&g.draft&&g.regions.join()=== "1,3,4,5,7"&&overlay().shadowRoot.querySelector('.cell[data-id="4"]').getAttribute("width")==="640",{geometry:g});
      const first=performance.now();await wait(3000);field("zoom",1.1);await wait(2300);
      check("latest_edit_restarts_five_seconds",overlay().dataset.visible==="true",{elapsedSinceFirst:performance.now()-first});await wait(2850);
      check("preview_expires_after_five_seconds",overlay().dataset.visible==="false",{elapsedSinceLast:performance.now()-first-3000});
      field("centerRatio",33);const valid=overlay().dataset.geometry;field("centerRatio","");check("invalid_draft_keeps_last_valid_geometry",overlay().dataset.geometry===valid&&state().centerRatio===50);
      field("centerRatio",33);field("searchRange",9);field("compensationLimit",3);field("zoom",1);ui().getElementById("apply").click();await until(()=>state().active&&state().centerRatio===33);
      check("shared_values_applied",state().searchRange===9&&state().compensationLimit===3&&state().area.requestedSearch===9&&Math.abs(state().area.limitX-57.6)<.001&&Math.abs(state().area.limitY-32.4)<.001,{state:state()});
      // Apply replays the last edited parameter (zoom above). Focus C before
      // checking its own contextual explanation and applied-band styling.
      ui().getElementById("advanced").open=true;ui().getElementById("compensationLimit").focus();
      g=geometry();const saved=localStorage.getItem("ytSteadySettings"),appliedOpacity=getComputedStyle(band()).fillOpacity;
      check("C_band_uses_each_edge_not_a_center_box",band().tagName==="path"&&Math.abs(g.band.x-57.6)<.001&&Math.abs(g.band.y-32.4)<.001&&Math.abs(g.band.width-1804.8)<.001&&Math.abs(g.band.height-1015.2)<.001&&filled(10,540)&&filled(1910,540)&&filled(960,10)&&filled(960,1070)&&!filled(960,540),{band:g.band});
      check("C_band_matches_parameter_color_and_explains_soft_limit",getComputedStyle(band()).fill===getComputedStyle(ui().getElementById("compensationLimitLabel")).color&&overlay().shadowRoot.getElementById("detail").textContent.includes(YTSteadyI18n.t("compensationBandHint")));
      field("compensationLimit",6);g=geometry();
      check("larger_C_thickens_each_edge_in_draft_only",g.draft&&Math.abs(g.band.x-115.2)<.001&&Math.abs(g.band.y-64.8)<.001&&filled(100,540)&&!filled(150,540)&&!filled(960,540)&&state().compensationLimit===3&&localStorage.getItem("ytSteadySettings")===saved);
      check("draft_and_applied_band_styles_are_distinct",Number(getComputedStyle(band()).fillOpacity)<Number(appliedOpacity));
      const good=overlay().dataset.geometry;field("compensationLimit","");check("invalid_C_retains_last_valid_band",overlay().dataset.geometry===good&&state().compensationLimit===3);
      field("compensationLimit",0);check("zero_C_has_no_filled_band_or_outline",band().getAttribute("d")===""&&!filled(10,540)&&!filled(960,540));
      field("compensationLimit",49.9);check("C_below_half_keeps_transparent_center",geometry().band.width>0&&geometry().band.height>0&&!filled(960,540)&&filled(10,540));
      for(const value of [50,100]){field("compensationLimit",value);g=geometry();check("C_"+value+"_overlap_fills_frame_without_clamping_request",g.band.width===0&&g.band.height===0&&filled(960,540)&&g.limit[0]===1920*value/100&&Number(ui().getElementById("compensationLimit").value)===value,{band:g.band,limit:g.limit});}
      field("compensationLimit",12);const independent=band().getAttribute("d");
      for(const value of [0,1,50]){field("searchRange",value);check("C_band_independent_of_S_"+value,band().getAttribute("d")===independent&&Math.abs(geometry().limit[0]-230.4)<.001);}
      field("searchRange",1);ui().getElementById("apply").click();await until(()=>state().active&&state().compensationLimit===12&&state().searchRange===1);
      check("C_greater_than_S_applies_only_to_current_video",Math.abs(state().area.limitX-230.4)<.001&&Math.abs(state().area.limitY-129.6)<.001&&localStorage.getItem("ytSteadySettings")===saved&&!geometry().draft);
      field("compensationLimit",3);field("searchRange",9);ui().getElementById("apply").click();await until(()=>state().active&&state().compensationLimit===3);
      select("mode","adaptive");check("adaptive_preview_does_not_invent_selected_cells",geometry().draft&&geometry().selected.length===0&&geometry().inliers.length===0);
      // Other suites can leave the short fixture near its end. Start this
      // continuous-frame check from the beginning and count fresh outputs.
      ui().getElementById("apply").click();video.currentTime=0;await until(()=>!video.seeking);const fresh=state().outputFrames;await video.play();await until(()=>state().active&&state().outputFrames>=fresh+15);video.pause();await wait(150);ui().getElementById("showRegions").click();g=geometry();
      check("applied_adaptive_matches_actual_ids",!g.draft&&g.selected.length<=5&&g.selected.join()===state().regions.ids.join()&&g.inliers.join()===state().regions.inlierIds.join(),{geometry:g});
      check("C_reference_stays_at_frame_edges_while_motion_is_separate",band().parentElement===overlay().shadowRoot.querySelector("svg")&&!band().hasAttribute("transform")&&Math.abs(g.band.x-57.6)<.001&&overlay().shadowRoot.querySelector(".motion").style.display!=="none");
      const canvas=$("yt-steady-output"),pixels=Array.from(canvas.getContext("2d").getImageData(0,0,16,16).data),frame=canvas.dataset.frame;
      ui().getElementById("showRegions").click();await wait(60);
      check("overlay_never_changes_output_pixels",canvas.dataset.frame===frame&&pixels.every((v,n)=>v===canvas.getContext("2d").getImageData(0,0,16,16).data[n]));
      check("overlay_does_not_intercept_input",getComputedStyle(overlay()).pointerEvents==="none"&&getComputedStyle(overlay().shadowRoot.getElementById("legend")).pointerEvents==="none");
      const bandBeforeZoom=band().getAttribute("d");field("zoom",1.2);g=geometry();const box=bounds(g.crop);
      check("zoom_preview_shows_smaller_visible_source",g.draft&&state().zoom===1&&box.right-box.left<1700&&box.bottom-box.top<950,{crop:g.crop});
      check("zoom_crop_does_not_change_C_band",band().getAttribute("d")===bandBeforeZoom&&Math.abs(g.band.x-57.6)<.001);
      player.style.width="640px";player.style.height="640px";await wait(120);ui().getElementById("showRegions").click();g=geometry();const letter=bounds(g.crop),svg=overlay().shadowRoot.querySelector("svg").getBoundingClientRect();
      check("letterbox_uses_video_content_not_player_box",Math.abs(svg.width/svg.height-1920/1080)<.01&&letter.bottom-letter.top>1000,{svg:{width:svg.width,height:svg.height},crop:g.crop});
      const bandMatrix=band().getScreenCTM();check("C_band_thickness_scales_with_content_not_letterbox",Math.abs(Math.hypot(bandMatrix.a,bandMatrix.b)*g.band.x-svg.width*.03)<.01&&Math.abs(Math.hypot(bandMatrix.c,bandMatrix.d)*g.band.y-svg.height*.03)<.01);
      if(style===null)player.removeAttribute("style");else player.setAttribute("style",style);video.style.transform="scaleX(-1)";await wait(120);ui().getElementById("showRegions").click();
      check("mirrored_video_has_matching_preview_transform",overlay().shadowRoot.querySelector("svg").getScreenCTM().a<0&&geometry().crop.length>=3);
      if(videoStyle===null)video.removeAttribute("style");else video.setAttribute("style",videoStyle);
      field("centerRatio",50);select("mode","cross");const signatures=[];
      for(const value of [20,30,40]){field("searchRange",value);ui().getElementById("apply").click();await until(()=>state().active&&state().searchRange===value);signatures.push(JSON.stringify(state().area.regions.map(r=>[r.analysisDx,r.analysisDy])));}
      check("S_above_twenty_changes_actual_search",new Set(signatures).size===3);
      field("searchRange",30);g=geometry();const searches=overlay().shadowRoot.querySelectorAll("path.search");check("search_uses_arrows_instead_of_rectangles",searches.length===state().area.regions.length&&!overlay().shadowRoot.querySelector("rect.search")&&[...searches].every(p=>p.getAttribute("d").includes("H")&&p.getAttribute("d").includes("V")));
      check("regional_arrows_match_their_own_source_offsets",g.searchRanges.every(a=>{const r=YTSteadySettings.plan({...YTSteadySettings.normalize(state()),searchRange:30},1920,1080).regions.find(r=>r.id===a.id);return a.dx===r.analysisDx*r.scaleX&&a.dy===r.analysisDy*r.scaleY;}));
      check("search_hint_describes_axes_and_diagonals",overlay().shadowRoot.getElementById("detail").textContent.includes(YTSteadyI18n.t("searchArrowHint",{region:YTSteadyI18n.number(5),x:YTSteadyI18n.number(g.searchRanges.find(r=>r.id===4).dx,1),y:YTSteadyI18n.number(g.searchRanges.find(r=>r.id===4).dy,1)})));
      field("searchRange",0);check("zero_search_has_origins_without_arrows",[...overlay().shadowRoot.querySelectorAll("path.search")].every(p=>p.getAttribute("d")==="")&&overlay().shadowRoot.querySelectorAll(".search-origin").length===5);
      field("searchRange",50);ui().getElementById("apply").click();await until(()=>state().searchRange===50&&state().active);check("each_region_axis_reports_its_own_cap",state().area.searchLimited&&state().area.regions.every(r=>r.analysisDx===Math.floor((r.analysisWidth-1)/2)&&r.analysisDy===Math.floor((r.analysisHeight-1)/2))&&ui().getElementById("searchHint").textContent.includes(YTSteadyI18n.number(state().area.effectiveSearchMin,2)));
      const validProfile=localStorage.getItem("ytSteadySettings");select("mode","single");field("centerRatio",1);ui().getElementById("apply").click();await wait(60);
      check("unusable_R_is_rejected_without_changing_active_profile",state().active&&!state().error&&localStorage.getItem("ytSteadySettings")===validProfile&&ui().getElementById("centerRatio").getAttribute("aria-invalid")==="true");
      field("centerRatio",50);ui().getElementById("apply").click();await until(()=>state().active&&!state().error);
      check("valid_R_recovers_output_and_preview",overlay().dataset.visible==="true"&&geometry().regions.length===1);
      ui().getElementById("showRegions").click();video.currentTime=2;await until(()=>!video.seeking&&Math.abs(video.currentTime-2)<.1);await wait(80);check("seek_clears_preview",overlay().dataset.visible==="false");
      ui().getElementById("showRegions").click();ui().getElementById("enabled").click();await wait(80);check("disable_clears_preview",!state().enabled&&overlay().dataset.visible==="false");
      ui().getElementById("enabled").click();await until(()=>state().active);ui().getElementById("showRegions").click();const oldOverlay=overlay(),parent=player.parentElement,next=player.nextSibling;player.remove();await wait(220);
      check("player_removal_destroys_overlay",!oldOverlay.isConnected&&oldOverlay.dataset.visible==="false");parent.insertBefore(player,next);await until(()=>!!$("yt-steady-controls")&&state().active);
      ui().getElementById("showRegions").click();check("player_replacement_has_one_overlay",document.querySelectorAll("#yt-steady-preview").length===1);
      $("status").textContent="簡化參數與預覽測試完成";
    }catch(error){check("unexpected_error",false,{error:error.message,state:state(),media:{time:video.currentTime,duration:video.duration,paused:video.paused,ended:video.ended,visibility:document.visibilityState}});$("status").textContent="預覽測試失敗："+error.message;}
    finally{video.pause();if(style===null)player.removeAttribute("style");else player.setAttribute("style",style);if(videoStyle===null)video.removeAttribute("style");else video.setAttribute("style",videoStyle);YTSteadyTestProfiles.restore(originalStorage);if(!wasPaused)await video.play();button.disabled=false;}
  });
})();
