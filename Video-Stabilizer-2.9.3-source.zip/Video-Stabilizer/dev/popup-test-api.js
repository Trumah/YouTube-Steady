/* Local preview adapter only; never included in the installable extension. */
(function(){
  const listeners=[],key="ytSteadySettings";
  globalThis.chrome={storage:{local:{
    async get(names){return Object.fromEntries((Array.isArray(names)?names:[names]).filter(k=>localStorage.getItem(k)!==null).map(k=>[k,JSON.parse(localStorage.getItem(k))]));},
    async set(values){for(const [name,value]of Object.entries(values)){const oldValue=JSON.parse(localStorage.getItem(name)||"null");localStorage.setItem(name,JSON.stringify(value));for(const listener of listeners)listener({[name]:{oldValue,newValue:value}},"local");}}
  },onChanged:{addListener(fn){listeners.push(fn);}}},tabs:{async query(){return [{id:1}];},async sendMessage(){return {found:false};}}};
  window.addEventListener("storage",event=>{if(Object.values(globalThis.YTSteadyProfiles?.keys||{legacy:key}).includes(event.key))for(const listener of listeners)listener({[event.key]:{newValue:JSON.parse(event.newValue||"null")}},"local");});
})();
