"use strict";
document.getElementById('test').addEventListener('click',()=>{
  const original=globalThis.YTSteadySupport,I=YTSteadyI18n,choice=I.choice,mount=document.getElementById('mount'),report={version:original.version,scope:'Synthetic receiver; external navigation prevented; no payment made',checks:{},locales:[]};
  let current={...YTSteadySettings.defaults};
  function create(config){globalThis.YTSteadySupport=config;mount.replaceChildren();const view=new YTSteadyPlayerUI(mount,{settings:()=>current,draft(){},save(patch){current={...current,...patch};I.setLanguage(current.language);view.translate();}});view.togglePanel(true);return view;}
  try{
    const off=create({enabled:false,supportUrl:''});report.checks.unconfigured_hidden=off.elements.support.hidden&&!off.elements.supportLink.hasAttribute('href');
    const url='https://paypal.me/Example123',view=create({enabled:true,supportUrl:url});let clicks=0;
    view.shadow.addEventListener('click',event=>{if(event.composedPath().includes(view.elements.supportLink)){event.preventDefault();clicks++;}},true);
    for(const language of I.languages){I.setLanguage(language.code);view.translate();report.locales.push({code:language.code,dir:view.host.dir,label:view.elements.supportLink.textContent,pass:view.elements.supportLink.textContent===I.t('supportOneTime')&&!view.elements.support.hidden&&view.elements.supportLink.href===url});}
    report.checks.all_12_languages=report.locales.length===12&&report.locales.every(x=>x.pass);
    report.checks.external_tab_isolated=view.elements.supportLink.target==='_blank'&&view.elements.supportLink.relList.contains('noopener')&&view.elements.supportLink.relList.contains('noreferrer');
    view.elements.supportLink.click();report.checks.click_routes_to_configured_profile=clicks===1&&view.elements.supportLink.href===url;
    report.checks.no_amount_or_subscription_in_link=new URL(view.elements.supportLink.href).pathname==='/Example123'&&!new URL(view.elements.supportLink.href).search;
    I.setLanguage('en');view.translate();
    view.elements.supportLink.addEventListener('click',()=>{document.getElementById('result').textContent=JSON.stringify({...report,manualClickIntercepted:true},null,2);});
  }catch(error){report.checks.test_error=false;report.error=error.message;}
  finally{globalThis.YTSteadySupport=original;I.setLanguage(choice);document.getElementById('result').textContent=JSON.stringify(report,null,2);}
});
