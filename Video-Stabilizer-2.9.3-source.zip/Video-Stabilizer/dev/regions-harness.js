/* End-to-end region tests using captured synthetic VideoFrames only. */
(function(){
  "use strict";
  const $=id=>document.getElementById(id),wait=ms=>new Promise(r=>setTimeout(r,ms));
  const button=document.createElement("button");button.id="test-regions";button.textContent="測試比例與分區偵測";document.querySelector(".actions").append(button);
  const output=document.createElement("pre");output.id="regions-results";output.textContent="Region tests not run.";$("results").before(output);
  function scene(){
    const world=makeWorld(),ctx=world.getContext("2d");ctx.fillStyle="#ff2020";ctx.fillRect(692,342,16,16);
    const fg=document.createElement("canvas");fg.width=fg.height=800;const c=fg.getContext("2d");let seed=973;
    for(let y=0;y<800;y+=7)for(let x=0;x<800;x+=7){seed=Math.imul(seed,1664525)+1013904223|0;c.fillStyle=seed&0x40000000?"#fff":"#080808";c.fillRect(x,y,7,7);}
    return {world,fg};
  }
  const motion=n=>({x:Math.round((5*Math.sin(n*1.61)+2*Math.cos(n*.73))*2),y:Math.round(4*Math.sin(n*1.19)*2)});
  button.addEventListener("click",async()=>{
    button.disabled=true;const report={version:YTSteadySupport.version,environment:navigator.userAgent,cases:[],checks:{}};const show=()=>output.textContent=JSON.stringify(report,null,2);
    const video=document.querySelector("video"),wasPaused=video.paused;video.pause();
    try{
      const S=YTSteadySettings,P=YTSteadyPipeline,reader=new P.LumaReader(),{world,fg}=scene(),canvas=document.createElement("canvas"),ctx=canvas.getContext("2d",{alpha:false});
      const view=new P.Renderer(document.createElement("video"),document.createElement("div")),core=await P.createCore(name=>"/"+name);
      const cases=[...[[640,360],[1280,720],[1920,1080],[3840,2160],[720,1280]].flatMap(([width,height])=>["cross","x","adaptive"].map(mode=>({width,height,mode,precision:"standard"}))),{width:1920,height:1080,mode:"cross",precision:"fine"},{width:1920,height:1080,mode:"single",precision:"source",baseline:true},{width:384,height:216,mode:"cross",precision:"standard",lowResolutionControl:true},{width:384,height:216,mode:"cross",precision:"fine"},{width:853,height:479,mode:"cross",precision:"standard"},...[33.3,75,100].map(ratio=>({width:1920,height:1080,mode:"cross",precision:"fine",ratio,...(ratio===100?{singleControl:true}:{})})),{width:1920,height:1080,mode:"cross",precision:"fine",ratio:100,noForeground:true}];
      await P.exclusive(async()=>{
        for(const item of cases){
          document.getElementById("status").textContent=`分區測試：${item.width}×${item.height} · ${item.mode} · ${item.precision}`;
          canvas.width=item.width;canvas.height=item.height;const settings=S.normalize({...S.defaults,mode:item.mode,precision:item.precision,sampleRatio:item.baseline?100:item.precision==="fine"?50:YTSteadySettings.defaults.sampleRatio,centerRatio:item.baseline?33.3333:item.ratio??50}),plan=S.plan(settings,item.width,item.height),sx=item.width/1920,sy=item.height/1080;
          core.invalidate();core.activate(settings,plan,30);const errors=[],times=[],pairs=[],votes=[];let previous;
          for(let n=0;n<24;n++){
            const camera=motion(n);ctx.setTransform(sx,0,0,sy,0,0);ctx.drawImage(world,-320+camera.x,-200+camera.y);
            if(!item.noForeground)ctx.drawImage(fg,80+n*7,80+n*3,400,400,760,340,400,400);
            const frame=new VideoFrame(canvas,{timestamp:n*33333});
            try{
              const begin=performance.now();let m;
              if(plan.direct){await reader.read(frame,plan,core);m=core.processSingle(plan,settings);}
              else m=core.processRegions(reader.readRegions(frame,plan),plan,settings);
              times.push(performance.now()-begin);view.draw(frame,m,settings,n/30);
              if(n&&m.valid)errors.push(Math.hypot(m.dx/sx+camera.x-previous.x,m.dy/sy+camera.y-previous.y));
              if(m.regions)votes.push({selected:m.regions.selected,inliers:m.regions.inliers,candidates:m.regions.candidates});
              const x=(380+camera.x)*sx-m.mapX,y=(150+camera.y)*sy-m.mapY,w=Math.max(16,Math.ceil(24*sx)),h=Math.max(16,Math.ceil(24*sy)),left=Math.floor(x-w/2),top=Math.floor(y-h/2);
              const data=view.context.getImageData(left,top,w,h).data;let sumX=0,sumY=0,count=0;
              for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++){const p=(yy*w+xx)*4;if(data[p]>180&&data[p+1]<90&&data[p+2]<90){sumX+=left+xx+.5;sumY+=top+yy+.5;count++;}}
              if(count)pairs.push(Math.hypot(sumX/count-x,sumY/count-y));previous=camera;
            }finally{frame.close();}
            if(n%6===0)await wait(0);
          }
          const rms=a=>Math.sqrt(a.reduce((s,v)=>s+v*v,0)/Math.max(1,a.length)),sorted=times.slice().sort((a,b)=>a-b);
          report.cases.push({...item,actualRegions:plan.regions.length,valid:errors.length,total:23,motionErrorRms:rms(errors),pairErrorMax:Math.max(...pairs),pairs:pairs.length,meanAnalysisMs:times.reduce((a,b)=>a+b,0)/times.length,p95AnalysisMs:sorted[Math.floor(sorted.length*.95)],votes,footprint:[plan.winx,plan.winy],samples:[plan.analysisWidth,plan.analysisHeight]});show();
        }
      });
      // Preserve the failed 216p/Q25 observation as a sampling tradeoff control.
      // The requested quality range starts at 360p; 216p/Q50 is also checked
      // against the unchanged <2 reference-pixel RMS threshold.
      const regional=report.cases.filter(c=>!c.baseline&&!c.singleControl&&!c.lowResolutionControl),old=report.cases.find(c=>c.baseline),balanced=report.cases.find(c=>c.mode==="cross"&&c.width===1920&&c.precision==="standard");
      report.checks.crossResolutionMotion=regional.every(c=>c.valid>=18&&c.motionErrorRms<2);
      report.checks.lowResolutionSamplingImproves=report.cases.find(c=>c.width===384&&c.precision==="fine").motionErrorRms<report.cases.find(c=>c.lowResolutionControl).motionErrorRms*.5;
      report.checks.sameFrameOutput=report.cases.every(c=>c.pairs===24&&c.pairErrorMax<1.6);
      report.checks.gridBudget=regional.filter(c=>c.mode==="adaptive").every(c=>c.votes.every(v=>v.selected<=5&&v.candidates<=9));
      report.checks.movingForegroundImprovement=balanced.motionErrorRms<old.motionErrorRms*.5;
      report.checks.fullFrameIsSingleRegion=report.cases.filter(c=>c.ratio===100).every(c=>c.actualRegions===1);
      report.checks.everyFrameFinite=report.cases.every(c=>Number.isFinite(c.motionErrorRms)&&Number.isFinite(c.pairErrorMax));
      view.destroy();reader.reset();document.getElementById("status").textContent="分區與比例測試完成";show();
    }catch(error){report.checks.unexpectedError=false;report.error=error.message;show();document.getElementById("status").textContent="分區測試失敗："+error.message;}
    finally{button.disabled=false;const apply=document.querySelector("#yt-steady-controls")?.shadowRoot.querySelector("#apply");apply?.click();if(!wasPaused)await video.play();}
  });
})();

