"use strict";
const test=require("node:test"),assert=require("node:assert/strict"),fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto");
const I=require("../extension/i18n.js"),S=require("../extension/settings.js");
test("BCP47, Chinese scripts, regional fallbacks and explicit choices",()=>{
  for(const [tag,expected]of [["zh-Hant-HK","zh_TW"],["zh-TW","zh_TW"],["zh-Hans-SG","zh_CN"],["zh-CN","zh_CN"],["en-GB","en"],["es-419","es"],["pt-PT","pt_BR"],["ar-EG","ar"],["hi-IN","hi"],["de-DE","de"]])assert.equal(I.resolve("auto",[tag]),expected,tag);
  assert.equal(I.resolve("auto",["zz-ZZ","fr-CA"]),"fr");assert.equal(I.resolve("auto",["zz-ZZ"]),"en");
  assert.equal(I.resolve("ja",["en-US"]),"ja");assert.equal(I.normalizeChoice("__proto__"),"auto");
});
test("localized input round trips every supported language and every default parameter",()=>{
  for(const language of I.languages){I.setLanguage(language.code);
    for(const [name,spec]of Object.entries(S.fields)){
      const text=I.input(spec.value),parsed=I.validate(text,spec);
      assert.equal(parsed.value,spec.value,`${language.code}.${name}: ${text}`);
    }
  }
  I.setLanguage("fr");assert.equal(I.input(1.06),"1,06");I.setLanguage("auto",["ar-EG"]);assert.equal(I.dir,"rtl");assert.match(I.input(1.06),/[٠-٩]/);
  I.setLanguage("auto",["ar-MA"]);assert.equal(I.tag,"ar-MA");assert.equal(I.input(1.06),new Intl.NumberFormat("ar-MA",{useGrouping:false,maximumFractionDigits:4}).format(1.06));
});
test("accepts decimal comma, Arabic/Persian/Devanagari/fullwidth digits without grouping guesses",()=>{
  for(const text of ["1.06","1,06","١٫٠٦","۱٫۰۶","१.०६","１．０６","１，０６","\u20681.06\u2069"])assert.equal(I.parseNumber(text).value,1.06,text);
  for(const text of ["1,234.56","1.234,56","1 024","1\u202f024","١٬٠٢٤","NaN","Infinity","1e2","<script>","1,2,3"])assert.equal(I.parseNumber(text).error,"validationNumber",text);
  assert.equal(I.parseNumber("").error,"validationRequired");assert.equal(I.validate("0",S.fields.zoom).error,"validationRange");
  assert.equal(I.validate("0,71001",S.fields.cutoff).error,"validationStep");assert.equal(I.validate("٠٫٧٠",S.fields.cutoff).value,.7);
});
test("plain-text messages and bidi isolates preserve interpolated values",()=>{
  I.setLanguage("ar");const text=I.t("effective",{width:512,height:512,dx:192,dy:192});
  assert.match(text,/\u2068512\u2069/);assert.ok(!/\{\w+\}/.test(text));assert.equal(I.stripBidi("\u2068test\u2069"),"test");
  for(const language of I.languages){I.setLanguage(language.code);assert.notEqual(I.t("apply"),"apply");}
  I.setLanguage("en");assert.equal(I.t("unknown-key"),"unknown-key");
});
test("the shipped core and native source match the recorded build",()=>{
  const record=require("../src/core-build.json"),hash=file=>crypto.createHash("sha256").update(fs.readFileSync(path.resolve(__dirname,"..",file))).digest("hex");
  assert.equal(hash("extension/depan-core.wasm"),record.wasmSha256);assert.equal(hash("extension/depan-core.js"),record.jsSha256);assert.equal(hash("src/depan_core.cpp"),record.sourceSha256);assert.ok(record.exports.includes("_ys_region"));
});
