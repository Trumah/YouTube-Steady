"use strict";
const test=require("node:test"),assert=require("node:assert/strict"),fs=require("node:fs"),path=require("node:path");
const factory=require("../extension/depan-core.js");
const root=path.resolve(__dirname,"../validation/native"),reference=JSON.parse(fs.readFileSync(path.join(root,"reference.json"),"utf8"));
let core,input,result;
const report={version:require("../package.json").version,nativeReference:reference.native,correlation:null,stabilization:[]};
const ready=(async()=>{core=await factory();input=core._ys_input_ptr();result=core._ys_result_ptr()>>2;})();
function state(){return Array.from(core.HEAPF32.subarray(result,result+12));}
function configure(c={}){
  const code=core._ys_configure(512,512,192,192,4,1,c.cutoff??1.25,c.damping??1,c.dxmax??128,c.dymax??128,30);
  assert.equal(code,0);input=core._ys_input_ptr();return code;
}
function crop(world,info,n){
  const [dx,dy]=reference.positions[n],x=reference.cropOrigin[0]-dx,y=reference.cropOrigin[1]-dy;
  for(let row=0;row<512;row++)core.HEAPU8.set(world.subarray((y+row)*info.width+x,(y+row)*info.width+x+512),input+row*512);
}
test("correlation agrees with original installed DePanEstimate on identical luma",async()=>{
  await ready;configure();const worlds=reference.worlds.map(w=>fs.readFileSync(path.join(root,w.file)));
  let maxXY=0,maxTrust=0,validMismatches=0;
  for(let n=0;n<reference.positions.length;n++){
    const scene=reference.scenes[n];crop(worlds[scene],reference.worlds[scene],n);core._ys_process();const actual=state(),expected=reference.motions[n];
    if(n===0)continue;
    if(!!actual[5]!==expected.valid)validMismatches++;
    if(actual[5]&&expected.valid){
      // Original's randomly signed .011 marker is not physical motion.
      const dxError=Math.abs(expected.x)<=.012&&Math.abs(actual[0])<=.012?0:Math.abs(actual[0]-expected.x);
      maxXY=Math.max(maxXY,dxError,Math.abs(actual[1]-expected.y));
    }
    maxTrust=Math.max(maxTrust,Math.abs(actual[2]-reference.trust[n]));
  }
  assert.equal(validMismatches,0,`validity mismatches ${validMismatches}`);
  assert.ok(maxXY<.015,`maximum motion discrepancy ${maxXY}`);
  assert.ok(maxTrust<.015,`maximum trust discrepancy ${maxTrust}`);
  console.log(JSON.stringify({motionMaxError:maxXY,trustMaxError:maxTrust,frames:reference.positions.length}));
  report.correlation={motionMaxError:maxXY,trustMaxError:maxTrust,validMismatches,frames:reference.positions.length};
});
for(const c of reference.stabilization)test(`inertial filter matches native cutoff=${c.cutoff}, damping=${c.damping}`,async()=>{
  await ready;configure(c);let maximum=0;
  for(let n=0;n<reference.filterInput.length;n++){
    const m=reference.filterInput[n];core._ys_push_motion(m.x,m.y,m.valid?1:0);const actual=state();
    maximum=Math.max(maximum,Math.abs(actual[3]-c.values[n][0]),Math.abs(actual[4]-c.values[n][1]));
  }
  assert.ok(maximum<.01,`maximum native compensation discrepancy ${maximum}`);
  console.log(JSON.stringify({cutoff:c.cutoff,damping:c.damping,compensationMaxError:maximum}));
  report.stabilization.push({cutoff:c.cutoff,damping:c.damping,dxmax:c.dxmax,dymax:c.dymax,compensationMaxError:maximum});
});
test("accumulated compensation may exceed the per-frame search range",async()=>{
  await ready;assert.equal(core._ys_configure(128,128,10,10,4,1,1,.9,60,60,30),0);
  core._ys_push_motion(0,0,0);
  // Test the smoothing stage with valid motion, not the image matcher: five
  // individually searchable steps need more than 10 pixels of compensation.
  for(let n=0;n<5;n++)core._ys_push_motion(3,0,1);
  assert.ok(Math.abs(state()[3])>10&&Math.abs(state()[3])<60);
});
test("flat, seek reset, bad configuration, and long pan fail safely",async()=>{
  await ready;configure();core.HEAPU8.fill(50,input,input+512*512);core._ys_process();core._ys_process();
  assert.equal(state()[5],0);assert.equal(state()[3],0);assert.equal(state()[4],0);
  assert.equal(core._ys_configure(512,512,256,192,4,1,1.25,1,128,128,30),-1);
  assert.equal(core._ys_configure(512,512,192,192,4,1,NaN,1,128,128,30),-1);
  configure();for(let n=0;n<1500;n++){core._ys_push_motion(-3,-1,1);const s=state();assert.ok(Number.isFinite(s[3])&&Math.abs(s[3])<=192&&Math.abs(s[4])<=192);}
  core._ys_reset();core._ys_push_motion(0,0,0);assert.equal(state()[3],0);assert.equal(state()[4],0);
});
test("stiff nonlinear limits stay finite without resetting the valid motion history",async()=>{
  await ready;let cases=0,implicitCases=0;
  for(const fps of [5,15,24,30,60,120,240])for(const cutoff of [.2,1,5])for(const damping of [.25,.9,3])for(const limit of [.001,1,30,60,65536]){
    assert.equal(core._ys_configure(16,16,7,7,4,1,cutoff,damping,limit,limit,fps),0);core._ys_push_motion(0,0,0);let implicit=0;
    for(let n=1;n<=180;n++){core._ys_push_motion(3*Math.sin(n*.83),2*Math.cos(n*1.13),1);const s=state();assert.notEqual(s[8],4,JSON.stringify({fps,cutoff,damping,limit,n}));assert.ok(Number.isFinite(s[3])&&Number.isFinite(s[4]));assert.ok(Math.abs(s[3])<=limit*1.50001&&Math.abs(s[4])<=limit*1.50001);implicit+=s[11];}cases++;if(implicit)implicitCases++;
  }
  assert.equal(cases,315);assert.ok(implicitCases>0);report.stiffLimits={cases,framesEach:180,numericResets:0,implicitCases};
});
test("normal 1080p large-shake trajectory retains frozen 2.5.2 compensation",async()=>{
  await ready;const baseline=require("../validation/native/extension-2.5.2-motion.json");
  assert.equal(core._ys_configure(16,16,7,7,4,1,baseline.cutoff,baseline.damping,baseline.limitX,baseline.limitY,baseline.fps),0);let error=0,implicit=0;
  baseline.motions.forEach((m,n)=>{core._ys_push_motion(...m);const s=state();error=Math.max(error,Math.abs(s[3]-baseline.values[n][0]),Math.abs(s[4]-baseline.values[n][1]));implicit+=s[11];});
  assert.ok(error<.0001);assert.equal(implicit,0);report.normalLargeMotion={frames:baseline.motions.length,maxError:error,implicitSteps:implicit,baselineWasmSha256:baseline.wasmSha256};
});
test("expanded cutoff, zero damping and the finite float damping ceiling recover to ordinary settings",async()=>{
  await ready;let cases=0;
  for(const fps of [5,30,240])for(const cutoff of [.0001,120])for(const damping of [0,3,100,3.4028234663852886e38])for(const limit of [0,.000032,60,65536]){
    assert.equal(core._ys_configure(16,16,7,7,100,10,cutoff,damping,limit,limit,fps),0);core._ys_push_motion(0,0,0);
    for(let n=1;n<=90;n++){core._ys_push_motion(3*Math.sin(n*.83),2*Math.cos(n*1.13),1);const s=state();assert.notEqual(s[8],4);assert.ok(Number.isFinite(s[3])&&Number.isFinite(s[4]));assert.ok(Math.abs(s[3])<=limit*1.50001&&Math.abs(s[4])<=limit*1.50001);}cases++;
  }
  for(const [cutoff,damping]of [[0,1],[121,1],[1,-.01],[1,Infinity]])assert.equal(core._ys_configure(16,16,7,7,4,1,cutoff,damping,60,60,30),-1);
  configure();core._ys_push_motion(0,0,0);core._ys_push_motion(3,2,1);assert.equal(state()[3],-3);assert.equal(state()[4],-2);
  report.expandedLimits={cases,framesEach:90,numericResets:0};
});
test.after(()=>fs.writeFileSync(path.resolve(__dirname,"../validation/native-conformance.json"),JSON.stringify(report,null,2)+"\n"));
