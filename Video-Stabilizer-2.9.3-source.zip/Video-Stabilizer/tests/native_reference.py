"""Generate replay fixtures from the installed, unmodified AviSynth/DePan DLLs.
Only synthetic imagery and project-local output are used. No player UI/settings.
Run with Python + Pillow. Windows/AviSynth is needed only to regenerate fixtures.
"""
from pathlib import Path
import ctypes as c
import hashlib
import json
import math
import os
import struct
import sys
from PIL import Image, ImageDraw

PROJECT = Path(__file__).resolve().parents[1]
WORKSPACE = PROJECT.parents[1]
NATIVE = Path(r"C:\Program Files (x86)\K-Lite Codec Pack\MPC-HC64")
ENGINE = WORKSPACE / "outputs/MPC-HC-Steady-Trial/player"
OUT = PROJECT / "validation/native"
OUT.mkdir(parents=True, exist_ok=True)
_paths = [os.add_dll_directory(str(p)) for p in [NATIVE, ENGINE]]
_fftw = c.WinDLL(str(NATIVE / "libfftw3f-3.dll"))
avs_path = NATIVE / "AviSynth.dll"
if not avs_path.exists():
    avs_path = ENGINE / "AviSynth.dll"
DLL = c.WinDLL(str(avs_path))

class Data(c.Union):
    _fields_ = [("p",c.c_void_p),("s",c.c_char_p),("i",c.c_int),("f",c.c_float),("d",c.c_double)]
class Value(c.Structure):
    _fields_ = [("type",c.c_short),("size",c.c_short),("data",Data)]
class VideoInfo(c.Structure):
    _fields_ = [("width",c.c_int),("height",c.c_int),("fps_num",c.c_uint),("fps_den",c.c_uint),
                ("num_frames",c.c_int),("pixel_type",c.c_int),("audio_rate",c.c_int),
                ("sample_type",c.c_int),("audio_samples",c.c_int64),("channels",c.c_int),("image_type",c.c_int)]
def bind(name, result, args):
    f=getattr(DLL,name);f.restype=result;f.argtypes=args;return f
create=bind("avs_create_script_environment",c.c_void_p,[c.c_int])
invoke=bind("avs_invoke",Value,[c.c_void_p,c.c_char_p,Value,c.POINTER(c.c_char_p)])
release_value=bind("avs_release_value",None,[Value])
take_clip=bind("avs_take_clip",c.c_void_p,[Value,c.c_void_p])
release_clip=bind("avs_release_clip",None,[c.c_void_p])
delete_env=bind("avs_delete_script_environment",None,[c.c_void_p])
get_info=bind("avs_get_video_info",c.POINTER(VideoInfo),[c.c_void_p])
get_frame=bind("avs_get_frame",c.c_void_p,[c.c_void_p,c.c_int])
release_frame=bind("avs_release_video_frame",None,[c.c_void_p])
get_ptr=bind("avs_get_read_ptr_p",c.c_void_p,[c.c_void_p,c.c_int])
get_pitch=bind("avs_get_pitch_p",c.c_int,[c.c_void_p,c.c_int])
clip_error=bind("avs_clip_get_error",c.c_char_p,[c.c_void_p])
get_var=bind("avs_get_var",Value,[c.c_void_p,c.c_char_p])

class Clip:
    def __init__(self, script):
        self.env=create(6);self.clip=None
        arg=Value();arg.type=ord("s");arg.data.s=script.encode("utf-8")
        result=invoke(self.env,b"Eval",arg,None)
        if result.type==ord("e"):
            message=result.data.s.decode("utf-8","replace");release_value(result);self.close();raise RuntimeError(message)
        self.clip=take_clip(result,self.env);release_value(result)
        if not self.clip: self.close();raise RuntimeError("Script did not return a clip")
        self.info=get_info(self.clip).contents
    def frame(self,n,copy=True):
        f=get_frame(self.clip,n)
        if not f: raise RuntimeError((clip_error(self.clip) or b"frame failed").decode("utf-8","replace"))
        try:
            if copy:
                pitch=get_pitch(f,1);ptr=get_ptr(f,1)
                return b"".join(c.string_at(ptr+y*pitch,self.info.width) for y in range(self.info.height))
        finally: release_frame(f)
    def var(self,name):
        value=get_var(self.env,name.encode("ascii"))
        try:
            if value.type==ord("f"):return value.data.f
            if value.type==ord("d"):return value.data.d
            if value.type==ord("i"):return value.data.i
            raise RuntimeError(f"Variable {name} type {value.type}")
        finally:release_value(value)
    def close(self):
        if self.clip:release_clip(self.clip);self.clip=None
        if self.env:delete_env(self.env);self.env=None
    def __enter__(self):return self
    def __exit__(self,*args):self.close()

def world(path, seed):
    w=h=832
    pixels=bytearray(w*h)
    for y in range(h):
        for x in range(w):
            seed=(1664525*seed+1013904223)&0xffffffff
            value=110+31*math.sin(x*.117)+24*math.cos(y*.083)+21*math.sin(x*.071+y*.051)+(seed>>24)*.18
            pixels[y*w+x]=max(0,min(255,round(value)))
    image=Image.frombytes("L",(w,h),bytes(pixels))
    draw=ImageDraw.Draw(image)
    for i in range(45):
        x=35+(i*109)%700;y=30+(i*83)%710
        draw.rectangle((x,y,x+30+i%48,y+24+i%57),outline=30+(i*17)%180,width=2)
    image.convert("RGB").save(path)

def main():
    total=int(sys.argv[1]) if len(sys.argv)>1 else 210
    image_plugin=next((WORKSPACE/"work/extracted/AviSynthPlus-filesonly").glob("*/x64/plugins/ImageSeq.dll"))
    load=f'''ClearAutoloadDirs()
LoadPlugin("{image_plugin}")
LoadPlugin("{NATIVE/'DePan.dll'}")
LoadPlugin("{NATIVE/'DePanEstimate.dll'}")
'''
    positions=[]
    for n in range(total):
        positions.append([round(7*math.sin(n*1.7)+3*math.cos(n*.91)+n*.045),round(4*math.sin(n*2.21))])
    worlds=[]
    for i,seed in enumerate([0x7101,0x1819]):
        bmp=OUT/f"world-{i}.bmp";world(bmp,seed)
        with Clip(load+f'ImageSource("{bmp}",start=0,end=0,fps=30).ConvertToY8(matrix="PC.601")') as clip:
            plane=clip.frame(0);worlds.append({"file":f"world-{i}.bin","width":clip.info.width,"height":clip.info.height})
            (OUT/worlds[-1]["file"]).write_bytes(plane)
    declarations="\n".join(f'w{i}=ImageSource("{OUT/f"world-{i}.bmp"}",start=0,end=0,fps=30).ConvertToY8(matrix="PC.601")' for i in range(2))
    frames=[];which=[]
    for n,(x,y) in enumerate(positions):
        scene=1 if 83<=n<145 else 0;which.append(scene)
        frames.append(f"w{scene}.Crop({160-x},{160-y},512,512).Trim(0,0)")
    source=load+declarations+"\nsrc=("+" ++ ".join(frames)+").AssumeFPS(30)\n"
    extlog=OUT/"estimate.log"
    estimate=f'motion=DePanEstimate(src,range=0,winx=512,winy=512,dxmax=192,dymax=192,zoommax=1.0,extlog="{extlog}")\n'
    motions=[]
    with Clip(source+estimate+"motion") as clip:
        for n in range(total):
            raw=clip.frame(n)
            frame,dx,dy,zoom,rot=struct.unpack_from("<iffff",raw,16)
            assert frame==n,(frame,n,raw[:36])
            motions.append({"x":dx,"y":dy,"valid":dx!=0})
    trust=[]
    for line in extlog.read_text().splitlines():
        parts=line.split()
        if len(parts)>=5 and parts[0].isdigit():trust.append(float(parts[-1]))
    filter_input=[{"x":float(f'{m["x"]:.6f}'),"y":float(f'{m["y"]:.6f}'),"valid":m["valid"]} for m in motions]
    motion_log=OUT/"filter-input.log"
    motion_log.write_text("".join(f'{n:7d} {m["x"]:.6f} {m["y"]:.6f} 0 1\n' for n,m in enumerate(filter_input)),encoding="ascii")
    cases=[]
    for freq,damp,mx,my in [(1.25,1,128,128),(.7,1.2,96,128),(2.0,.8,128,64)]:
        values=[]
        final=f'DePanStabilize(src,data=motion,inputlog="{motion_log}",cutoff={freq},damping={damp},initzoom=1.0,addzoom=false,prev=0,next=0,dxmax={mx},dymax={my},zoommax=1.05,rotmax=0.0,subpixel=1,method=0,vdx="reference_dx",vdy="reference_dy")'
        # No extlog on this independent instance, so regeneration stays deterministic.
        plain_estimate=estimate.replace(f',extlog="{extlog}"',"")
        with Clip(source+plain_estimate+final) as clip:
            for n in range(total):
                clip.frame(n,False);values.append([clip.var("reference_dx"),clip.var("reference_dy")])
        cases.append({"cutoff":freq,"damping":damp,"dxmax":mx,"dymax":my,"values":values})
    data={"native":{"DePan":"2.15","DePanEstimate":"2.12","dllSha256":{name:hashlib.sha256((NATIVE/name).read_bytes()).hexdigest() for name in ["DePan.dll","DePanEstimate.dll"]}},
          "fps":30,"window":[512,512],"estimateMax":[192,192],"trustLimit":4,"stab":1,
          "worlds":worlds,"positions":positions,"scenes":which,"cropOrigin":[160,160],"motions":motions,"trust":trust,"filterInput":filter_input,"stabilization":cases}
    (OUT/"reference.json").write_text(json.dumps(data,indent=2),encoding="utf-8")
    print(json.dumps({"frames":total,"trustLines":len(trust),"cases":len(cases),"path":str(OUT/"reference.json")}),flush=True)
if __name__=="__main__":main()
