"use strict";
const test=require("node:test"),assert=require("node:assert/strict"),{iconPlacement,logPosition,logValue}=require("../extension/ui.js");
test("logarithmic cutoff travel preserves ratios, endpoints and precise Hz round trips",()=>{
  const {min,max}=require("../extension/settings.js").sliderSpec("cutoff"),near=(a,b)=>assert.ok(Math.abs(a-b)<1e-11*Math.max(1,Math.abs(b)));
  near(logValue(0,min,max),min);near(logValue(1,min,max),max);near(logValue(.5,min,max),Math.sqrt(min*max));
  const decades=[.0001,.001,.01,.1,1].map(hz=>logPosition(hz,min,max));for(let i=2;i<decades.length;i++)near(decades[i]-decades[i-1],decades[1]-decades[0]);
  for(const hz of [min,.0003,.0123,.6,1,1.2345,4.5678,max])near(logValue(logPosition(hz,min,max),min,max),hz);
  assert.equal(logPosition(12.3456,min,max),1);assert.equal(logPosition(min/10,min,max),0);
  for(let i=1;i<=100;i++)assert.ok(logValue(i/100,min,max)>logValue((i-1)/100,min,max));
});
test("icon positions stay clear of the actual control strip across player sizes",()=>{
  for(const [w,h,toolbar]of [[1714,964,902],[320,180,102],[1920,1080,990],[1080,1920,1810]])for(const p of [null,{x:0,y:0},{x:1,y:1},{x:.3,y:.7},{x:-5,y:5}]){
    const r=iconPlacement(w,h,toolbar,p);assert.ok(r.x>=12&&r.x+34<=w-12);assert.ok(r.y>=12&&r.y+34<=toolbar-8);
  }
  const small=iconPlacement(640,360,290,{x:.25,y:.75}),large=iconPlacement(1280,720,650,{x:.25,y:.75});
  assert.equal((small.x-small.left)/(small.right-small.left),.25);assert.equal((large.y-large.top)/(large.bottom-large.top),.75);
});
