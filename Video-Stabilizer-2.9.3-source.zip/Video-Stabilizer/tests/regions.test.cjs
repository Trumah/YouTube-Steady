"use strict";
const test=require("node:test"),assert=require("node:assert/strict"),path=require("node:path");
const S=require("../extension/settings.js"),R=require("../extension/regions.js");
globalThis.YTDePanModule=require("../extension/depan-core.js");require("../extension/renderer.js");
// Preserve the historical regression fixture independently of the user defaults.
const reference={...S.defaults,mode:"cross",centerRatio:50,sampleRatio:25,searchRange:25,compensationLimit:3,cutoff:1,damping:.9};
const P=globalThis.YTSteadyPipeline;
const custom={...reference,mode:"x"};
function world(seed){const a=new Uint8Array(512*512);for(let n=0;n<a.length;n++){seed=Math.imul(seed,1664525)+1013904223|0;a[n]=30+(seed>>>24)%190;}return a;}
const worlds=Array.from({length:9},(_,n)=>world(17+n*9871));
function tiles(plan,n,foreground=false,texture=null){return plan.regions.map(r=>{
  const pixels=new Uint8Array(r.analysisWidth*r.analysisHeight),dx=foreground&&r.id===4?-7*n:2*n,dy=foreground&&r.id===4?5*n:-n,src=worlds[r.id];
  for(let y=0;y<r.analysisHeight;y++)for(let x=0;x<r.analysisWidth;x++)pixels[y*r.analysisWidth+x]=src[(64+y-dy)*512+64+x-dx];
  return {...r,pixels,texture:texture?texture(r.id):40};
});}
async function core(settings){const c=await P.createCore(name=>path.resolve(__dirname,"../extension",name)),p=S.plan(settings,1920,1080);c.activate(settings,p,30);return {c,p};}
test("five independent references reject a textured moving center and advance smoothing once per frame",async()=>{
  const s=S.normalize(custom),{c,p}=await core(s);
  for(let n=0;n<7;n++){
    const m=c.processRegions(tiles(p,n,true),p,s);assert.equal(m.frame,n);
    if(!n){assert.equal(m.valid,false);continue;}
    assert.equal(m.valid,true);assert.ok(!m.regions.inlierIds.includes(4));assert.equal(m.regions.inliers,4);
    // DePan reports the correlation offset, opposite to the feature's shift.
    assert.ok(Math.abs(m.dx+8)<.15,JSON.stringify(m.regions));assert.ok(Math.abs(m.dy-4)<.15);
  }
  c.invalidate();c.activate(s,p,30);const reset=c.processRegions(tiles(p,9,true),p,s);assert.equal(reset.frame,0);assert.equal(reset.mapX,0);assert.equal(reset.reason,1);
});
test("adaptive cells that were not estimated still compare against the immediately preceding frame",async()=>{
  const s=S.normalize({...custom,mode:"adaptive"}),{c,p}=await core(s);
  c.processRegions(tiles(p,0,false,id=>id<5?40:0),p,s);
  const m=c.processRegions(tiles(p,1,false,id=>id>=4?40:0),p,s);
  assert.equal(m.valid,true);assert.ok(m.regions.ids.some(id=>id>=5));
  for(const v of m.regions.vectors.filter(v=>m.regions.ids.includes(v.id))){assert.equal(v.valid,true);assert.ok(Math.abs(v.dx+8)<.15);}
});
test("resolution changes reset all region references even when analysis dimensions stay the same",async()=>{
  const s=S.normalize(custom),{c,p}=await core(s);c.processRegions(tiles(p,0),p,s);c.processRegions(tiles(p,1),p,s);
  const large=S.plan(s,3840,2160);c.activate(s,large,30);const m=c.processRegions(tiles(large,2),large,s);
  assert.equal(m.frame,0);assert.equal(m.valid,false);assert.equal(m.mapX,0);assert.equal(m.mapY,0);
});
test("a cut to unrelated regional content rejects motion and clears accumulated compensation",async()=>{
  const s=S.normalize(custom),{c,p}=await core(s);
  for(let n=0;n<6;n++)c.processRegions(tiles(p,n),p,s);
  const next=tiles(p,0).map((sample,id)=>({...sample,pixels:world(91633+id*71).subarray(0,sample.analysisWidth*sample.analysisHeight)}));
  const cut=c.processRegions(next,p,s);assert.equal(cut.valid,false);assert.equal(cut.mapX,0);assert.equal(cut.mapY,0);
});
test("flat texture, conflicting votes and invalid region indices fail safely",async()=>{
  const s=S.normalize({...custom,mode:"adaptive"}),{c,p}=await core(s);
  const m=c.processRegions(tiles(p,0,false,()=>0),p,s);assert.equal(m.valid,false);assert.equal(m.regions.selected,0);assert.equal(m.mapX,0);
  c.module._ys_region(9,1);assert.equal(c.state().reason,-1);c.module._ys_region(-1,0);assert.equal(c.state().reason,-1);
  assert.equal(c.module._ys_region_configure(0,32,32,2147483647,1,1),-1);
  assert.throws(()=>c.processRegions([{...p.regions[0],pixels:new Uint8Array(1),texture:40}],p,s),/invalid-region-sample-length/);
  const samples=[0,1,2,3].map(id=>({id,texture:40,trust:10,valid:true,dx:id<2?-30:30,dy:0}));
  assert.equal(R.fuse(samples,[0,1,2,3],{...p,regions:p.regions.slice(0,4)},4).valid,false);
});
test("unreliable cells abstain but a single survivor or conflicting reliable majority cannot steer",()=>{
  const p=S.plan(custom,1920,1080),selected=[0,1,2,3,4];
  const samples=selected.map(id=>({id,texture:40,trust:id<2?8:2,valid:id<2,dx:10,dy:4}));
  const agreed=R.fuse(samples,selected,p,4);assert.equal(agreed.valid,true);assert.deepEqual(agreed.inliers,[0,1]);
  samples[1].valid=false;assert.equal(R.fuse(samples,selected,p,4).valid,false);
  samples.forEach((s,id)=>Object.assign(s,{valid:true,trust:8,dx:id<2?10:id===2?70:40}));
  assert.equal(R.fuse(samples,selected,p,4).valid,false);
});
test("joint confidence admits independent agreement without accepting weak or inconsistent evidence",()=>{
  const p=S.plan(custom,1920,1080),selected=[0,1,2,3,4];
  const samples=selected.map(id=>({id,texture:40,trust:3,valid:true,dx:20,dy:-8}));
  const all=R.fuse(samples,selected,p,4);assert.equal(all.valid,true);assert.ok(all.trust>=4);
  samples.forEach(s=>s.trust=1.9);assert.equal(R.fuse(samples,selected,p,4).valid,false);
  samples.forEach((s,id)=>Object.assign(s,{trust:3,dx:id*20}));assert.equal(R.fuse(samples,selected,p,4).valid,false);
  const single={...p,regions:[p.regions[0]]};assert.equal(R.fuse([{...samples[0],trust:3}],[0],single,4).valid,false);
});
test("an old cached core fails with a reload message and does not poison the next attempt",async()=>{
  const fs=require("node:fs"),vm=require("node:vm");
  const sandbox={YTSteadyRegions:R,YTDePanModule:async()=>({_ys_api_version:()=>2})};
  vm.runInNewContext(fs.readFileSync(path.resolve(__dirname,"../extension/renderer.js"),"utf8"),sandbox);
  await assert.rejects(sandbox.YTSteadyPipeline.createCore(()=>""),/core-version-mismatch-reload-extension/);
  sandbox.YTDePanModule=async()=>({_ys_api_version:()=>6,_ys_input_ptr:()=>0,_ys_result_ptr:()=>0});
  assert.ok(await sandbox.YTSteadyPipeline.createCore(()=>""));
});
test("different regional FFT sizes recover one representable source motion and reject a moving center",async()=>{
  for(const [width,height,mx,my]of [[1024,768,8,8],[512,384,4,4]]){
    const s=S.normalize({...reference,mode:"x",samplingMode:"fixed"}),p=S.plan(s,width,height),c=await P.createCore(n=>path.resolve(__dirname,"../extension",n));c.activate(s,p,30);
    for(let n=0;n<6;n++){
      const samples=p.regions.map(r=>{const pixels=new Uint8Array(r.analysisWidth*r.analysisHeight),dx=Math.round((r.id===4?-mx:mx)*n/r.scaleX),dy=Math.round(my*n/r.scaleY),src=worlds[r.id];
        for(let y=0;y<r.analysisHeight;y++)for(let x=0;x<r.analysisWidth;x++)pixels[y*r.analysisWidth+x]=src[(64+y-dy)*512+64+x-dx];
        return {...r,pixels,texture:40};});
      const m=c.processRegions(samples,p,s);assert.equal(m.frame,n);if(!n)continue;
      assert.equal(m.valid,true,JSON.stringify(m.regions));assert.equal(m.regions.inliers,4);assert.ok(!m.regions.inlierIds.includes(4));assert.ok(Math.abs(m.dx+mx)<.2);assert.ok(Math.abs(m.dy+my)<.2);
    }
    const cut=c.processRegions(p.regions.map(r=>({...r,pixels:world(81137+r.id*97).subarray(0,r.analysisWidth*r.analysisHeight),texture:40})),p,s);
    assert.equal(cut.valid,false);assert.equal(cut.mapX,0);assert.equal(cut.mapY,0);
    assert.equal(c.module._ys_region_configure(0,7,32,1,1,1),-1);assert.equal(c.module._ys_region_configure(9,32,32,1,1),-1);assert.equal(c.module._ys_region_configure(0,32,32,16,1),-1);
    assert.equal(c.module._ys_region_configure(0,32,32,1,1,2),-1);
  }
});
test("the unified source-precision single region preserves the old 360-frame pipeline",async()=>{
  const fs=require("node:fs"),dir=path.resolve(__dirname,"../validation/native"),ref=JSON.parse(fs.readFileSync(path.join(dir,"reference.json"))),data=ref.worlds.map(w=>fs.readFileSync(path.join(dir,w.file)));
  const s=S.normalize({...reference,mode:"single",centerRatio:100,sampleRatio:100}),p=S.plan(s,512,512),c=await P.createCore(n=>path.resolve(__dirname,"../extension",n));p.preserveNativeZero=true;c.activate(s,p,30); // Test-only native-zero reference; no user compatibility mode.
  assert.equal(p.direct,true);assert.equal(p.preserveNativeZero,true);
  const fill=n=>{const scene=ref.scenes[n],src=data[scene],span=ref.worlds[scene].width,[dx,dy]=ref.positions[n],x=ref.cropOrigin[0]-dx,y=ref.cropOrigin[1]-dy;for(let row=0;row<512;row++)c.module.HEAPU8.set(src.subarray((y+row)*span+x,(y+row)*span+x+512),c.input+row*512);};
  const baseline=[];for(let n=0;n<ref.positions.length;n++){fill(n);baseline.push(c.process());}
  c.invalidate();c.activate(s,p,30);
  for(let n=0;n<ref.positions.length;n++){fill(n);const m=c.processSingle(p,s),b=baseline[n];for(const key of ["dx","dy","mapX","mapY","trust"])assert.ok(Math.abs(m[key]-b[key])<.000001,key+" "+n);assert.equal(m.valid,b.valid);assert.equal(m.frame,b.frame);}
});
test("a small adaptive full-frame region still estimates motion through direct luma",async()=>{
  const s={...reference,mode:"adaptive",centerRatio:100,sampleRatio:100},p=S.plan(s,64,64),c=await P.createCore(n=>path.resolve(__dirname,"../extension",n));c.activate(s,p,30);assert.equal(p.direct,true);
  for(let n=0;n<3;n++){for(let y=0;y<64;y++)c.module.HEAPU8.set(worlds[0].subarray((64+y)*512+64-n*2,(64+y)*512+128-n*2),c.input+y*64);const m=c.processSingle(p,s);assert.equal(m.regions.selected,1);if(n){assert.equal(m.valid,true);assert.ok(Math.abs(m.dx+2)<.1);}}
});
function pixel(x,y,seed){let v=(Math.imul(x+seed,374761393)+Math.imul(y,668265263))|0;v=Math.imul(v^(v>>>13),1274126177);return (v^(v>>>16))>>>24;}
function imageTiles(p,n,overlays=false){return p.regions.map(r=>{const a=new Uint8Array(r.analysisWidth*r.analysisHeight),shift=overlays&&[0,2,6,8].includes(r.id)?0:n;for(let y=0;y<r.analysisHeight;y++)for(let x=0;x<r.analysisWidth;x++)a[y*r.analysisWidth+x]=pixel(x-shift*3+50,y-shift*2+50,r.id*3917);return {...r,pixels:a,texture:50};});}
test("source-percentage sampling handles odd FFT dimensions and fixed corner graphics",async()=>{
  for(const mode of ["cross","x"]){
    const s={...reference,mode,sampleRatio:100},p=S.plan(s,802,602),c=await P.createCore(n=>path.resolve(__dirname,"../extension",n));c.activate(s,p,30);
    assert.ok(p.regions.some(r=>r.analysisWidth%2||r.analysisHeight%2));
    for(let n=0;n<4;n++){const m=c.processRegions(imageTiles(p,n,true),p,s);if(!n)continue;assert.equal(m.valid,true);if(mode==="cross"){assert.ok(Math.abs(m.dx+3)<.15);assert.ok(Math.abs(m.dy+2)<.15);}else{assert.ok(Math.abs(m.dx)<.15);assert.ok(Math.abs(m.dy)<.15);}}
  }
});
test("4K at Q=100 grows memory, keeps pointers valid and recovers to small sampling",async()=>{
  const s={...reference,mode:"single",centerRatio:100,sampleRatio:100},p=S.plan(s,3840,2160),c=await P.createCore(n=>path.resolve(__dirname,"../extension",n)),before=c.module.HEAPU8.byteLength;
  c.activate(s,p,30);assert.equal(c.module._ys_input_capacity(),3840*2160);assert.equal(c.input,c.module._ys_input_ptr());assert.ok(c.module.HEAPU8.byteLength>before);
  c.module.HEAPU8.fill(80,c.input,c.input+3840*2160);assert.equal(c.processSingle(p,s).frame,0);assert.equal(c.processSingle(p,s).valid,false);
  const small=S.plan(reference,640,360);c.activate(reference,small,30);assert.equal(c.input,c.module._ys_input_ptr());const m=c.processRegions(imageTiles(small,0),small,reference);assert.equal(m.frame,0);assert.equal(m.mapX,0);
});
test("percentage sampling does not merge distinct foreground motion at lower source resolutions",()=>{
  for(const [width,height]of [[640,360],[853,479],[1920,1080],[3840,2160]]){
    const p=S.plan(reference,width,height),unit=width/1920,dx=-12*unit;
    const samples=p.regions.map(r=>({...r,texture:40,trust:10,valid:true,dx:dx+(r.id===4?8*unit:0),dy:0}));
    const m=R.fuse(samples,samples.map(r=>r.id),p,4);assert.equal(m.valid,true);assert.equal(m.inliers.length,4);assert.ok(!m.inliers.includes(4));assert.ok(Math.abs(m.dx-dx)<1e-9);
  }
});

async function regionalMotion(searchRange,mx,my){
  const settings={...reference,searchRange},plan=S.plan(settings,1920,1080),c=await P.createCore(n=>path.resolve(__dirname,"../extension",n));c.activate(settings,plan,30);let motion;
  for(let n=0;n<2;n++){const samples=plan.regions.map(r=>{const pixels=new Uint8Array(r.analysisWidth*r.analysisHeight),dx=Math.round(mx*n/r.scaleX),dy=Math.round(my*n/r.scaleY),src=worlds[r.id];for(let y=0;y<r.analysisHeight;y++)for(let x=0;x<r.analysisWidth;x++)pixels[y*r.analysisWidth+x]=src[(128+y-dy)*512+128+x-dx];return {...r,pixels,texture:40};});motion=c.processRegions(samples,plan,settings);}
  return motion;
}
test("regional S30 recovers large horizontal motion using wide regions without narrow-region veto",async()=>{
  const limited=await regionalMotion(20,224,0),wide=await regionalMotion(30,224,0);assert.equal(limited.valid,false);assert.equal(wide.valid,true);assert.deepEqual(wide.regions.inlierIds,[1,4,7]);assert.ok(Math.abs(wide.dx+224)<.05&&Math.abs(wide.dy)<.05);assert.ok(wide.regions.vectors.filter(v=>[3,5].includes(v.id)).every(v=>!v.valid));console.log(JSON.stringify({regionalSearchMotion:{search:30,expected:[-224,0],actual:[wide.dx,wide.dy],inliers:wide.regions.inlierIds}}));
});
test("one wide diagonal estimate is insufficient; larger S allows independent agreement",async()=>{
  const one=await regionalMotion(30,160,100),many=await regionalMotion(40,160,100);assert.equal(one.valid,false);assert.equal(one.regions.vectors.filter(v=>v.valid).length,1);assert.equal(many.valid,true);assert.equal(many.regions.inliers,5);assert.ok(Math.abs(many.dx+160)<1&&Math.abs(many.dy+100)<1);console.log(JSON.stringify({regionalSearchMotion:{search:40,expected:[-160,-100],actual:[many.dx,many.dy],inliers:many.regions.inlierIds}}));
});
