"use strict";
const test=require('node:test'),assert=require('node:assert/strict'),D=require('../src/distribution.cjs');
test('one-time support accepts only an unpriced PayPal.Me profile',()=>{
  assert.equal(D.supportUrl(''),'');assert.equal(D.supportUrl('https://www.paypal.me/Example123/'),'https://paypal.me/Example123');
  for(const value of ['http://paypal.me/test','https://paypal.me.evil.invalid/test','https://paypal.me@evil.invalid/test','https://user:pass@paypal.me/test','https://paypal.me/test/10','https://paypal.me/test?amount=5','https://paypal.me/test#x','https://paypal.me:8443/test','https://www.paypal.com/subscribe','javascript:alert(1)',' https://paypal.me/test','https://paypal.me/'])
    assert.throws(()=>D.supportUrl(value),undefined,value);
});
test('repository configuration cannot inject URLs, commands or local paths',()=>{
  assert.equal(D.repository(''),'');assert.equal(D.repository('example/youtube-steady'),'example/youtube-steady');
  for(const value of ['https://github.com/a/b','a/b.git','a/b/../../c','a/b;whoami','a\\b','a/b\n','-a/b'])assert.throws(()=>D.repository(value),undefined,value);
});
test('shipping support stays unavailable until a real receiver is provided',()=>{
  const config=require('../src/distribution.json'),support=require('../extension/support.js');
  assert.equal(support.supportUrl,D.supportUrl(config.supportUrl));assert.equal(support.enabled,!!support.supportUrl);
  assert.equal(support.version,require('../extension/manifest.json').version);
  assert.equal(support.repository,D.repository(config.repository));
});
