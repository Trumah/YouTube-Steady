"use strict";
const test=require("node:test"),assert=require("node:assert/strict"),fs=require("node:fs"),path=require("node:path"),vm=require("node:vm");
const S=require("../extension/settings.js"),{cropPolygon,compensationBand,searchArrows,cellStates}=require("../extension/overlay.js");
// Preserve the historical regression fixture independently of the user defaults.
const reference={...S.defaults,mode:"cross",centerRatio:50,sampleRatio:25,searchRange:25,compensationLimit:3,cutoff:1,damping:.9};
const bounds=p=>[Math.min(...p.map(v=>v.x)),Math.min(...p.map(v=>v.y)),Math.max(...p.map(v=>v.x)),Math.max(...p.map(v=>v.y))];
const close=(a,b)=>a.forEach((v,n)=>assert.ok(Math.abs(v-b[n])<1e-7,JSON.stringify([a,b])));

test("compensation thickness is per edge, including portrait and unequal legacy axes",()=>{
  for(const [w,h]of [[640,360],[1920,1080],[3840,2160],[1080,1920]]){
    const p=S.plan(reference,w,h),b=compensationBand(w,h,p.limitX,p.limitY);
    close([b.x,b.y,b.width,b.height],[w*.03,h*.03,w*.94,h*.94]);
  }
  const b=compensationBand(1920,1080,70,22);close([b.x,b.y,b.width,b.height],[70,22,1780,1036]);
});

test("zero compensation has no band and overlapping edges never invert the inner rectangle",()=>{
  assert.equal(compensationBand(1920,1080,0,0).path,"");
  for(const [x,y]of [[960,540],[1920,1080],[0,1080],[1920,0]]){
    const b=compensationBand(1920,1080,x,y);assert.equal(b.path,"M0 0H1920V1080H0Z");assert.ok(b.width>=0&&b.height>=0);
  }
  const b=compensationBand(1920,1080,0,30);close([b.x,b.y,b.width,b.height],[0,30,1920,1020]);
});

test("C stays independent of requested and grid-limited search S",()=>{
  const plans=[0,1,50].map(searchRange=>S.plan({...reference,centerRatio:80,searchRange,compensationLimit:20},1920,1080));
  assert.equal(plans[0].effectiveSearchMin,0);assert.ok(plans[2].searchLimited);
  for(const p of plans){close([p.limitX,p.limitY],[384,216]);assert.deepEqual(compensationBand(1920,1080,p.limitX,p.limitY),compensationBand(1920,1080,384,216));}
});
test("zoom crop reflects the actual screen viewport and source displacement",()=>{
  const matrix={a:1,b:0,c:0,d:1,e:100,f:50},view={left:100,top:50,right:1100,bottom:550};
  close(bounds(cropPolygon(1000,500,{x:0,y:0},matrix,view)),[0,0,1000,500]);
  close(bounds(cropPolygon(1000,500,{x:0,y:0},matrix,view,1.25)),[100,50,900,450]);
  close(bounds(cropPolygon(1000,500,{x:30,y:-20},matrix,view,1.25)),[130,30,930,430]);
});
test("pillarboxing does not invent a horizontal crop when zoom still fits; mirrored CSS remains correct",()=>{
  const m={a:900/768,b:0,c:0,d:900/768,e:200,f:0},view={left:0,top:0,right:1600,bottom:900};
  close(bounds(cropPolygon(1024,768,{x:0,y:0},m,view,1.1)),[0,768/2-768/2/1.1,1024,768/2+768/2/1.1]);
  close(bounds(cropPolygon(1000,500,{x:0,y:0},{a:-1,b:0,c:0,d:1,e:1000,f:0},{left:0,top:0,right:1000,bottom:500},1.25)),[100,50,900,450]);
  assert.deepEqual(cropPolygon(1000,500,{x:0,y:0},{a:0,b:0,c:0,d:0,e:0,f:0},view),[]);
});
test("preview never invents adaptive selections, applied highlights use the actual frame's IDs",()=>{
  const p=S.plan({...reference,mode:"adaptive"},1920,1080),motion={regions:{ids:[0,2,4,6,8],inlierIds:[0,2,6,8]}};
  assert.ok(cellStates(p,motion,true).every(c=>c.state==="candidate"));
  const live=cellStates(p,motion,false);assert.equal(live.find(c=>c.id===4).state,"selected");assert.equal(live.find(c=>c.id===0).state,"inlier");assert.equal(live.find(c=>c.id===1).state,"candidate");
  const cross=S.plan(reference,1920,1080);assert.equal(cellStates(cross,null,true).filter(c=>c.state==="planned").length,5);
});
function clockOverlay(){
  let now=0,id=0;const timers=new Map(),node=()=>({style:{},dataset:{},setAttribute(){},append(){},remove(){this.removed=true;}});
  const doc={createElement(){const n=node();n.attachShadow=()=>({innerHTML:"",getElementById:()=>node()});return n;},createElementNS:()=>node()};
  const ctx={YTSteadySettings:S,YTSteadyI18n:{},document:doc,performance:{now:()=>now},setTimeout:(fn,ms)=>{timers.set(++id,{at:now+ms,fn});return id;},clearTimeout:n=>timers.delete(n)};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname,"../extension/overlay.js"),"utf8"),ctx);
  const overlay=new ctx.YTSteadyOverlay({}, {videoWidth:1920,videoHeight:1080});overlay.build=()=>{};overlay.update=()=>{};
  return {overlay,timers,advance(ms){now+=ms;for(const [key,t]of [...timers])if(t.at<=now){timers.delete(key);t.fn();}}};
}
test("overlay expires five seconds after the latest valid edit and invalid drafts do not restart it",()=>{
  const h=clockOverlay(),o=h.overlay;assert.equal(o.show(reference),true);h.advance(4000);o.show({...reference,centerRatio:60});h.advance(1500);assert.equal(o.visible,true);
  assert.equal(o.show({...reference,mode:"single",centerRatio:1},{state:{size:{width:320,height:180}}}),false);h.advance(3499);assert.equal(o.visible,true);h.advance(1);assert.equal(o.visible,false);assert.equal(h.timers.size,0);
});
test("destroy clears preview timers and DOM, including when a fade is pending",()=>{
  const h=clockOverlay();h.overlay.show(reference);h.advance(4900);h.overlay.destroy();assert.equal(h.timers.size,0);assert.equal(h.overlay.host.removed,true);assert.equal(h.overlay.visible,false);assert.equal(h.overlay.show(reference),false);
});

test("search arrows end at each region's actual positive and negative offsets",()=>{
  const p=S.plan({...reference,searchRange:30},1920,1080);for(const r of p.regions){const a=searchArrows(r);assert.equal(a.dx,r.analysisDx*r.scaleX);assert.equal(a.dy,r.analysisDy*r.scaleY);assert.ok(a.x-a.dx>=r.left&&a.x+a.dx<=r.left+r.width);assert.ok(a.y-a.dy>=r.top&&a.y+a.dy<=r.top+r.height);assert.ok(a.path.includes("H")&&a.path.includes("V"));}
  for(const r of S.plan({...reference,searchRange:0},1920,1080).regions)assert.equal(searchArrows(r).path,"");
});
