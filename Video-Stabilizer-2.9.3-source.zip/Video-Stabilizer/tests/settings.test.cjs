"use strict";
const test=require("node:test"),assert=require("node:assert/strict");
const S=require("../extension/settings.js");
// Geometry/cost regressions keep their original explicit five-region fixture.
const reference={...S.defaults,mode:"cross",centerRatio:50,sampleRatio:25,searchRange:25,compensationLimit:3,cutoff:1,damping:.9};
test("full numeric input ranges are independent of common slider travel",()=>{
  const I=require("../extension/i18n.js");
  for(const [name,value]of [["centerRatio",0],["sampleRatio",.0001],["zoom",1.005],["zoom",.5],["zoom",32768],["cutoff",.0001],["cutoff",120],["damping",0],["damping",.92],["damping",S.fields.damping.max],["trust",100],["stab",10],["compensationLimit",204800]])assert.equal(I.validate(I.input(value),S.fields[name]).value,value,name);
  for(const [name,value]of [["sampleRatio",0],["zoom",0],["zoom",32768.0001],["cutoff",0],["cutoff",120.0001],["damping",-1],["trust",100.0001],["stab",10.0001]])assert.ok(I.validate(String(value),S.fields[name]).error,name);
  assert.equal(S.sliderSpec("zoom").max,4);assert.equal(S.sliderSpec("compensationLimit").max,100);assert.equal(S.sliderSpec("damping").max,3);
  const bad=S.normalize({...S.defaults,zoom:0,cutoff:-1,sampleRatio:0});assert.equal(bad.zoom,1);assert.equal(bad.cutoff,.5);assert.equal(bad.sampleRatio,30);
  const precise=S.normalize({...S.defaults,zoom:1.005,cutoff:1.01,damping:.92,trust:4.05,stab:.05});for(const name of ["zoom","cutoff","damping","trust","stab"])assert.equal(precise[name],{zoom:1.005,cutoff:1.01,damping:.92,trust:4.05,stab:.05}[name]);
});
test("R zero keeps real corner regions and rejects layouts with no usable area",()=>{
  for(const mode of ["x","adaptive"]){const p=S.plan({...S.defaults,centerRatio:0,mode},1920,1080);assert.deepEqual(p.regions.map(r=>r.id),[0,2,6,8]);assert.equal(p.cells[4].width,0);}
  for(const mode of ["single","cross"])assert.throws(()=>S.plan({...S.defaults,centerRatio:0,mode},1920,1080),/analysis-regions-too-small/);
  const tiny=S.plan({...S.defaults,sampleRatio:.0001},1920,1080);assert.ok(tiny.samplingRaised);assert.ok(tiny.regions.every(r=>r.analysisWidth===8&&r.analysisHeight===8));
});
test("C source-dependent core ceiling preserves requests independently of S",()=>{
  const settings=S.normalize({...S.defaults,compensationLimit:204800,searchRange:1});
  for(const [w,h]of [[32,32],[1920,1080],[1080,1920],[32768,32768]]){const p=S.plan({...settings,centerRatio:100,mode:"single",sampleRatio:1},w,h);assert.equal(Math.max(p.limitX,p.limitY),65536);assert.ok(p.limitX>=0&&p.limitY>=0);assert.equal(settings.compensationLimit,204800);assert.equal(p.compensationLimited,w!==32||h!==32);}
  const p=S.plan({...settings,compensationLimit:120},1920,1080);assert.equal(p.limitX,2304);assert.equal(p.compensationLimited,false);
});
test("icon preferences migrate independently and malformed positions cannot escape the player",()=>{
  const old=S.normalize({...S.defaults,schema:7,iconHidden:true,iconPosition:{x:.25,y:.75},zoom:1.005});assert.deepEqual(S.iconPreferences(old),{iconHidden:true,iconPosition:{x:.25,y:.75}});assert.equal(old.zoom,1.005);
  assert.deepEqual(S.iconPreferences({iconPosition:{x:-9,y:8}}),{iconHidden:false,iconPosition:{x:0,y:1}});
  assert.equal(S.normalize({...S.defaults,iconPosition:{x:Infinity,y:.5}}).iconPosition,null);
  const reset=S.normalize({...S.defaults,...S.iconPreferences(old)});assert.equal(reset.iconHidden,true);assert.deepEqual(reset.iconPosition,old.iconPosition);
});
test("new profiles use the requested central-region defaults across source resolutions and language changes",()=>{
  const expected={mode:"single",centerRatio:85,sampleRatio:30,centerPriority:false,searchRange:30,compensationLimit:15,cutoff:.5,damping:.3,trust:4,stab:1,subpixel:1,zoom:1,iconHidden:false,language:"auto"};
  const s=S.normalize(null);for(const [key,value]of Object.entries(expected))assert.equal(s[key],value,key);assert.equal(s.units,"percent");
  const saved=S.normalize({...s,language:"ar"});for(const key of Object.keys(expected).filter(k=>k!=="language"))assert.equal(saved[key],s[key],key);
  for(const [w,h]of [[1280,720],[1920,1080],[3840,2160]]){
    const p=S.plan(s,w,h);assert.deepEqual(p.regions.map(r=>r.id),[4]);assert.equal(p.analysisWidth,Math.round(w*.85*.3));assert.equal(p.analysisHeight,Math.round(h*.85*.3));
    assert.equal(p.winx/w,.85);assert.equal(p.winy/h,.85);assert.equal(p.searchMode,"regional");
    assert.ok(Math.abs(p.limitX/w-.15)<.00001);assert.ok(Math.abs(p.limitY/h-.15)<.00001);
  }
});
test("small, odd, portrait and large full-frame regions stay within bounds",()=>{
  for(const mode of S.modes)for(const [w,h]of [[32,32],[53,37],[1080,1920],[3840,2160]]){const p=S.plan({...S.defaults,mode,centerRatio:100},w,h);assert.equal(p.regions.length,1);assert.ok(p.analysisDx<p.analysisWidth/2&&p.analysisDy<p.analysisHeight/2);for(const r of p.regions)assert.ok(r.left>=0&&r.top>=0&&r.left+r.width<=w&&r.top+r.height<=h);}
});

test("R=50 partitions 1024x768 exactly into the requested center, edges and corners",()=>{
  const p=S.plan({...reference,mode:"adaptive",parameterModel:"legacy",samplingMode:"fixed"},1024,768);
  assert.deepEqual(p.cells.map(r=>[r.width,r.height]),[[256,192],[512,192],[256,192],[256,384],[512,384],[256,384],[256,192],[512,192],[256,192]]);
  assert.equal(p.regions.length,9);assert.equal(p.cells.reduce((sum,r)=>sum+r.width*r.height,0),1024*768);
  assert.equal(p.regions[4].analysisDx*p.regions[4].scaleX,128);
  assert.equal(p.regions[0].analysisDx*p.regions[0].scaleX,64);
  assert.ok(S.grid(1920,1080,33.3333).every(r=>r.width===640&&r.height===360));

});
test("odd, portrait and extreme ratios cover every source pixel once without enlarging tiny cells",()=>{
  for(const [w,h]of [[53,37],[853,479],[720,1280],[3840,2160]])for(const ratio of [1,33.3,50,75,99.9,100]){
    const cells=S.grid(w,h,ratio);assert.equal(cells.reduce((sum,r)=>sum+r.width*r.height,0),w*h);
    for(let a=0;a<9;a++)for(let b=a+1;b<9;b++)assert.equal(Math.max(0,Math.min(cells[a].left+cells[a].width,cells[b].left+cells[b].width)-Math.max(cells[a].left,cells[b].left))*Math.max(0,Math.min(cells[a].top+cells[a].height,cells[b].top+cells[b].height)-Math.max(cells[a].top,cells[b].top)),0);
    const s={...S.defaults,mode:"adaptive",centerRatio:ratio};
    if(!cells.some(c=>c.width>=32&&c.height>=32)){assert.throws(()=>S.plan(s,w,h),/analysis-regions-too-small/);continue;}
    const p=S.plan(s,w,h);
    for(const r of p.regions){assert.ok(r.width>=32&&r.height>=32);assert.ok(r.analysisWidth<=r.width&&r.analysisHeight<=r.height);assert.ok(r.analysisDx<r.analysisWidth/2&&r.analysisDy<r.analysisHeight/2);}
  }
});
test("zero-weight regions are excluded; full-frame R=100 is one actual vote",()=>{
  const single=S.plan({...S.defaults,mode:"single"},1024,768);assert.deepEqual(single.regions.map(r=>r.id),[4]);assert.equal(single.cells.filter(r=>!r.weight).length,8);
  for(const mode of S.modes){const p=S.plan({...S.defaults,mode,centerRatio:100},1024,768);assert.deepEqual(p.regions.map(r=>r.id),[4]);}
  assert.throws(()=>S.plan({...S.defaults,mode:"single",centerRatio:1},320,180),/analysis-regions-too-small/);
});
test("cross and X masks share R geometry but use different five-region layouts",()=>{
  const cross=S.plan(reference,1024,768),x=S.plan({...reference,mode:"x"},1024,768);
  assert.deepEqual(cross.regions.map(r=>r.id),[1,3,4,5,7]);assert.deepEqual(x.regions.map(r=>r.id),[0,2,4,6,8]);
  assert.equal(cross.regions.reduce((n,r)=>n+r.width*r.height,0),1024*768*.75);
  assert.equal(x.regions.reduce((n,r)=>n+r.width*r.height,0),1024*768*.5);
  assert.ok(cross.regions.every(r=>r.weight===1));assert.equal(S.plan({...reference,centerPriority:true},1024,768).regions.find(r=>r.id===4).weight,2);
});
test("Q scales sampling with each source from 360p to 4K, including 100 percent and odd sizes",()=>{
  for(const [w,h]of [[640,360],[1920,1080],[3840,2160],[853,479]])for(const q of [1,25,50,100]){
    const p=S.plan({...S.defaults,sampleRatio:q},w,h);assert.equal(p.work.supported,true);
    for(const r of p.regions){assert.equal(r.analysisWidth,Math.min(r.width,Math.max(8,Math.round(r.width*q/100))));assert.equal(r.analysisHeight,Math.min(r.height,Math.max(8,Math.round(r.height*q/100))));assert.ok(r.analysisDx*2<r.analysisWidth&&r.analysisDy*2<r.analysisHeight);}
    if(q===100)assert.ok(p.regions.every(r=>r.scaleX===1&&r.scaleY===1));
  }
  const full=S.plan({...S.defaults,mode:"single",centerRatio:100,sampleRatio:100},3840,2160);
  assert.equal(full.analysisWidth,3840);assert.equal(full.analysisHeight,2160);assert.equal(full.direct,true);
  assert.equal(S.plan({...S.defaults,mode:"single",centerRatio:100,sampleRatio:100},32768,32768).work.supported,false);
});
test("work estimates expose resolution, quadratic sample growth and adaptive uncertainty",()=>{
  const a=S.plan(reference,1920,1080),b=S.plan({...reference,sampleRatio:50},1920,1080),large=S.plan(reference,3840,2160),small=S.plan(reference,640,360),adaptive=S.plan({...reference,mode:"adaptive"},1920,1080);
  assert.ok(Math.abs(a.work.relativeMax-1)<1e-12);
  assert.ok(b.work.samplePixels/a.work.samplePixels>3.95&&b.work.samplePixels/a.work.samplePixels<4.05);
  assert.ok(b.work.relativeMax>4&&large.work.relativeMax>4);assert.ok(small.work.relativeMax<.12);
  assert.ok(adaptive.work.relativeMin<adaptive.work.relativeMax);assert.equal(adaptive.work.selected,5);
  assert.ok(b.work.workingBytes>a.work.workingBytes);
});
test("unified R ignores old width/height and supports zero search or zero compensation",()=>{
  const p=S.plan({...reference,windowLayout:"custom",winx:99,winy:2,searchRange:0,compensationLimit:0},1024,768);
  assert.equal(p.winx,512);assert.equal(p.winy,384);assert.ok(p.regions.every(r=>r.analysisDx===0&&r.analysisDy===0));assert.equal(p.limitX,0);assert.equal(p.limitY,0);
});

test("all normalized settings use schema9 regional geometry and discard old axis fields",()=>{
  assert.deepEqual(S.normalize(null),S.defaults);assert.equal(S.defaults.schema,9);assert.equal(S.defaults.searchRange,30);assert.equal(S.defaults.zoom,1);assert.equal(S.defaults.subpixel,1);
  const n=S.normalize({parameterModel:"legacy",units:"pixels",windowLayout:"custom",samplingMode:"fixed",searchMode:"manual",winx:512,estimateDx:100,zoom:1.2,cutoff:.7});
  assert.equal(n.parameterModel,"unified");assert.equal(n.windowLayout,"grid");assert.equal(n.samplingMode,"relative");assert.equal(n.searchMode,"regional");assert.ok(!("winx" in n)&&!("estimateDx" in n));assert.equal(n.zoom,1.2);assert.equal(n.cutoff,.7);
});
test("invalid numerical values remain bounded and finite",()=>{
  const n=S.normalize({zoom:NaN,cutoff:Infinity,damping:-10,searchRange:1e9,compensationLimit:-1,trust:"4",subpixel:9});assert.equal(n.zoom,1);assert.equal(n.cutoff,.5);assert.equal(n.damping,0);assert.equal(n.searchRange,50);assert.equal(n.compensationLimit,0);assert.equal(n.trust,4);assert.equal(n.subpixel,1);
});
test("S is region-relative while C remains source-relative at every resolution",()=>{
  for(const [w,h]of [[640,360],[1024,768],[853,479],[3840,2160],[720,1280]]){const p=S.plan({...S.defaults,searchRange:25,compensationLimit:3,sampleRatio:100},w,h);assert.equal(p.searchMode,"regional");assert.equal(p.searchLimited,false);assert.ok(Math.abs(p.limitX-w*.03)<1e-9&&Math.abs(p.limitY-h*.03)<1e-9);for(const r of p.regions){assert.equal(r.analysisDx,Math.floor(r.width*.25+1e-9));assert.equal(r.analysisDy,Math.floor(r.height*.25+1e-9));}}
});
test("each region and axis reaches its own lattice cap without capping other regions",()=>{
  for(const mode of S.modes)for(const centerRatio of [10,33.3,50,80,100])for(const sampleRatio of [1,25,100]){const settings={...S.defaults,mode,centerRatio,sampleRatio,searchRange:50},p=S.plan(settings,853,479);assert.equal(settings.searchRange,50);assert.equal(p.searchLimited,true);for(const r of p.regions){assert.equal(r.analysisDx,Math.floor((r.analysisWidth-1)/2));assert.equal(r.analysisDy,Math.floor((r.analysisHeight-1)/2));assert.ok(r.analysisDx*r.scaleX<r.width/2&&r.analysisDy*r.scaleY<r.height/2);}}
});
test("S20,30,40 no longer collapse to one full-frame search ceiling",()=>{
  const plans=[20,30,40].map(searchRange=>S.plan({...reference,searchRange},1920,1080));for(let i=1;i<plans.length;i++)for(let r=0;r<plans[i].regions.length;r++){assert.ok(plans[i].regions[r].analysisDx>plans[i-1].regions[r].analysisDx);assert.ok(plans[i].regions[r].analysisDy>plans[i-1].regions[r].analysisDy);}
  const p=S.plan({...reference,centerRatio:70,searchRange:30},1920,1080),center=p.regions.find(r=>r.id===4),side=p.regions.find(r=>r.id===3);assert.ok(center.analysisDx*center.scaleX>350);assert.ok(side.analysisDx*side.scaleX<100);assert.equal(p.searchLimited,false);
});
