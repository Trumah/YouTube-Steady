"use strict";
const test=require("node:test"),assert=require("node:assert/strict"),S=require("../extension/settings.js"),F=require("../extension/profiles.js");
test("pre2.8 processing records stay ignored while independent UI preferences remain",()=>{
  const old={schema:8,enabled:false,mode:"single",cutoff:.71,zoom:1.5,searchRange:6.25,language:"zh_TW",iconHidden:true,iconPosition:{x:.2,y:.3}},raw={[F.keys.legacy]:old,[F.keys.personal]:{format:1,profile:old,previous:{...old,cutoff:2}}},before=JSON.stringify(raw),d=F.decode(raw);
  assert.equal(JSON.stringify(raw),before);assert.ok(F.equal(d.personal,S.defaults));assert.equal(d.hasPersonal,false);assert.equal(d.preferences.language,"zh_TW");assert.equal(d.preferences.iconHidden,true);
});
test("only a complete current profile can become the one personal default",()=>{
  const profile=F.snapshot({...S.defaults,cutoff:.6,searchRange:40}),old={...profile,schema:8};
  for(const record of [{format:1,profile},{format:2,profile:old},{format:2,profile:{...profile,cutoff:NaN}},{format:2,profile:{zoom:2}}]){const d=F.decode({[F.keys.personal]:record});assert.ok(F.equal(d.personal,S.defaults));assert.equal(d.hasPersonal,false);}
  const d=F.decode({[F.keys.personal]:{format:2,profile,previous:old}});assert.ok(F.equal(d.personal,profile));assert.equal(d.hasPersonal,true);assert.deepEqual(Object.keys(F.record(profile)),["format","profile"]);
});
test("existing 2.8 personal values survive while an older backup never becomes active",()=>{
  const previous={...S.defaults,mode:"cross",centerRatio:50,sampleRatio:25,searchRange:25,compensationLimit:3,cutoff:1,damping:.9},personal={...previous,mode:"single",centerRatio:80,sampleRatio:40,searchRange:30,compensationLimit:13};
  const raw={[F.keys.personal]:{format:2,profile:F.snapshot(personal),previous:F.snapshot(previous)}},before=JSON.stringify(raw),decoded=F.decode(raw),session=new F.Session(decoded,"video");
  assert.ok(F.equal(session.settings(),personal));assert.equal(JSON.stringify(raw),before);assert.equal(decoded.previousPersonal,undefined);
  session.apply(S.defaults);assert.ok(F.equal(session.settings(),S.defaults));assert.ok(F.equal(session.personal,personal));session.newVideo("next");assert.ok(F.equal(session.settings(),personal));
  assert.deepEqual(F.record(session.settings()),{format:2,profile:F.snapshot(personal)});
});
test("processing snapshots and UI preference writes remain disjoint",()=>{
  const settings=S.normalize({...S.defaults,language:"fr",iconHidden:true,iconPosition:{x:.4,y:.6}}),snapshot=F.snapshot(settings),writes=F.preferenceWrites({...settings,zoom:2});
  for(const k of ["language","iconHidden","iconPosition"])assert.ok(!(k in snapshot));assert.deepEqual(Object.keys(writes).sort(),[F.keys.language,F.keys.iconHidden,F.keys.iconPosition].sort());assert.ok(F.equal(F.record(settings).profile,settings));
});
test("local apply keeps the saved profile and receives UI preferences without replacing current work",()=>{
  const p=new F.Session(F.decode({[F.keys.personal]:F.record({...S.defaults,centerRatio:72})}),"one");p.apply({...p.settings(),centerRatio:44});assert.equal(p.settings().centerRatio,44);assert.equal(p.personal.centerRatio,72);assert.equal(p.apply(p.settings()),false);
  p.receive(F.decode({[F.keys.personal]:F.record({...S.defaults,centerRatio:80}),[F.keys.language]:"fr",[F.keys.iconHidden]:true}));assert.equal(p.settings().centerRatio,44);assert.equal(p.personal.centerRatio,80);assert.equal(p.settings().language,"fr");assert.equal(p.settings().iconHidden,true);
});
test("absence of a saved profile is distinct from a deliberately saved system default",()=>{
  const empty=new F.Session(F.decode({}),"one"),saved=new F.Session(F.decode({[F.keys.personal]:F.record(S.defaults)}),"two");assert.equal(empty.hasPersonal,false);assert.equal(saved.hasPersonal,true);assert.ok(F.equal(empty.settings(),saved.settings()));
});
test("new videos and fresh sessions load the latest personal default without altering other sessions",()=>{
  const data=F.decode({[F.keys.personal]:F.record({...S.defaults,centerRatio:62})}),a=new F.Session(data,"one"),b=new F.Session(data,"two");a.apply({...a.settings(),centerRatio:44});assert.equal(b.settings().centerRatio,62);
  const changed=F.decode({[F.keys.personal]:F.record({...S.defaults,centerRatio:88})});a.receive(changed);b.receive(changed);assert.equal(a.settings().centerRatio,44);assert.equal(b.settings().centerRatio,62);
  assert.equal(a.newVideo("one"),false);assert.equal(a.newVideo("three"),true);assert.equal(a.settings().centerRatio,88);assert.equal(a.touched,false);assert.equal(new F.Session(changed,"one").settings().centerRatio,88);
});
