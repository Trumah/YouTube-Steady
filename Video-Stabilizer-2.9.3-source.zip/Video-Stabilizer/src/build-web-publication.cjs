"use strict";
// A flat web-upload kit avoids directory loss in browser file choosers.
// The complete corresponding source remains in its version-matched ZIP.
const fs=require('node:fs'),path=require('node:path'),config=require('../extension/support.js');
const root=path.resolve(__dirname,'..'),site=path.join(root,'work/public-site'),out=path.join(root,'work/github-web-'+config.version);
fs.mkdirSync(out,{recursive:true});
for(const name of ['index.html','style.css','script.js','icon.svg','public.js','LICENSE.txt','NOTICE.txt','.nojekyll']){
  const data=fs.readFileSync(path.join(site,name));
  fs.writeFileSync(path.join(out,name),['index.html','script.js'].includes(name)?data.toString('utf8').replaceAll('downloads/',''):data);
}
for(const name of [`Video-Stabilizer-${config.version}.zip`,`Video-Stabilizer-${config.version}-source.zip`,'SHA256SUMS.txt'])fs.copyFileSync(path.join(site,'downloads',name),path.join(out,name));
for(const name of ['FFTW-COPYRIGHT.txt','EMSCRIPTEN-LICENSE.txt'])fs.copyFileSync(path.join(root,name),path.join(out,name));
const intro=`Video Stabilizer public distribution\n\nThe complete corresponding source is in Video-Stabilizer-${config.version}-source.zip.\nExtract that archive for the extension source, build scripts, translations,\nnative reference tests and public validation reports. The GPL license and\nthird-party notices are included in both packages.\n\n`;
fs.writeFileSync(path.join(out,'README.txt'),intro+fs.readFileSync(path.join(root,'README.txt'),'utf8'));
console.log('Flat GitHub web-upload kit ready: '+out);
