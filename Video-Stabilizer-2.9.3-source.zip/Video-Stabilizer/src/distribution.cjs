"use strict";
// Public destinations only. Never store PayPal credentials or API keys here.
function supportUrl(value){
  if(value===""||value===undefined)return "";
  if(typeof value!=="string"||value!==value.trim())throw Error("Use a public HTTPS PayPal.Me profile link.");
  let url;try{url=new URL(value);}catch{throw Error("Invalid PayPal.Me link.");}
  if(url.protocol!=="https:"||!['paypal.me','www.paypal.me'].includes(url.hostname.toLowerCase())||url.username||url.password||url.port||url.search||url.hash||!/^\/[a-zA-Z0-9]{1,20}\/?$/.test(url.pathname))
    throw Error("Use only https://paypal.me/YourProfile, without an amount, query, or recurring-payment link.");
  return "https://paypal.me/"+url.pathname.split('/')[1];
}
function repository(value){
  if(value===""||value===undefined)return "";
  if(typeof value!=="string"||!/^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,37}[a-zA-Z0-9])?)\/[a-zA-Z0-9][a-zA-Z0-9._-]{0,99}$/.test(value)||value.split('/')[1].endsWith('.git'))
    throw Error("Repository must be an owner/name on github.com.");
  return value;
}
module.exports={supportUrl,repository};
