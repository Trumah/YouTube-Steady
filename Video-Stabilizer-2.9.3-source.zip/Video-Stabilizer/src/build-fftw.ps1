param(
    [Parameter(Mandatory=$true)][string]$SdkRoot,
    [Parameter(Mandatory=$true)][string]$FftwRoot,
    [Parameter(Mandatory=$true)][string]$FftwBuild,
    [string]$CMake = 'cmake',
    [string]$Ninja = 'ninja'
)
$ErrorActionPreference = 'Stop'
$steadySdk = (Resolve-Path -LiteralPath $SdkRoot).Path
$steadyFftw = (Resolve-Path -LiteralPath $FftwRoot).Path
$env:EM_CONFIG = Join-Path $steadySdk '.emscripten'
if (!$env:EMSDK_PYTHON) { $env:EMSDK_PYTHON = Join-Path $steadySdk 'python\3.13.3_64bit\python.exe' }
$env:EMCC_TEMP_DIR = Join-Path $FftwBuild 'em-temp'
New-Item -ItemType Directory -Path $env:EMCC_TEMP_DIR -Force | Out-Null
$steadyToolchain = Join-Path $steadySdk 'upstream\emscripten\cmake\Modules\Platform\Emscripten.cmake'
& $CMake --fresh -S $steadyFftw -B $FftwBuild -G Ninja `
    "-DCMAKE_MAKE_PROGRAM=$Ninja" "-DCMAKE_TOOLCHAIN_FILE=$steadyToolchain" `
    '-DCMAKE_BUILD_TYPE=Release' '-DCMAKE_C_FLAGS=-O3 -msimd128 -ffp-contract=off' `
    '-DENABLE_FLOAT=ON' '-DBUILD_SHARED_LIBS=OFF' '-DENABLE_THREADS=OFF' `
    '-DENABLE_OPENMP=OFF' '-DDISABLE_FORTRAN=ON' '-DBUILD_TESTS=OFF'
if ($LASTEXITCODE -ne 0) { throw "FFTW configure failed ($LASTEXITCODE)" }
& $CMake --build $FftwBuild --parallel 4
if ($LASTEXITCODE -ne 0) { throw "FFTW build failed ($LASTEXITCODE)" }
