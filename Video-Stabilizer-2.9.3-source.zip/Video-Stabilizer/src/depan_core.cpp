/* YouTube Steady 2: sequential, translation-only DePan core adapter.
 * Derived from DePan/DePanEstimate by A.G. Balakhnin (Fizick), 2004-2016,
 * and Ferenc Pinter's 8-16 bit/MT maintenance. GNU GPL, see LICENSE.txt.
 * Upstream commit: b41dca46d97916c9e86c7be2b7fc434349df0fd4.
 * Kept: FFTW single precision correlation, peak/trust/subpixel calculation,
 * method=0 nonlinear predictor/corrector, rolling base, and soft travel limits.
 * Removed: Avisynth/Windows interfaces, interlacing, rotation, zoom estimation,
 * future-frame border filling and file IO. No frames leave the browser.
 * Deliberate fixes: initialized trust; deterministic nonzero-dx sentinel;
 * preserve the sign of the final negative-limit safety clamp.
 */
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fftw3.h>

namespace {
struct Motion { int frame; float x, y; };
struct Result {
  float motionX, motionY, trust, mapX, mapY, valid;
  float frame, base, reason, change, deviation, reserved;
};
struct Axis { float c0=0, c1=0, c2=0, s0=0, s1=0, s2=0; };
int width=0, height=0, stride=0, count=0, estimateX=0, estimateY=0;
float trustLimit=4, stab=1, cutoff=1.25f, damping=1, limitX=128, limitY=128, fps=30;
fftwf_complex *current=nullptr, *previous=nullptr, *correlation=nullptr;
fftwf_plan forwardPlan=nullptr, inversePlan=nullptr;
uint8_t *input=nullptr,*previousPixels=nullptr;
int inputCapacity=0;
bool havePrevious=false;
float previousTrust=0;
int frameIndex=-1, baseFrame=0;
std::deque<Motion> history;
Result output{};
// Region estimation owns separate references; only ys_push_motion advances
// the global stabilizer. Skipped grid cells retain raw pixels for the next frame.
struct Region { uint8_t *pixels=nullptr; fftwf_complex *spectrum=nullptr;
  fftwf_plan forward=nullptr, inverse=nullptr;
  int width=0,height=0,stride=0,count=0,searchX=0,searchY=0;
  bool have=false, fftReady=false, temporalGuard=true; float trust=0; };
Region regions[9];
void releaseRegion(Region &r) {
  if(r.forward)fftwf_destroy_plan(r.forward);
  if(r.inverse)fftwf_destroy_plan(r.inverse);
  std::free(r.pixels);if(r.spectrum)fftwf_free(r.spectrum);r=Region{};
}

void reset() {
  havePrevious=false; previousTrust=0; frameIndex=-1; baseFrame=0;
  history.clear(); output={};
  for (auto &r:regions) { r.have=r.fftReady=false; r.trust=0; }
}
void release() {
  for (auto &r:regions) releaseRegion(r);
  if (forwardPlan) fftwf_destroy_plan(forwardPlan);
  if (inversePlan) fftwf_destroy_plan(inversePlan);
  if (current) fftwf_free(current);
  if (previous) fftwf_free(previous);
  if (correlation) fftwf_free(correlation);
  std::free(input);std::free(previousPixels);input=previousPixels=nullptr;inputCapacity=0;
  forwardPlan=inversePlan=nullptr; current=previous=correlation=nullptr;
}
float step(Axis &a, float motion, int relative, double frequency, double nonlin) {
  a.c2=a.c1; a.c1=a.c0; a.c0 += motion;
  a.s2=a.s1; a.s1=a.s0;
  if (relative<2) return a.s0=0;
  // Keep the upstream predictor/corrector in its well-conditioned region.
  // Tiny positive C makes 5/C stiff, even at normal cutoff and frame rates.
  // Solve the same restoring/damping forces implicitly in that region instead
  // of repeatedly overflowing and discarding the motion history. Double terms
  // avoid both the cancellation freq*(nonlin/freq) and large-damping overflow.
  const double d=12.56*double(damping)/fps*frequency;
  const double dn=6.28*double(damping)/fps*nonlin;
  const double k=39.44/(double(fps)*fps)*frequency*frequency;
  const double e=double(a.s1)-a.c1,v=double(a.s1)-a.s2-a.c1+a.c2;
  const auto stiff=[&](double error,double velocity) {
    return d+2*dn*std::fabs(velocity)+k*(1+2*nonlin*std::fabs(error))>1;
  };
  const auto implicit=[&]() {
    const double target=2*double(a.s1)-a.s2-a.c0;
    double lo=std::min({0.0,e,target}),hi=std::max({0.0,e,target});
    // F is strictly increasing for nonnegative damping/stiffness. Its root is
    // bracketed by the force centers; bisection cannot overshoot or diverge.
    for(int n=0;n<56;++n) {
      const double x=lo+(hi-lo)*.5,dv=x-e;
      const double f=x-target+d*dv+dn*dv*std::fabs(dv)+k*x*(1+nonlin*std::fabs(x));
      if(f>0)hi=x;else lo=x;
    }
    ++output.reserved;
    return a.s0=float(double(a.c0)+lo+(hi-lo)*.5);
  };
  if(cutoff<.2f||cutoff>5||damping<.25f||damping>3||nonlin>3.4028234663852886e38)return implicit();
  const float f=float(frequency),n=float(nonlin);
  const float cdamp=12.56f*damping/fps, cquad=39.44f/(fps*fps);
  const float first=2*a.s1-a.s2
    -cdamp*f*(a.s1-a.s2-a.c1+a.c2)
      *(1+0.5f*n/f*std::fabs(a.s1-a.s2-a.c1+a.c2))
    -cquad*f*f*(a.s1-a.c1)*(1+n*std::fabs(a.s1-a.c1));
  a.s0=2*a.s1-a.s2
    -cdamp*f*0.5f*(first-a.s2-a.c0+a.c2)
      *(1+0.5f*n/f*0.5f*std::fabs(first-a.s2-a.c0+a.c2))
    -cquad*f*f*(a.s1-a.c1)*(1+n*std::fabs(a.s1-a.c1));
  // The two upstream square-root passes already saturate at |error|>1.5^4*C.
  // Local stiffness alone is not sufficient to replace a healthy predictor:
  // fast alternating camera motion can have large slopes yet remain stable.
  const double next=double(a.s0)-a.c0,velocity=double(a.s0)-a.s1-a.c0+a.c1;
  if(!std::isfinite(a.s0)||(std::fabs(next)>25.3125/nonlin&&(stiff(e,v)||stiff(next,velocity))))return implicit();
  return a.s0;
}
float softLimit(float value, float bound) {
  if (bound==0) return 0;
  if (std::fabs(value)>bound) value=std::copysign(std::sqrt(std::fabs(value)*bound),value);
  if (std::fabs(value)>bound) value=std::copysign(std::sqrt(std::fabs(value)*bound),value);
  if (std::fabs(value)>bound*1.5f) value=std::copysign(bound,value);
  return value;
}
void stabilize(float dx, float dy, bool valid) {
  ++frameIndex;
  if (!valid) baseFrame=frameIndex;
  const float effectiveCutoff=std::min(cutoff,fps*.5f);
  const float framesBack=std::min(10*fps/effectiveCutoff,5*fps);
  baseFrame=std::max(baseFrame,std::max(0,int(float(frameIndex)-framesBack)));
  history.push_back({frameIndex,dx,dy});
  while (!history.empty()&&history.front().frame<baseFrame) history.pop_front();
  Axis x,y;
  const double z=1+6*double(damping)*damping;
  // Preserve float arithmetic for existing normal profiles/native comparisons.
  const double frequency=damping<=3?double(effectiveCutoff/std::sqrt(1+6*damping*damping+
    std::sqrt((1+6*damping*damping)*(1+6*damping*damping)+3))):effectiveCutoff/std::sqrt(z+std::hypot(z,std::sqrt(3.0)));
  const auto nonlinear=[](float bound){const float n=5.0f/std::fabs(bound);return std::isfinite(n)?double(n):5.0/std::fabs(double(bound));};
  for (const auto &m:history) if (m.frame>baseFrame) {
    if(limitX)step(x,m.x,m.frame-baseFrame,frequency,nonlinear(limitX));
    if(limitY)step(y,m.y,m.frame-baseFrame,frequency,nonlinear(limitY));
  }
  float mx=x.s0-x.c0,my=y.s0-y.c0;
  if (!std::isfinite(mx)||!std::isfinite(my)) {
    baseFrame=frameIndex;history.clear();history.push_back({frameIndex,0,0});
    mx=my=0;output.reason=4;
  }
  output.mapX=softLimit(mx,limitX);output.mapY=softLimit(my,limitY);
  output.frame=float(frameIndex);output.base=float(baseFrame);
}
void peak(int w=width,int h=height,int pad=stride,int ex=estimateX,int ey=estimateY,float priorTrust=previousTrust,bool temporalGuard=true) {
  const float *surface=reinterpret_cast<float*>(correlation);
  float maximum=surface[0],mean=0; int samples=0,imax=0,jmax=0;
  auto row=[&](int j) {
    for (int i=0;i<=ex;i++) {
      const float v=surface[j*pad+i];mean+=v;++samples;
      if (maximum<v) {maximum=v;imax=i;jmax=j;}
    }
    for (int i=w-ex;i<w;i++) {
      const float v=surface[j*pad+i];mean+=v;++samples;
      if (maximum<v) {maximum=v;imax=i;jmax=j;}
    }
  };
  for (int j=0;j<=ey;j++) row(j);
  for (int j=h-ey;j<h;j++) row(j);
  mean=mean/samples/(w*h); maximum/=w*h;
  float trust=(maximum-mean)*100.0f/(maximum+0.1f);
  int dx=imax*2<w?imax:imax-w,dy=jmax*2<h?jmax:jmax-h;
  trust*=(ex+1)/(ex+1+stab*std::abs(dx))
    *(ey+1)/(ey+1+stab*std::abs(dy));
  output.trust=trust;output.valid=trust>=trustLimit;
  if (!std::isfinite(trust)) output.valid=0;
  if (!output.valid) {output.motionX=output.motionY=0;output.reason=2;return;}
  const int xp=(imax+1)%w,xm=(imax+w-1)%w;
  const int yp=(jmax+1)%h,ym=(jmax+h-1)%h;
  const float center=surface[jmax*pad+imax];
  const float fx1=(surface[jmax*pad+xp]-surface[jmax*pad+xm])/2;
  const float fx2=surface[jmax*pad+xp]+surface[jmax*pad+xm]-center*2;
  const float fy1=(surface[yp*pad+imax]-surface[ym*pad+imax])/2;
  const float fy2=surface[yp*pad+imax]+surface[ym*pad+imax]-center*2;
  float xa=fx2==0?0:std::clamp(-fx1/fx2,-1.0f,1.0f);
  float ya=fy2==0?0:std::clamp(-fy1/fy2,-1.0f,1.0f);
  if (std::fabs(dx+xa)>ex) xa=0;
  if (std::fabs(dy+ya)>ey) ya=0;
  output.motionX=dx+xa;output.motionY=dy+ya;
  // Upstream uses randomly signed .011 as its "valid zero" marker. A separate
  // flag removes that ambiguity here; deterministic +.011 preserves semantics.
  if (std::fabs(output.motionX)<0.01f) output.motionX=0.011f;
  if (temporalGuard&&trust<trustLimit*2&&trust<0.5f*priorTrust) {
    output.valid=0;output.motionX=output.motionY=0;output.reason=3;
  }
}
}

extern "C" {
int ys_api_version() {return 6;}
uint8_t *ys_input_ptr() {return input;}
Result *ys_result_ptr() {return &output;}
int ys_input_capacity() {return inputCapacity;}
void ys_reset() {reset();}
int ys_configure(int w,int h,int ex,int ey,float trust,float penalty,
                 float frequency,float damp,float maxX,float maxY,float rate) {
  if (w<8||h<8||w>8192||h>8192||ex<0||ey<0||
      ex>(w-1)/2||ey>(h-1)/2||!std::isfinite(trust)||trust<0.1f||trust>100||
      !std::isfinite(penalty)||penalty<0||penalty>10||
      !std::isfinite(frequency)||frequency<0.0001f||frequency>120||
      !std::isfinite(damp)||damp<0||
      !std::isfinite(maxX)||maxX<0||maxX>65536||
      !std::isfinite(maxY)||maxY<0||maxY>65536||
      !std::isfinite(rate)||rate<5||rate>240) return -1;
  if (w!=width||h!=height||!forwardPlan||!inversePlan) {
    release();width=w;height=h;stride=(w/2+1)*2;count=h*(w/2+1);
    current=fftwf_alloc_complex(count);previous=fftwf_alloc_complex(count);
    correlation=fftwf_alloc_complex(count);
    inputCapacity=w*h;input=static_cast<uint8_t*>(std::malloc(inputCapacity));
    if (!current||!previous||!correlation||!input) {release();return -2;}
    forwardPlan=fftwf_plan_dft_r2c_2d(h,w,reinterpret_cast<float*>(current),current,FFTW_ESTIMATE);
    inversePlan=fftwf_plan_dft_c2r_2d(h,w,correlation,reinterpret_cast<float*>(correlation),FFTW_ESTIMATE);
    if (!forwardPlan||!inversePlan) {release();return -3;}
  }
  estimateX=ex;estimateY=ey;trustLimit=trust;stab=penalty;
  cutoff=frequency;damping=damp;limitX=maxX;limitY=maxY;fps=rate;
  reset();return 0;
}
int ys_set_fps(float rate) {
  if (!std::isfinite(rate)||rate<5||rate>240) return -1;
  fps=rate;return 0;
}
Result *ys_process() {
  output={};
  if (!forwardPlan||!inversePlan) {output.reason=-1;return &output;}
  if(!previousPixels)previousPixels=static_cast<uint8_t*>(std::malloc(inputCapacity));
  if(!previousPixels){output.reason=-3;return &output;}
  float *real=reinterpret_cast<float*>(current);
  double sum=0,sq=0,diff=0;int samples=0;
  for(int y=0;y<height;y++) for(int x=0;x<width;x++) {
    const int p=y*width+x;real[y*stride+x]=input[p];
    if (y%8==0&&x%8==0) {const float v=input[p];sum+=v;sq+=v*v;
      if(havePrevious)diff+=std::abs(int(input[p])-int(previousPixels[p]));++samples;}
    previousPixels[p]=input[p];
  }
  output.change=float(diff/std::max(1,samples));
  output.deviation=float(std::sqrt(std::max(0.0,sq/std::max(1,samples)-std::pow(sum/std::max(1,samples),2))));
  fftwf_execute_dft_r2c(forwardPlan,real,current);
  if (!havePrevious) {
    havePrevious=true;output.reason=1;stabilize(0,0,false);
  } else {
    for (int k=0;k<count;k++) {
      correlation[k][0]=current[k][0]*previous[k][0]+current[k][1]*previous[k][1];
      correlation[k][1]=current[k][0]*previous[k][1]-current[k][1]*previous[k][0];
    }
    fftwf_execute_dft_c2r(inversePlan,correlation,reinterpret_cast<float*>(correlation));
    peak();previousTrust=output.trust;
    stabilize(output.motionX,output.motionY,output.valid!=0);
  }
  std::swap(current,previous);return &output;
}
Result *ys_push_motion(float dx,float dy,int valid) {
  output={};output.motionX=dx;output.motionY=dy;output.valid=valid;
  stabilize(dx,dy,valid&&std::isfinite(dx)&&std::isfinite(dy));return &output;
}
int ys_region_configure(int slot,int w,int h,int ex,int ey,int temporalGuard) {
  if(slot<0||slot>=9||!forwardPlan||!inversePlan||w<8||h<8||w>width||h>height||
     ex<0||ey<0||ex>(w-1)/2||ey>(h-1)/2||(temporalGuard!=0&&temporalGuard!=1))return -1;
  auto &r=regions[slot];
  if(r.width!=w||r.height!=h||!r.forward||!r.inverse) {
    releaseRegion(r);r.width=w;r.height=h;r.stride=(w/2+1)*2;r.count=h*(w/2+1);
    r.pixels=static_cast<uint8_t*>(std::malloc(size_t(w)*h));r.spectrum=fftwf_alloc_complex(r.count);
    if(!r.pixels||!r.spectrum){releaseRegion(r);return -2;}
    r.forward=fftwf_plan_dft_r2c_2d(h,w,reinterpret_cast<float*>(current),current,FFTW_ESTIMATE);
    r.inverse=fftwf_plan_dft_c2r_2d(h,w,correlation,reinterpret_cast<float*>(correlation),FFTW_ESTIMATE);
    if(!r.forward||!r.inverse){releaseRegion(r);return -3;}
  }
  r.searchX=ex;r.searchY=ey;r.temporalGuard=temporalGuard!=0;return 0;
}
Result *ys_region(int slot,int selected) {
  output={};
  if(slot<0||slot>=9||(selected!=0&&selected!=1)||!forwardPlan||!inversePlan) {output.reason=-1;return &output;}
  auto &r=regions[slot];
  if(!r.forward&&ys_region_configure(slot,width,height,estimateX,estimateY,1)!=0){output.reason=-3;return &output;}
  double sum=0,sq=0,diff=0;int samples=0;
  for(int y=0;y<r.height;y+=4)for(int x=0;x<r.width;x+=4) {
    const int p=y*r.width+x;const float v=input[p];sum+=v;sq+=v*v;++samples;
    if(r.have)diff+=std::abs(int(input[p])-int(r.pixels[p]));
  }
  output.change=float(diff/std::max(1,samples));
  output.deviation=float(std::sqrt(std::max(0.0,sq/std::max(1,samples)-std::pow(sum/std::max(1,samples),2))));
  if(selected) {
    auto transform=[&](const uint8_t *pixels,fftwf_complex *target) {
      auto real=reinterpret_cast<float*>(target);
      for(int y=0;y<r.height;y++)for(int x=0;x<r.width;x++)real[y*r.stride+x]=pixels[y*r.width+x];
      fftwf_execute_dft_r2c(r.forward,real,target);
    };
    const fftwf_complex *reference=r.spectrum;
    if(r.have&&!r.fftReady) {transform(r.pixels,previous);reference=previous;}
    transform(input,current);
    if(r.have) {
      for(int k=0;k<r.count;k++) {
        correlation[k][0]=current[k][0]*reference[k][0]+current[k][1]*reference[k][1];
        correlation[k][1]=current[k][0]*reference[k][1]-current[k][1]*reference[k][0];
      }
      fftwf_execute_dft_c2r(r.inverse,correlation,reinterpret_cast<float*>(correlation));
      peak(r.width,r.height,r.stride,r.searchX,r.searchY,r.fftReady?r.trust:0,r.temporalGuard);r.trust=output.trust;
    } else output.reason=1;
    std::memcpy(r.spectrum,current,sizeof(fftwf_complex)*r.count);r.fftReady=true;
  } else {r.fftReady=false;r.trust=0;}
  std::memcpy(r.pixels,input,size_t(r.width)*r.height);r.have=true;
  return &output;
}
}
