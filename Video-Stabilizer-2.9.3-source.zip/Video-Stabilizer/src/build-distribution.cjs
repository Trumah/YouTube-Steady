"use strict";
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),D=require('./distribution.cjs');
const root=path.resolve(__dirname,'..'),file=path.join(__dirname,'distribution.json'),argv=process.argv.slice(2);
let config=JSON.parse(fs.readFileSync(file,'utf8'));
for(let i=0;i<argv.length;i++){
  if(argv[i]==='--check')continue;
  if(!['--support-url','--repository'].includes(argv[i])||!argv[i+1]||argv[i+1].startsWith('--'))throw Error('Expected --support-url URL or --repository owner/name.');
  config[argv[i]==='--support-url'?'supportUrl':'repository']=argv[++i];
}
config={repository:D.repository(config.repository),supportUrl:D.supportUrl(config.supportUrl)};
const version=JSON.parse(fs.readFileSync(path.join(root,'extension/manifest.json'),'utf8')).version;
assert.match(version,/^\d+\.\d+\.\d+$/);
const data={version,...config,provider:config.supportUrl?'PayPal':'',enabled:!!config.supportUrl};
const output='/* Generated public destinations; no payment credentials. GPL-2.0-or-later. */\n'+
  '(function(root){"use strict";const data=Object.freeze('+JSON.stringify(data)+');root.YTSteadySupport=data;if(typeof module!=="undefined"&&module.exports)module.exports=data;})(globalThis);\n';
const target=path.join(root,'extension/support.js');
if(argv.includes('--check'))assert.equal(fs.readFileSync(target,'utf8'),output,'Public destinations are stale; run npm run build:distribution.');
else{fs.writeFileSync(file,JSON.stringify(config,null,2)+'\n');fs.writeFileSync(target,output);}
console.log(`Public destinations ${argv.includes('--check')?'verified':'generated'}; one-time support ${data.enabled?'configured':'not configured (link hidden)'}.`);
