param(
    [string]$SdkRoot = '',
    [string]$FftwRoot = '',
    [string]$FftwBuild = ''
)
$ErrorActionPreference = 'Stop'
$steadyProject = Split-Path -Parent $PSScriptRoot
# Keep default SDK, source and temporary paths inside this standalone checkout.
$steadyWorkspace = $steadyProject
if (!$SdkRoot) { $SdkRoot = Join-Path $steadyWorkspace 'work\tools\emsdk' }
if (!$FftwRoot) { $FftwRoot = Join-Path $steadyWorkspace 'work\sources\fftw\fftw-3.3.10' }
if (!$FftwBuild) { $FftwBuild = Join-Path $steadyWorkspace 'work\build\fftw-wasm' }
$env:EM_CONFIG = Join-Path $SdkRoot '.emscripten'
if (!$env:EMSDK_PYTHON) { $env:EMSDK_PYTHON = Join-Path $SdkRoot 'python\3.13.3_64bit\python.exe' }
$env:EMCC_TEMP_DIR = Join-Path $steadyWorkspace 'work\build\em-temp'
New-Item -ItemType Directory -Path $env:EMCC_TEMP_DIR -Force | Out-Null
$steadyCompiler = Join-Path $SdkRoot 'upstream\emscripten\em++.exe'
$steadyLibrary = Join-Path $FftwBuild 'libfftw3f.a'
if (!(Test-Path -LiteralPath $steadyLibrary)) { throw "Build FFTW single precision first: $steadyLibrary" }
# Optimizers rewrite their output in place. Stage outside the loaded extension
# so a browser read or a failed build cannot expose a half-built JS/WASM pair.
$steadyStage = Join-Path $steadyWorkspace 'work\build\core-stage'
New-Item -ItemType Directory -Path $steadyStage -Force | Out-Null
$steadyExports = '["_ys_configure","_ys_input_ptr","_ys_input_capacity","_ys_result_ptr","_ys_reset","_ys_process","_ys_push_motion","_ys_set_fps","_ys_region","_ys_region_configure","_ys_api_version"]'
& $steadyCompiler (Join-Path $PSScriptRoot 'depan_core.cpp') $steadyLibrary "-I$FftwRoot/api" `
    -std=c++17 -O3 -msimd128 -ffp-contract=off -fno-exceptions -fno-rtti `
    '-sMODULARIZE=1' '-sEXPORT_NAME=YTDePanModule' '-sENVIRONMENT=web,worker,node' `
    '-sDYNAMIC_EXECUTION=0' '-sALLOW_MEMORY_GROWTH=1' '-sINITIAL_MEMORY=67108864' '-sMAXIMUM_MEMORY=2147483648' '-sABORTING_MALLOC=0' `
    '-sFILESYSTEM=0' '-sASSERTIONS=0' '-sMALLOC=emmalloc' '-sSTACK_SIZE=1048576' `
    '-sEXPORTED_RUNTIME_METHODS=["HEAPU8","HEAPF32"]' `
    "-sEXPORTED_FUNCTIONS=$steadyExports" `
    -o (Join-Path $steadyStage 'depan-core.js')
if ($LASTEXITCODE -ne 0) { throw "DePan WebAssembly build failed ($LASTEXITCODE)" }
Copy-Item -LiteralPath (Join-Path $steadyStage 'depan-core.js') -Destination (Join-Path $steadyProject 'extension\depan-core.js')
Copy-Item -LiteralPath (Join-Path $steadyStage 'depan-core.wasm') -Destination (Join-Path $steadyProject 'extension\depan-core.wasm')
Get-Item (Join-Path $steadyProject 'extension\depan-core.js'), (Join-Path $steadyProject 'extension\depan-core.wasm') | Select-Object Name, Length
@{sourceSha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'depan_core.cpp')).Hash.ToLowerInvariant();wasmSha256=(Get-FileHash -LiteralPath (Join-Path $steadyProject 'extension\depan-core.wasm')).Hash.ToLowerInvariant();jsSha256=(Get-FileHash -LiteralPath (Join-Path $steadyProject 'extension\depan-core.js')).Hash.ToLowerInvariant();fftwLibrarySha256=(Get-FileHash -LiteralPath $steadyLibrary).Hash.ToLowerInvariant();exports=($steadyExports | ConvertFrom-Json)} | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'core-build.json') -Encoding utf8NoBOM

& node (Join-Path $PSScriptRoot 'build-wasm-data.cjs')
if ($LASTEXITCODE) { throw 'Could not generate the packaged WASM data' }
