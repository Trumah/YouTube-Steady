"use strict";
// Source stays vector-based; Chrome's manifest requires raster icons.
// Rebuilding needs Sharp. Checking the shipped assets only needs Node.js.
const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto"),assert=require("node:assert/strict");
const root=path.resolve(__dirname,".."),source=path.join(__dirname,"brand/icon.svg"),record=path.join(__dirname,"brand/icons.json");
const sizes=[16,20,24,32,48,128],svg=fs.readFileSync(source),hash=data=>crypto.createHash("sha256").update(data).digest("hex");
const outputs=Object.fromEntries(sizes.map(size=>[size,`icons/icon${size}.png`]));
const uiFile=path.join(root,"extension/ui.js"),iconPattern=/const icon=.*; \/\/ Generated from src\/brand\/icon\.svg\./;
const playerIcon=svg.toString("utf8").replace(/<!--[\s\S]*?-->/g,"").replace(/>\s+</g,"><").trim().replace('width="128" height="128"','class="brand-icon" width="24" height="24" aria-hidden="true" focusable="false"');
const iconLine="const icon="+JSON.stringify(playerIcon)+"; // Generated from src/brand/icon.svg.";
function syncPlayer(){const source=fs.readFileSync(uiFile,"utf8");assert.ok(iconPattern.test(source),"Missing generated player icon marker.");fs.writeFileSync(uiFile,source.replace(iconPattern,()=>iconLine));}
function check(){
  const manifest=JSON.parse(fs.readFileSync(path.join(root,"extension/manifest.json"),"utf8")),saved=JSON.parse(fs.readFileSync(record,"utf8"));
  assert.equal(saved.sourceSha256,hash(svg),"SVG changed; run npm run build:icons.");
  assert.deepEqual(manifest.icons,outputs,"Manifest must declare every supplied size.");
  assert.deepEqual(manifest.action.default_icon,outputs,"Toolbar icons must use the same artwork.");
  for(const [size,name]of Object.entries(outputs)){
    const png=fs.readFileSync(path.join(root,"extension",name));
    assert.ok(png.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])),`Invalid PNG: ${name}`);
    assert.equal(png.readUInt32BE(16),Number(size));assert.equal(png.readUInt32BE(20),Number(size));
    assert.equal(saved.files[name],hash(png),`Icon changed; rebuild from the SVG: ${name}`);
  }
  assert.ok(fs.readFileSync(path.join(root,"site/icon.svg")).equals(svg),"Website icon must match the vector source.");
  assert.equal(fs.readFileSync(uiFile,"utf8").match(iconPattern)?.[0],iconLine,"Player icon must match the vector source. Run node src/build-icons.cjs --player.");
  console.log("Camera stabilization icons verified: "+sizes.join(", ")+" px.");
}
async function build(){
  let sharp;try{sharp=require("sharp");}catch{throw Error("Rebuilding icons needs Sharp. Install it locally or set NODE_PATH to an existing Sharp installation; see README-build.txt.");}
  fs.mkdirSync(path.join(root,"extension/icons"),{recursive:true});
  const files={};
  for(const [size,name]of Object.entries(outputs)){
    const png=await sharp(svg,{density:288}).resize(Number(size),Number(size)).png({compressionLevel:9}).toBuffer();
    fs.writeFileSync(path.join(root,"extension",name),png);files[name]=hash(png);
  }
  fs.copyFileSync(source,path.join(root,"site/icon.svg"));
  fs.writeFileSync(record,JSON.stringify({sourceSha256:hash(svg),renderer:"sharp "+sharp.versions.sharp,files},null,2)+"\n");
  syncPlayer();
  check();
}
if(process.argv.includes("--check"))check();else if(process.argv.includes("--player")){syncPlayer();check();}else build().catch(error=>{console.error(error.message);process.exitCode=1;});
