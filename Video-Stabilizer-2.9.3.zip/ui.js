/* Accessible, direction-aware player UI. Playback and motion state are owned
 * by controller.js; changing language only updates this view. GPL-2.0-or-later. */
(function(root){
  "use strict";
  const I=root.YTSteadyI18n,S=root.YTSteadySettings,F=root.YTSteadyProfiles;
  const colorFor=root.YTSteadyOverlayGeometry?.parameterColor||(()=>"#c8dfff");
  const fieldNames=["centerRatio","sampleRatio","searchRange","compensationLimit","zoom","cutoff","damping","trust","stab","subpixel"];
  const helpFor={centerRatio:"ratioHint",sampleRatio:"sampleHint",searchRange:"searchHint",compensationLimit:"limitHint",zoom:"zoomHint",cutoff:"cutoffHint",damping:"dampingHint",trust:"trustHint"};
  const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
  // Slider position is logarithmic; stored settings and precise input stay Hz.
  const logPosition=(value,min,max)=>clamp(Math.log(value/min)/Math.log(max/min),0,1);
  const periodValue=hz=>{const seconds=1/hz;return seconds<.1?"<"+I.number(.1,1):I.number(seconds,seconds<1?1:0);};
  const logValue=(position,min,max)=>min*Math.pow(max/min,clamp(position,0,1));
  function iconPlacement(width,height,toolbarTop,position){
    const left=12,top=12,right=Math.max(left,width-46),bottom=Math.max(top,Math.min(height-46,toolbarTop-42));
    return {x:position?left+(right-left)*clamp(position.x,0,1):right,y:position?top+(bottom-top)*clamp(position.y,0,1):bottom,left,top,right,bottom};
  }
  class PlayerUI{
    constructor(player,actions){
      this.player=player;this.actions=actions;this.errors=new Map();this.effectiveSignature="";this.host=document.createElement("div");this.host.id="yt-steady-controls";
      this.host.style.cssText="position:absolute;inset:0;z-index:65;pointer-events:none;";
      this.shadow=this.host.attachShadow({mode:"open"});
      const icon="<svg xmlns=\"http://www.w3.org/2000/svg\" class=\"brand-icon\" width=\"24\" height=\"24\" aria-hidden=\"true\" focusable=\"false\" viewBox=\"0 0 128 128\"><rect x=\"2\" y=\"2\" width=\"124\" height=\"124\" rx=\"29\" fill=\"#43edbb\"/><g stroke=\"#102f3b\" stroke-width=\"8\" stroke-linecap=\"round\" fill=\"none\"><path d=\"M22 40c-12 13-12 35 0 48\"/><path d=\"M106 40c12 13 12 35 0 48\"/></g><path d=\"M45 45l7-12h24l7 12h6a9 9 0 0 1 9 9v31a9 9 0 0 1-9 9H39a9 9 0 0 1-9-9V54a9 9 0 0 1 9-9z\" fill=\"#102f3b\"/><circle cx=\"64\" cy=\"68\" r=\"18\" fill=\"#f8fffc\"/><path d=\"M59 57l16 11-16 11z\" fill=\"#102f3b\"/></svg>"; // Generated from src/brand/icon.svg.
      const input=id=>`<div class="parameter" data-field="${id}" style="--field-color:${colorFor(id)}"><label class="row" for="${id}"><span class="label" id="${id}Label"><span data-i18n="${id}"></span>${["centerRatio","sampleRatio","searchRange","compensationLimit"].includes(id)?" <small>%</small>":""}${id==="cutoff"?'<small class="key" id="cutoffPeriod"></small>':""}</span><input id="${id}" type="text" inputmode="${S.fields[id].step<1?"decimal":"numeric"}" role="spinbutton" aria-valuemin="${S.fields[id].min}" aria-valuemax="${S.fields[id].max}" ${helpFor[id]?`aria-describedby="${helpFor[id]}"`:""} dir="ltr" required autocomplete="off" spellcheck="false"></label><input id="${id}Slider" class="slider" type="range" min="${S.fields[id].min}" max="${S.fields[id].max}" step="${S.fields[id].step}" aria-labelledby="${id}Label" ${helpFor[id]?`aria-describedby="${helpFor[id]}"`:""} dir="ltr">${id==="cutoff"?'<div class="cutoff-scale"><span id="strengthHeavy" data-i18n="strengthHeavy"></span><span id="strengthMedium" data-i18n="strengthMedium"></span><span id="strengthLight" data-i18n="strengthLight"></span></div>':""}</div>`;
      this.shadow.innerHTML=`<style>
        :host{font:14px/1.5 system-ui,-apple-system,'Segoe UI','Noto Sans','Microsoft JhengHei',sans-serif;color:#edf3ff;color-scheme:dark;text-align:start}*{box-sizing:border-box}#support{font-size:12px;margin-block-start:4px}#support a{color:#b6d9ff;text-underline-offset:3px}#support a:focus-visible{outline:2px solid #a7d1ff;outline-offset:3px}
        button,input,select{font:inherit}button{cursor:pointer;border:1px solid #7489a4;border-radius:6px;background:#27364b;color:#fff;padding:7px 10px;line-height:1.35}button:hover{background:#3b5273}
        button:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:2px solid #a7d1ff;outline-offset:2px}
        [hidden]{display:none!important}.brand-icon{display:block;flex:0 0 auto;inline-size:24px;block-size:24px}#entry{position:absolute;z-index:1;touch-action:none;cursor:grab;pointer-events:auto;display:flex;align-items:center;justify-content:center;inline-size:34px;block-size:34px;margin-inline-start:auto;background:#17253bed;padding:6px}#entry .brand-icon{inline-size:20px;block-size:20px}#entry[aria-pressed=false] .brand-icon{filter:grayscale(1);opacity:.65}
        #entry[aria-pressed=true]{border-color:#9bc6ff}#entry:active{cursor:grabbing}.icon-options{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-block-start:12px}.icon-options button{font-size:12px;padding:4px 7px}#panel{position:absolute;z-index:2;pointer-events:auto;overflow:auto;overscroll-behavior:contain;scroll-padding-block:64px;background:#111d2df5;border:1px solid #6f87a7;border-radius:10px;inline-size:384px;padding:14px;box-shadow:0 8px 28px #0009;margin-block-end:8px}
        .head,.row,.footer{display:flex;align-items:center;justify-content:space-between;gap:10px}.head{position:sticky;inset-block-start:-14px;z-index:2;background:#111d2d;padding-block:3px 9px;margin-block-end:8px;font-weight:650}.brand{display:flex;align-items:center;gap:8px;min-inline-size:0}.head small{display:block;font-size:11px;color:#adbed5;font-weight:400}.head button{border:0;background:transparent;font-size:23px;padding:0 5px;align-self:flex-start}
        .row{margin-block:8px}.label{flex:1;min-inline-size:0;font-size:13px;overflow-wrap:anywhere}.key{display:block;font:11px/1.4 ui-monospace,Consolas,monospace;color:#acbfd8}input[role=spinbutton],select{min-inline-size:0;inline-size:96px;border:1px solid #7489a4;border-radius:5px;background:#233349;color:#fff;padding:6px;scroll-margin-block:64px}input[role=spinbutton]{flex:0 0 96px;text-align:end;font-variant-numeric:tabular-nums}
        input[aria-invalid=true]{border-color:#ffb29f}input[type=checkbox]{inline-size:18px;block-size:18px;accent-color:#9bc6ff;vertical-align:middle;margin-inline:0 7px}.language{display:block}.language>span{display:block;margin-block-end:5px}.language select{inline-size:100%}
        .parameter{--field-color:#c8dfff;margin-block:6px;border-inline-start:3px solid var(--field-color);padding-inline-start:8px;border-radius:3px}.parameter .row{margin:0}.parameter .label{color:var(--field-color)}.parameter input[role=spinbutton]{border-color:var(--field-color)}.parameter:focus-within{background:#263c5866}.parameter input[aria-invalid=true]{border-color:#ffb29f}.slider{display:block;inline-size:100%;min-inline-size:0;height:18px;margin:3px 0 0;padding:0;accent-color:var(--field-color);background:transparent;cursor:pointer;direction:ltr}.parameter input:focus-visible{outline-color:var(--field-color)}
        .hint{font-size:12px;color:#b9c8dd;margin-block:5px 12px;overflow-wrap:anywhere}.compact-hint{margin-block:2px 8px}.footer{position:sticky;inset-block-end:-14px;z-index:1;background:#111d2d;padding-block:8px 3px;margin-block-start:8px;border-block-start:1px solid #3d506a;align-items:stretch}.footer button{flex:1;min-inline-size:0;font-size:13px;white-space:normal;overflow-wrap:anywhere}#apply{background:#285e9c}
        details{border-block-start:1px solid #3d506a;margin-block-start:8px;padding-block-start:6px}summary{cursor:pointer;font-size:13px;color:#d1e2fc;overflow-wrap:anywhere}#effective,#status,#perf{font-size:12px;color:#c8dfff;overflow-wrap:anywhere}#effective{margin-block-start:9px}#status{margin-block-start:8px;min-block-size:18px}#perf{white-space:pre-line;margin-block-start:8px;font-variant-numeric:tabular-nums}#subpixel{max-inline-size:48%;inline-size:150px}
        .main-actions,.storage-state{display:flex;flex-wrap:wrap;align-items:center;gap:8px}.main-actions{margin-block:6px}.enable-control{white-space:nowrap}.preset-actions{display:flex;flex:1 1 230px;min-inline-size:0;gap:8px}.main-actions button{flex:1;min-inline-size:0}.main-actions button,.storage-state button{font-size:12px;padding:5px 7px;max-inline-size:100%;overflow-wrap:anywhere}.storage-state .hint{flex:1;margin-block:4px}.cutoff-scale{display:flex;justify-content:space-between;position:relative;font-size:12px;color:#b9c8dd;direction:ltr;margin:2px 8px 6px;padding-bottom:20px}#strengthMedium{position:absolute;top:20px;left:var(--cutoff-default-position);transform:translateX(-50%)}#strengthMedium::before{content:"";position:absolute;left:50%;top:-25px;height:4px;border-left:1px solid currentColor}button:disabled{opacity:.5;cursor:default}#defaultStatus:empty{display:none}
      </style><section id="panel" role="dialog" aria-labelledby="panelTitle" hidden><form id="form" novalidate>
        <div class="head"><span class="brand">${icon}<span><span id="panelTitle" data-i18n="panelTitle"></span><small><bdi dir="ltr">Video Stabilizer · 2.9.3</bdi></small></span></span><button type="button" id="close" data-i18n-aria="close">×</button></div>
        <div class="main-actions"><label class="enable-control"><input id="enabled" type="checkbox"><span data-i18n="enabled"></span></label><div class="preset-actions"><button type="button" id="showRegions" data-i18n="showRegions"></button><button type="button" id="useMyDefault" data-i18n="useMyDefault"></button></div></div>
        <div class="storage-state"><p id="defaultStatus" class="hint" role="status" aria-live="polite"></p><button type="button" id="retryStorage" data-i18n="retryStorage" hidden></button></div>
        ${input("compensationLimit")}<p id="limitHint" class="hint" data-i18n="sharedLimitHint" hidden></p>
        ${input("cutoff")}<p id="cutoffHint" class="hint" data-i18n="cutoffHint" hidden></p>
        <details id="advanced"><summary data-i18n="advanced"></summary>
          ${input("damping")}<p id="dampingHint" class="hint" hidden></p>
          <label class="language" id="modeRow" style="color:${colorFor("mode")}"><span data-i18n="analysisMode"></span><select id="mode" style="border-color:${colorFor("mode")}"><option value="single" data-i18n="modeLegacy"></option><option value="cross" data-i18n="modeCross"></option><option value="x" data-i18n="modeX"></option><option value="adaptive" data-i18n="modeAdaptive"></option></select></label>
          ${input("centerRatio")}<p id="ratioHint" class="hint compact-hint" hidden></p>
          ${input("sampleRatio")}<p id="sampleHint" class="hint compact-hint" hidden></p><p id="workHint" class="hint compact-hint" role="status"></p>
          <label id="priorityRow" style="color:${colorFor("centerPriority")}"><input id="centerPriority" type="checkbox" style="accent-color:${colorFor("centerPriority")}"><span data-i18n="centerPriority"></span></label>
          ${input("searchRange")}<p id="searchHint" class="hint" hidden></p>
          ${input("trust")}<p id="trustHint" class="hint" data-i18n="trustHint" hidden></p>${input("stab")}
          <label class="row"><span class="label" data-i18n="subpixel"></span><select id="subpixel"><option value="1" data-i18n="bilinear"></option><option value="0" data-i18n="nearest"></option></select></label>
          ${input("zoom")}<p id="zoomHint" class="hint" hidden></p>
          <div class="icon-options"><label><input id="showIcon" type="checkbox" aria-describedby="iconHint"><span data-i18n="showIcon"></span></label><button id="resetIcon" type="button" data-i18n="resetIcon"></button></div><p id="iconHint" class="hint" data-i18n="iconHint" hidden></p>
          <label class="language"><span data-i18n="language"></span><select id="language" aria-describedby="languageHint"></select></label><p id="languageHint" class="hint" hidden></p>
        </details>
        <div id="status" role="status" aria-live="polite"></div><button type="button" id="retryProcessing" data-i18n="retryProcessing" hidden></button><details id="performance"><summary data-i18n="performance"></summary><div id="perf" aria-live="off"></div><div id="effective"></div><p class="hint" data-i18n="scopeHint"></p></details>
        <div id="support" hidden><a id="supportLink" target="_blank" rel="noopener noreferrer" data-i18n="supportOneTime" aria-describedby="supportHint"></a><p id="supportHint" class="hint" data-i18n="supportHint" hidden></p></div>
        <div class="footer"><button type="button" id="defaults" data-i18n="generalDefaults"></button><button type="button" id="saveMyDefault" data-i18n="saveMyDefault"></button><button type="submit" id="apply" data-i18n="applyCurrent" disabled></button></div>
      </form></section><button id="entry" data-i18n-aria="openSettings" aria-haspopup="dialog" aria-controls="panel" aria-expanded="false" aria-pressed="true">${icon}</button>`;
      this.elements=Object.fromEntries([...this.shadow.querySelectorAll("[id]")].map(el=>[el.id,el]));const e=this.elements;
      const support=root.YTSteadySupport;if(support?.enabled&&support.supportUrl){e.supportLink.href=support.supportUrl;e.support.hidden=false;}
      e.entry.addEventListener("click",event=>{if(this.suppressClick&&event.detail){this.suppressClick=false;event.preventDefault();return;}this.suppressClick=false;this.togglePanel();});e.close.addEventListener("click",()=>this.togglePanel(false));
      e.showIcon.addEventListener("change",()=>actions.save({iconHidden:!e.showIcon.checked}));
      e.resetIcon.addEventListener("click",()=>actions.save({iconPosition:null}));
      e.entry.addEventListener("pointerdown",event=>{
        if(event.button!==0||!event.isPrimary)return;
        this.suppressClick=false;this.layout();this.drag={id:event.pointerId,startX:event.clientX,startY:event.clientY,x:this.icon.x,y:this.icon.y,moved:false};
        try{e.entry.setPointerCapture(event.pointerId);}catch{}e.entry.focus({preventScroll:true});
      });
      e.entry.addEventListener("pointermove",event=>{
        const d=this.drag;if(!d||d.id!==event.pointerId)return;
        if(!d.moved&&Math.hypot(event.clientX-d.startX,event.clientY-d.startY)<4)return;
        d.moved=true;event.preventDefault();const b=this.player.getBoundingClientRect(),x=d.x+(event.clientX-d.startX)*this.player.clientWidth/b.width,y=d.y+(event.clientY-d.startY)*this.player.clientHeight/b.height;
        d.position={x:clamp((x-this.icon.left)/Math.max(1,this.icon.right-this.icon.left),0,1),y:clamp((y-this.icon.top)/Math.max(1,this.icon.bottom-this.icon.top),0,1)};this.layout();
      });
      e.entry.addEventListener("pointerup",event=>{
        const d=this.drag;if(!d||d.id!==event.pointerId)return;this.drag=null;this.suppressClick=d.moved;
        if(d.moved)actions.save({iconPosition:d.position});try{e.entry.releasePointerCapture(event.pointerId);}catch{}this.layout();
      });
      const cancelDrag=()=>{const d=this.drag;this.drag=null;this.suppressClick=true;if(d)try{e.entry.releasePointerCapture(d.id);}catch{}this.layout();};
      e.entry.addEventListener("pointercancel",cancelDrag);e.entry.addEventListener("lostpointercapture",()=>{if(this.drag)cancelDrag();});
      e.entry.addEventListener("keydown",event=>{
        if(event.key==="Escape"&&this.drag){event.preventDefault();cancelDrag();return;}
        const direction={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[event.key];
        if(!direction&&event.key!=="Home")return;if(event.ctrlKey||event.altKey||event.metaKey)return;event.preventDefault();
        if(event.key==="Home"){actions.save({iconPosition:null});return;}
        const p=this.actions.settings().iconPosition||{x:1,y:1},step=event.shiftKey?.1:.01;
        actions.save({iconPosition:{x:clamp(p.x+direction[0]*step,0,1),y:clamp(p.y+direction[1]*step,0,1)}});
      });
      e.enabled.addEventListener("change",()=>{
        // Enable is immediate; keep any other unfinished form values intact.
        const values=Object.fromEntries([...fieldNames,"mode"].map(name=>[name,e[name].value])),priority=e.centerPriority.checked;
        actions.save({enabled:e.enabled.checked});
        for(const [name,value]of Object.entries(values)){e[name].value=value;if(fieldNames.includes(name)){this.showValidation(name,{});this.updateNumericARIA(name);}}
        e.centerPriority.checked=priority;this.updateControls();this.draftChanged("enabled");
      });
      e.language.addEventListener("change",()=>actions.save({language:e.language.value}));
      e.useMyDefault.addEventListener("click",()=>actions.useDefault());e.saveMyDefault.addEventListener("click",()=>this.commit(true));e.retryStorage.addEventListener("click",()=>actions.retryStorage());
      e.retryProcessing.addEventListener("click",()=>actions.retryProcessing());
      for(const name of ["mode","centerPriority"])e[name].addEventListener("change",()=>{this.updateControls();this.draftChanged(name);});
      e.showRegions.addEventListener("click",()=>actions.preview?.(this.readValues(false),"all"));
      e.defaults.addEventListener("click",()=>this.stageProfile(S.defaults));
      e.form.addEventListener("submit",event=>{event.preventDefault();this.commit(false);});
      for(const name of fieldNames){
        const field=e[name];field.addEventListener("input",()=>this.draftChanged(name));
        if(name!=="subpixel"){
          const slider=e[name+"Slider"];
          for(const control of [field,slider])for(const event of ["focus","pointerdown"])control.addEventListener(event,()=>actions.preview?.(this.readValues(false),name));
          slider.addEventListener("input",()=>{
            const spec=S.sliderSpec(name),step=spec.nudge||spec.step,position=Number(slider.value),raw=name==="cutoff"?logValue(position,spec.min,spec.max):Math.round(position/step)*step,value=clamp(Math.round(raw*10000)/10000,spec.min,spec.max);
            const current=I.validate(field.value,spec);
            if(!current.error&&current.value===value)this.updateNumericARIA(name);
            else{field.value=I.input(value);this.draftChanged(name);}
            // Keep continuous gesture travel when four-decimal Hz precision
            // merges nearby positions at the low end. Apply repositions from Hz.
            if(name==="cutoff")slider.value=String(position);
          });
          slider.addEventListener("keydown",event=>{
            if(event.ctrlKey||event.altKey||event.metaKey)return;
            const direction={ArrowRight:1,ArrowUp:1,ArrowLeft:-1,ArrowDown:-1,PageUp:10,PageDown:-10}[event.key];
            if(direction===undefined&&!['Home','End'].includes(event.key))return;
            event.preventDefault();const spec=S.sliderSpec(name),log=name==="cutoff",step=log?.01:spec.nudge||spec.step,current=Number(slider.value),min=log?0:spec.min,max=log?1:spec.max;
            const position=event.key==="Home"?min:event.key==="End"?max:clamp(current+direction*step*(event.shiftKey?10:1),min,max),value=log?logValue(position,spec.min,spec.max):position;
            field.value=I.input(Math.round(value*10000)/10000);this.draftChanged(name);
            if(log)slider.value=String(position);
          });
        }
        if(name!=="subpixel")field.addEventListener("keydown",event=>{
          if(field.readOnly)return;
          if(!["ArrowUp","ArrowDown"].includes(event.key)||event.ctrlKey||event.altKey||event.metaKey)return;
          event.preventDefault();const spec=S.fields[name],step=spec.nudge||spec.step,parsed=I.parseNumber(field.value),current=parsed.value??spec.value;
          const next=current+(event.key==="ArrowUp"?1:-1)*step*(event.shiftKey?10:1);
          field.value=I.input(Math.max(spec.min,Math.min(spec.max,Math.round(next*10000)/10000)));this.draftChanged(name);
        });
      }
      for(const name of ["keydown","keyup","keypress"])this.shadow.addEventListener(name,event=>{
        event.stopPropagation();if(event.key==="Escape"&&!e.panel.hidden){this.togglePanel(false);event.preventDefault();}
      });
      for(const name of ["click","dblclick","pointerdown","wheel"])this.host.addEventListener(name,event=>event.stopPropagation());
      player.append(this.host);this.refreshFields(actions.settings());this.translate();this.layout();
    }
    commit(personal){
      if(personal){const values=this.readValues(false);if(values&&F.equal(values,this.actions.settings()))this.actions.saveDefault();return;}
      const values=this.readValues();if(!values){const group=this.shadow.querySelector('[aria-invalid="true"]')?.closest("details");if(group)group.open=true;this.elements.form.reportValidity();return;}
      if(!F.equal(values,this.actions.settings()))this.actions.save(values,true,this.lastField||"all");
    }
    stageProfile(profile){
      this.refreshFields({...this.actions.settings(),...F.snapshot(profile)},true);this.draftChanged("all");
    }
    draftChanged(name){
      this.lastField=name;if(fieldNames.includes(name)){this.showValidation(name,{});this.updateNumericARIA(name);}
      if(name==="centerRatio")this.updateRatioHint();this.updateWork();this.actions.draft(this.readValues(false),name);
    }
    updateControls(){
      const e=this.elements;e.centerPriority.disabled=e.mode.value==="single";e.priorityRow.title=I.t("centerPriorityHint");
      e.mode.title=I.t("regionsHint");this.updateRatioHint();this.layout();this.updateProfileControls();
    }
    setHint(name,text,visible=false){
      const e=this.elements;e[name].title=text;if(e[name+"Label"])e[name+"Label"].title=text;
      const hint=e[helpFor[name]];if(hint){hint.textContent=text;hint.hidden=!visible;}
    }
    updateRatioHint(){
      const e=this.elements,size=this.actions.dimensions?.(),ratio=I.parseNumber(e.centerRatio.value).value;
      if(size?.width>=32&&size?.height>=32&&ratio>=0&&ratio<=100){const c=S.grid(size.width,size.height,ratio)[4];this.setHint("centerRatio",I.t("ratioHint",{ratio:I.input(ratio),width:I.number(c.width),height:I.number(c.height)}));}
      else this.setHint("centerRatio",I.t("ratioWaiting"));
    }
    updateWork(){
      const e=this.elements,size=this.actions.dimensions?.(),profile=this.readValues(false);
      this.setHint("searchRange",I.t("sharedSearchHint"));this.setHint("cutoff",I.t("cutoffHint"));this.setHint("compensationLimit",I.t("sharedLimitHint"));
      this.setHint("sampleRatio",I.t("sampleHint",{recommended:I.input(S.defaults.sampleRatio)}));
      if(!size?.width||!size?.height||!profile){e.workHint.textContent=I.t(size?.width&&size?.height?"workUnavailable":"workWaiting");return;}
      e.workHint.title=I.t("workBasis");
      try{const p=S.plan(profile,size.width,size.height),w=p.work,load=w.relativeMin===w.relativeMax?I.number(w.relativeMax,1):I.number(w.relativeMin,1)+"–"+I.number(w.relativeMax,1);
        e.workHint.textContent=I.t("workEstimate",{load,memory:I.number(w.workingBytes/1048576,1)})+(w.supported?"":" "+I.t("workUnsupported"));
        if(p.searchLimited)this.setHint("searchRange",I.t("searchLimited",{requested:I.number(p.requestedSearch,2),effective:I.number(p.effectiveSearchMin,2)+"–"+I.number(p.effectiveSearchMax,2)}),true);
        if(p.compensationLimited)this.setHint("compensationLimit",I.t("compensationLimited",{requested:I.number(profile.compensationLimit,4),effective:I.number(p.effectiveCompensation,4)}),true);
        const frequency=Math.min(profile.cutoff,(size.fps||30)/2);if(frequency<profile.cutoff)this.setHint("cutoff",I.t("cutoffLimited",{requested:I.number(profile.cutoff,4),effective:I.number(frequency,4)}),true);
        if(p.samplingRaised)this.setHint("sampleRatio",I.t("samplingMinimum",{samples:S.limits.minSamples}),true);
      }catch{e.workHint.textContent=I.t("workUnavailable");}
    }
    readValues(validate=true){
      const e=this.elements,current=this.actions.settings(),values={...this.draftValues,...S.iconPreferences(current),mode:e.mode.value,centerPriority:e.centerPriority.checked,language:current.language,enabled:e.enabled.checked};let valid=true;
      for(const name of fieldNames){const result=I.validate(e[name].value,S.fields[name]);if(validate)this.showValidation(name,result);if(result.error)valid=false;else values[name]=result.value;}
      if(validate&&valid){const size=this.actions.dimensions?.();if(size?.width&&size?.height)try{const p=S.plan(values,size.width,size.height);if(!p.work.supported){this.showValidation("sampleRatio",{error:"errorSamplingCapacity"});valid=false;}}catch{this.showValidation("centerRatio",{error:"errorRegionSize"});valid=false;}}
      return valid?values:null;
    }
    updateSpecs(){
      const range=S.sliderSpec("cutoff");this.elements.strengthMedium.style.setProperty("--cutoff-default-position",100*logPosition(S.defaults.cutoff,range.min,range.max)+"%");this.elements.strengthMedium.title=I.input(S.defaults.cutoff)+" Hz";
      for(const name of fieldNames){const spec=S.fields[name],e=this.elements[name];e.setAttribute("aria-valuemin",spec.min);e.setAttribute("aria-valuemax",spec.max);if(name!=="subpixel"){e.inputMode=spec.step<1?"decimal":"numeric";const slider=this.elements[name+"Slider"],range=S.sliderSpec(name),log=name==="cutoff";slider.min=String(log?0:range.min);slider.max=String(log?1:range.max);slider.step=log?"any":String(range.step);slider.title=I.t("sliderRangeHint",{min:I.input(range.min),max:I.input(range.max)});}}
    }
    updateNumericARIA(name){
      const field=this.elements[name];if(name==="subpixel")return;
      const parsed=I.parseNumber(field.value);if(parsed.error){field.removeAttribute("aria-valuenow");field.removeAttribute("aria-valuetext");}
      else{field.setAttribute("aria-valuenow",String(parsed.value));field.setAttribute("aria-valuetext",I.input(parsed.value));}
      // Keep precise typed values; the slider only snaps to a convenient step
      // when the user moves it. Invalid text leaves its last valid position.
      const valid=I.validate(field.value,S.fields[name]),slider=this.elements[name+"Slider"];
      if(name==="cutoff"){
        const period=this.elements.cutoffPeriod;period.textContent=I.t("cutoffPeriod",{seconds:valid.error?"—":periodValue(valid.value)});period.title=I.t("cutoffPeriodHint");
        if(!valid.error){const range=S.sliderSpec(name),hz=clamp(valid.value,range.min,range.max);slider.value=String(logPosition(hz,range.min,range.max));slider.setAttribute("aria-valuetext",I.input(hz)+" Hz · "+I.t("cutoffPeriod",{seconds:periodValue(hz)}));}
      }else if(!valid.error){slider.value=String(valid.value);slider.setAttribute("aria-valuetext",I.input(Number(slider.value))+(["centerRatio","sampleRatio","searchRange","compensationLimit"].includes(name)?"%":""));}
    }
    showValidation(name,result){
      const field=this.elements[name];field.setCustomValidity(result.error?I.t(result.error,Object.fromEntries(Object.entries(result.args||{}).map(([k,v])=>[k,I.input(v)]))):"");
      if(result.error){field.setAttribute("aria-invalid","true");this.errors.set(name,result);}
      else{field.removeAttribute("aria-invalid");this.errors.delete(name);}
    }
    refreshFields(settings,preserveEffective=false){
      const e=this.elements;e.enabled.checked=settings.enabled;this.draftValues={...settings};e.mode.value=settings.mode;e.centerPriority.checked=settings.centerPriority;
      if(!preserveEffective){this.lastRegions=null;this.effectiveSignature="";e.effective.textContent="";}this.updateSpecs();
      for(const name of fieldNames){e[name].value=name==="subpixel"?String(settings[name]):I.input(settings[name]);this.showValidation(name,{});this.updateNumericARIA(name);}
      I.languageOptions(e.language);this.updateControls();
    }
    translate(){
      this.host.lang=I.tag;this.host.dir=I.dir;this.host.style.direction=I.dir;
      I.translateDOM(this.shadow);I.languageOptions(this.elements.language);
      this.updateSpecs();
      this.setHint("zoom",I.t("zoomHint",{zoom:I.input(S.defaults.zoom),full:I.number(1,2)}));
      this.setHint("damping",I.t("dampingHint",{damping:I.number(S.defaults.damping,1)}));this.setHint("trust",I.t("trustHint"));
      this.elements.languageHint.textContent=I.choice==="auto"?I.t("automaticHint",{language:I.languageName}):I.languageName;this.elements.language.title=this.elements.languageHint.textContent;
      this.elements.showIcon.title=I.t("iconHint");this.elements.supportLink.title=I.t("supportHint");this.elements.enabled.title=I.t("enabledHint");this.elements.defaults.title=I.t("generalDefaultsHint");
      for(const name of fieldNames){
        if(name!=="subpixel"&&!helpFor[name])this.elements[name].title=I.t("precisionHint");
        if(name!=="subpixel"){const value=I.parseNumber(this.elements[name].value);if(!value.error)this.elements[name].value=I.input(value.value);this.updateNumericARIA(name);}
        if(this.errors.has(name))this.showValidation(name,this.errors.get(name));
      }
      this.effectiveSignature="";this.updateControls();
    }
    refreshEntry(settings,error){const e=this.elements;e.entry.title=I.t(error?"entryBypass":settings.enabled?"entryOn":"entryOff")+" · "+I.t("openSettings")+" · "+I.t("moveIconHint");e.entry.setAttribute("aria-pressed",String(settings.enabled&&!error));e.showIcon.checked=!settings.iconHidden;this.layout();}
    togglePanel(force){
      const e=this.elements,open=force??e.panel.hidden;if(open){const b=this.player.getBoundingClientRect();if(Math.min(b.bottom,innerHeight)-Math.max(0,b.top)<80)this.player.scrollIntoView({block:"nearest",inline:"nearest"});}
      if(!open&&!e.panel.hidden)this.actions.cancel();
      e.panel.hidden=!open;e.entry.setAttribute("aria-expanded",String(open));this.layout();
      (open?e.close:!e.entry.hidden?e.entry:this.player.querySelector("video"))?.focus({preventScroll:true});
    }
    layout(){
      this.updateRatioHint();this.updateWork();
      const e=this.elements,open=!e.panel.hidden,bounds=this.player.getBoundingClientRect();
      const width=this.player.clientWidth,height=this.player.clientHeight,sx=bounds.width/width||1,sy=bounds.height/height||1;
      let toolbarTop=height-50;
      for(const control of this.player.querySelectorAll('.ytp-chrome-bottom,.ytp-chrome-controls,[role="slider"]')){
        const r=control.getBoundingClientRect(),style=getComputedStyle(control),top=(r.top-bounds.top)/sy;
        if(r.width&&r.height&&style.display!=="none"&&top>=height*.5)toolbarTop=Math.min(toolbarTop,top);
      }
      const settings=this.actions.settings();this.icon=iconPlacement(width,height,toolbarTop,this.drag?.position||settings.iconPosition);
      Object.assign(e.entry.style,{left:this.icon.x+"px",top:this.icon.y+"px"});
      const left=Math.max(12,(12-bounds.left)/sx),right=Math.min(width-12,(innerWidth-12-bounds.left)/sx),top=Math.max(12,(12-bounds.top)/sy),bottom=Math.min(height-12,(innerHeight-12-bounds.top)/sy),room=Math.max(60,bottom-top);
      const anchorVisible=this.icon.y>=top&&this.icon.y+34<=bottom;
      e.entry.hidden=settings.iconHidden||open&&(room<300||!anchorVisible);
      const panelRoom=open&&!e.entry.hidden?Math.max(60,Math.min(room,Math.max(this.icon.y-8-top,bottom-this.icon.y-42))):room;
      // offsetHeight is integral. A fractional cap rounded upward can reject
      // both free sides and wrongly place the panel over the centered icon.
      const panelWidth=Math.max(100,Math.min(384,right-left));e.panel.style.inlineSize=panelWidth+"px";e.panel.style.maxHeight=Math.floor(panelRoom)+"px";
      const panelHeight=e.panel.offsetHeight,above=this.icon.y-8-panelHeight,below=this.icon.y+42;
      Object.assign(e.panel.style,{left:clamp(this.icon.x+34-panelWidth,left,Math.max(left,right-panelWidth))+"px",top:clamp(above>=top?above:below+panelHeight<=bottom?below:top,top,Math.max(top,bottom-panelHeight))+"px"});
    }
    destroy(){this.drag=null;this.host.remove();}
    updateProfileControls(state=this.profileState){
      if(!state)return;this.profileState=state;const e=this.elements;
      e.useMyDefault.disabled=!state.defaultAvailable||!state.hasPersonal;e.apply.disabled=!state.profileDirty;
      e.saveMyDefault.disabled=!state.defaultAvailable||state.defaultSaving||state.profileDirty;
      e.retryProcessing.hidden=!state.error;e.retryProcessing.disabled=!!state.profileDirty;
      e.useMyDefault.title=I.t(!state.defaultAvailable?"profileLoadFailed":state.hasPersonal?"restoreDefaultHint":"noPersonalDefault");e.saveMyDefault.title=I.t("saveDefaultHint");e.retryStorage.hidden=!state.retryStorage;
      const message=state.defaultSaving?"defaultSaving":{saved:"defaultSaved",failed:"defaultSaveFailed"}[state.defaultSaveState];e.defaultStatus.textContent=message?I.t(message):"";
    }
    setEffective(area,regions){
      if(!area)return;if(regions)this.lastRegions=regions;
      const selected=this.lastRegions?.selected??area.regions.length,signature=[I.code,area.sourceWidth,area.sourceHeight,area.winx,area.winy,area.analysisWidth,area.analysisHeight,area.analysisDx,area.analysisDy,selected,area.regions.length].join(":");
      if(signature===this.effectiveSignature)return;this.effectiveSignature=signature;
      this.elements.effective.textContent=I.t("effectiveGrid",{sourceWidth:I.number(area.sourceWidth),sourceHeight:I.number(area.sourceHeight),width:I.number(area.winx),height:I.number(area.winy),selected:I.number(selected),count:I.number(area.regions.length)})+"\n"+area.regions.map(r=>`${I.number(r.id+1)}: ${I.number(r.width)}×${I.number(r.height)} → ${I.number(r.analysisWidth)}×${I.number(r.analysisHeight)}; ±${I.number(r.analysisDx*r.scaleX,1)} / ±${I.number(r.analysisDy*r.scaleY,1)} px`).join(" · ");
      this.updateRatioHint();this.updateWork();
    }
    publish(state){
      this.updateProfileControls(state);
      const n=(value,digits=0)=>I.number(value,digits);
      this.elements.perf.textContent=[I.t("perfOutput",{fps:n(state.outputFps,1)}),I.t("perfTiming",{mean:n(state.meanMs,2),p95:n(state.p95Ms,2)}),
        I.t("perfStages",{read:n(state.copyMs,2),compute:n(state.computeMs,2),draw:n(state.drawMs,2)}),
        I.t("perfSource",{dropped:n(state.dropped),total:n(state.total),missed:n(state.callbackMisses)}),I.t("perfUncertain",{count:n(state.invalidMatches)}),
        I.t("perfRegions",{inliers:n(state.regions?.inliers||0),selected:n(state.regions?.selected||0)}),I.t("perfFormat",{format:state.pixelFormat||"—"}),...(state.errorDetail?[I.t("perfError",{error:state.errorDetail})]:[])].join("\n");
    }
  }
  root.YTSteadyPlayerUI=PlayerUI;
  if(typeof module!=="undefined"&&module.exports)module.exports={iconPlacement,logPosition,logValue};
})(globalThis);
