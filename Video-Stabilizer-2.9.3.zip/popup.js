"use strict";
const I=YTSteadyI18n,S=YTSteadySettings,F=YTSteadyProfiles,language=document.getElementById("language"),status=document.getElementById("status");
if(globalThis.YTSteadySupport?.enabled){document.getElementById("supportLink").href=YTSteadySupport.supportUrl;document.getElementById("support").hidden=false;}
function render(){
  document.documentElement.lang=I.tag;document.documentElement.dir=I.dir;document.title=I.t("actionTitle");
  I.translateDOM(document);I.languageOptions(language);const hint=document.getElementById("languageHint");hint.textContent=I.t("automaticHint",{language:I.languageName});hint.hidden=I.choice!=="auto";
  document.getElementById("about").textContent=I.t("popupAbout",{zoom:I.input(S.defaults.zoom)});
}
language.addEventListener("change",async()=>{
  const choice=language.value;I.setLanguage(choice);render();
  try{await chrome.storage.local.set(F.preferenceWrites({language:choice}));}
  catch{status.dataset.i18n="statusSaveFailed";render();}
});
document.getElementById("open").addEventListener("click",async()=>{
  try{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});const result=await chrome.tabs.sendMessage(tab.id,{type:"yt-steady-panel"});if(result?.found){window.close();return;}}
  catch{}status.dataset.i18n="popupRefresh";render();
});
async function loadLanguage(){I.setLanguage(F.decode(await chrome.storage.local.get(Object.values(F.keys))).preferences.language);render();}
chrome.storage.onChanged.addListener((changes,area)=>{if(area==="local"&&(changes[F.keys.language]||changes[F.keys.legacy]))loadLanguage().catch(()=>{});});
loadLanguage().catch(()=>render());
