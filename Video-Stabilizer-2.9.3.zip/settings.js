/* Schema 9: one region-relative search definition for every profile.
 * Percentages describe source regions; Q only determines the sampling grid. */
(function(root){
  "use strict";
  const I=root.YTSteadyI18n||(typeof module!=="undefined"&&module.exports?require("./i18n.js"):null);
  const fields={
  "centerRatio": {
    "value": 85,
    "min": 0,
    "max": 100,
    "step": 0.0001,
    "nudge": 1
  },
  "sampleRatio": {
    "value": 30,
    "min": 0.0001,
    "max": 100,
    "step": 0.0001,
    "nudge": 1
  },
  "searchRange": {
    "value": 30,
    "min": 0,
    "max": 50,
    "step": 0.0001,
    "nudge": 0.25
  },
  "compensationLimit": {
    "value": 15,
    "min": 0,
    "max": 204800,
    "step": 0.0001,
    "nudge": 0.25,
    "sliderMax": 100
  },
  "zoom": {
    "value": 1,
    "min": 0.0001,
    "max": 32768,
    "step": 0.0001,
    "nudge": 0.01,
    "sliderMin": 0.25,
    "sliderMax": 4
  },
  "cutoff": {
    "value": 0.5,
    "min": 0.0001,
    "max": 120,
    "step": 0.0001,
    "nudge": 0.05,
    "sliderMax": 5
  },
  "damping": {
    "value": 0.3,
    "min": 0,
    "max": 3.4028234663852886e+38,
    "step": 0.0001,
    "nudge": 0.05,
    "sliderMax": 3
  },
  "trust": {
    "value": 4,
    "min": 0.1,
    "max": 100,
    "step": 0.0001,
    "nudge": 0.1
  },
  "stab": {
    "value": 1,
    "min": 0,
    "max": 10,
    "step": 0.0001,
    "nudge": 0.1
  },
  "subpixel": {
    "value": 1,
    "min": 0,
    "max": 1,
    "step": 1
  }
};
  const modes=["single","cross","x","adaptive"],limits=Object.freeze({minSamples:8,maxAxis:8192,maxMemoryBytes:2147483648,maxMotion:65536,maxRate:240});
  const round=n=>Math.round(n*10000)/10000;
  const sliderSpec=name=>{const s=fields[name];return {...s,min:s.sliderMin??s.min,max:s.sliderMax??s.max};};
  const iconPreferences=value=>({iconHidden:value?.iconHidden===true,iconPosition:value?.iconPosition&&[value.iconPosition.x,value.iconPosition.y].every(Number.isFinite)?{x:Math.max(0,Math.min(1,value.iconPosition.x)),y:Math.max(0,Math.min(1,value.iconPosition.y))}:null});
  const defaults=Object.freeze({schema:9,parameterModel:"unified",units:"percent",windowLayout:"grid",samplingMode:"relative",searchMode:"regional",precision:"standard",language:"auto",enabled:true,mode:"single",centerPriority:false,...iconPreferences(null),...Object.fromEntries(Object.entries(fields).map(([k,v])=>[k,v.value]))});
  function normalize(value){
    const result={...defaults,mode:modes.includes(value?.mode)?value.mode:defaults.mode,centerPriority:value?.centerPriority===true,language:I?I.normalizeChoice(value?.language):"auto",enabled:typeof value?.enabled==="boolean"?value.enabled:true,...iconPreferences(value)};
    for(const [key,spec]of Object.entries(fields)){let n=typeof value?.[key]==="number"&&Number.isFinite(value[key])?value[key]:spec.value;if(["zoom","cutoff","sampleRatio"].includes(key)&&n<=0)n=spec.value;n=Math.max(spec.min,Math.min(spec.max,n));result[key]=spec.step===1?Math.round(n):round(n);}
    return result;
  }
  function dimensionsOK(width,height){
    if(!Number.isInteger(width)||!Number.isInteger(height)||width<32||height<32||width>32768||height>32768)throw new Error("source-dimensions-too-small-or-large");
  }
  function grid(width,height,ratio){
    dimensionsOK(width,height);
    if(!Number.isFinite(ratio)||ratio<0||ratio>100)throw Error("invalid-center-ratio");
    const cut=span=>{const center=Math.round(span*ratio/100),edge=Math.floor((span-center)/2);return [0,edge,edge+center,span];};
    const xs=cut(width),ys=cut(height),cells=[];
    for(let row=0;row<3;row++)for(let col=0;col<3;col++)cells.push({id:row*3+col,left:xs[col],top:ys[row],width:xs[col+1]-xs[col],height:ys[row+1]-ys[row],row,col});
    return cells;
  }
  function plan(value,width,height){
    dimensionsOK(width,height);const settings=normalize(value),single=settings.mode==="single",centerId=4,mask=settings.mode==="cross"?[1,3,4,5,7]:[0,2,4,6,8];
    const cells=grid(width,height,settings.centerRatio).map(r=>({...r,weight:single?(r.id===centerId?1:0):settings.mode==="adaptive"||mask.includes(r.id)?settings.centerPriority&&r.id===centerId?2:1:0})),center=cells[centerId];
    const regions=cells.filter(r=>r.weight>0&&r.width>=32&&r.height>=32).map((r,slot)=>{
      const sample=span=>Math.min(span,Math.max(limits.minSamples,Math.round(span*settings.sampleRatio/100))),analysisWidth=sample(r.width),analysisHeight=sample(r.height),scaleX=r.width/analysisWidth,scaleY=r.height/analysisHeight;
      const capX=Math.floor((analysisWidth-1)/2),capY=Math.floor((analysisHeight-1)/2),analysisDx=Math.min(capX,Math.floor(analysisWidth*settings.searchRange/100+1e-9)),analysisDy=Math.min(capY,Math.floor(analysisHeight*settings.searchRange/100+1e-9));
      return {...r,slot,analysisWidth,analysisHeight,scaleX,scaleY,analysisDx,analysisDy,searchCapX:capX/analysisWidth*100,searchCapY:capY/analysisHeight*100,effectiveSearchX:analysisDx/analysisWidth*100,effectiveSearchY:analysisDy/analysisHeight*100};
    });
    if(!regions.length)throw Error("analysis-regions-too-small");
    const analysisWidth=Math.max(...regions.map(r=>r.analysisWidth)),analysisHeight=Math.max(...regions.map(r=>r.analysisHeight)),atlas=atlasLayout(regions,true),r=regions[0],compensationCap=limits.maxMotion/Math.max(width,height)*100,effectiveCompensation=Math.min(settings.compensationLimit,compensationCap);
    // Each axis is bounded by its own lattice. A narrow region never caps another.
    const searches=regions.flatMap(r=>[r.effectiveSearchX,r.effectiveSearchY]);
    return {winx:center.width,winy:center.height,left:center.left,top:center.top,sourceWidth:width,sourceHeight:height,mode:settings.mode,windowLayout:"grid",samplingMode:"relative",searchMode:"regional",centerId,cells,regions,analysisWidth,analysisHeight,atlas,work:estimateWork(regions,settings.mode,atlas),
      requestedSearch:settings.searchRange,effectiveSearchMin:Math.min(...searches),effectiveSearchMax:Math.max(...searches),searchLimited:regions.some(r=>settings.searchRange>r.searchCapX+1e-9||settings.searchRange>r.searchCapY+1e-9),
      compensationCap,effectiveCompensation,compensationLimited:settings.compensationLimit>compensationCap,samplingRaised:regions.some(r=>Math.round(r.width*settings.sampleRatio/100)<limits.minSamples||Math.round(r.height*settings.sampleRatio/100)<limits.minSamples),
      analysisDx:Math.max(...regions.map(r=>r.analysisDx)),analysisDy:Math.max(...regions.map(r=>r.analysisDy)),scaleX:center.width/analysisWidth,scaleY:center.height/analysisHeight,limitX:Math.min(limits.maxMotion,width*effectiveCompensation/100),limitY:Math.min(limits.maxMotion,height*effectiveCompensation/100),
      direct:regions.length===1&&r.scaleX===1&&r.scaleY===1,preserveNativeZero:false};
  }
  function atlasLayout(regions,gridLayout){
    if(gridLayout){
      const cols=[0,0,0],rows=[0,0,0];for(const r of regions){cols[r.col]=Math.max(cols[r.col],r.analysisWidth);rows[r.row]=Math.max(rows[r.row],r.analysisHeight);}
      return {width:cols.reduce((a,b)=>a+b,0),height:rows.reduce((a,b)=>a+b,0),positions:regions.map(r=>({x:cols.slice(0,r.col).reduce((a,b)=>a+b,0),y:rows.slice(0,r.row).reduce((a,b)=>a+b,0)}))};
    }
    let x=0,y=0,rowHeight=0,width=0;const positions=[];
    for(const r of regions){if(x&&x+r.analysisWidth>limits.maxAxis){y+=rowHeight;x=0;rowHeight=0;}positions.push({x,y});x+=r.analysisWidth;rowHeight=Math.max(rowHeight,r.analysisHeight);width=Math.max(width,x);}
    return {width,height:y+rowHeight,positions};
  }
  const fftUnits=r=>r.analysisWidth*r.analysisHeight*(Math.log2(r.analysisWidth)+Math.log2(r.analysisHeight));
  // Operation index, not CPU utilization or predicted milliseconds. The fixed
  // 1080p/R50/cross/Q25 baseline makes resolution changes visible in the cost.
  const workBaseline=2*[[240,135],[240,68],[240,68],[120,135],[120,135]].reduce((sum,[w,h])=>sum+fftUnits({analysisWidth:w,analysisHeight:h}),0);
  function estimateWork(regions,mode,atlas){
    const counts=regions.map(r=>r.analysisWidth*r.analysisHeight),costs=regions.map(fftUnits).sort((a,b)=>a-b),selected=mode==="adaptive"?Math.min(5,regions.length):regions.length;
    const minUnits=2*costs.slice(0,selected).reduce((a,b)=>a+b,0),maxUnits=(mode==="adaptive"?3:2)*costs.slice(-selected).reduce((a,b)=>a+b,0);
    const w=Math.max(...regions.map(r=>r.analysisWidth)),h=Math.max(...regions.map(r=>r.analysisHeight)),complex=(w,h)=>h*(Math.floor(w/2)+1)*8;
    const nativeBytes=w*h+3*complex(w,h)+regions.reduce((n,r)=>n+r.analysisWidth*r.analysisHeight+complex(r.analysisWidth,r.analysisHeight),0);
    const readbackBytes=atlas.width*atlas.height*8+counts.reduce((a,b)=>a+b,0);
    const workingBytes=Math.ceil(nativeBytes*1.25+readbackBytes+8*1024*1024);
    return {samplePixels:counts.reduce((a,b)=>a+b,0),selected,relativeMin:minUnits/workBaseline,relativeMax:maxUnits/workBaseline,nativeBytes,workingBytes,
      supported:w<=limits.maxAxis&&h<=limits.maxAxis&&nativeBytes+16*1024*1024<limits.maxMemoryBytes&&atlas.width<=32767&&atlas.height<=32767};
  }
  const api={fields,modes,limits,sliderSpec,iconPreferences,defaults,normalize,grid,plan};root.YTSteadySettings=api;
  if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(globalThis);
