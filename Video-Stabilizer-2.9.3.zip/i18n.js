/* Local catalogs, locale resolution, bidi-safe text and numeric input.
 * No network requests or page-language changes. GPL-2.0-or-later. */
(function(root){
  "use strict";
  const data=root.YTSteadyLocales||(typeof module!=="undefined"&&module.exports?require("./locales.js"):null);
  if(!data)throw new Error("locales-bundle-missing");
  const languages=data.languages,catalogs=data.catalogs,byCode=new Map(languages.map(l=>[l.code,l]));
  function matchLocale(raw){
    if(typeof raw!=="string")return null;
    const tag=raw.trim().replace(/_/g,"-").toLowerCase(),base=tag.split("-")[0];
    if(base==="zh")return /(?:^|-)(hant|tw|hk|mo)(?:-|$)/.test(tag)?"zh_TW":"zh_CN";
    if(base==="pt")return "pt_BR";
    return languages.find(l=>l.tag.toLowerCase()===tag)?.code||(byCode.has(base)?base:null);
  }
  function normalizeChoice(value){return value==="auto"||value===undefined?"auto":byCode.has(value)?value:"auto";}
  function browserLanguages(){
    let ui="";try{ui=root.chrome?.i18n?.getUILanguage?.()||"";}catch{}
    return [ui,...(root.navigator?.languages||[root.navigator?.language||"en"])].filter(Boolean);
  }
  function resolve(choice,candidates=browserLanguages()){
    if(byCode.has(choice))return choice;
    for(const candidate of candidates){const code=matchLocale(candidate);if(code)return code;}
    return "en";
  }
  const stripBidi=s=>String(s).replace(/[\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,"");
  function parseNumber(value){
    let text=stripBidi(value??"").trim();if(!text)return {error:"validationRequired"};
    text=text.replace(/[\u0660-\u0669\u06f0-\u06f9\u0966-\u096f\uff10-\uff19]/g,c=>{
      const n=c.charCodeAt(0),zero=n>=0xff10?0xff10:n>=0x0966&&n<=0x096f?0x0966:n>=0x06f0?0x06f0:0x0660;
      return String(n-zero);
    }).replace(/\uff0e/g,".").replace(/\uff0c/g,",").replace(/\u2212/g,"-");
    // Grouping is deliberately rejected: guessing whether 1,024 means a
    // decimal or a thousand can silently change a stabilization parameter.
    if(!/^[+-]?(?:\d+(?:[.,\u066b]\d*)?|[.,\u066b]\d+)$/.test(text))return {error:"validationNumber"};
    const number=Number(text.replace(/[,\u066b]/g,"."));
    return Number.isFinite(number)?{value:number}:{error:"validationNumber"};
  }
  function validate(value,spec){
    const parsed=parseNumber(value);if(parsed.error)return parsed;
    const number=parsed.value;
    if(number<spec.min-1e-9||number>spec.max+1e-9)return {error:"validationRange",args:{min:spec.min,max:spec.max}};
    const steps=(number-spec.min)/spec.step;
    if(Math.abs(steps-Math.round(steps))>1e-6)return {error:"validationStep",args:{step:spec.step}};
    return {value:Math.round(number*10000)/10000};
  }
  let choice="auto",code=resolve("auto"),formatTag=byCode.get(code).tag;
  const formatterCache=new Map();
  function formatter(options){
    const key=formatTag+JSON.stringify(options);if(!formatterCache.has(key))formatterCache.set(key,new Intl.NumberFormat(formatTag,options));
    return formatterCache.get(key);
  }
  function number(value,digits=0){return formatter({minimumFractionDigits:digits,maximumFractionDigits:digits}).format(value);}
  function input(value){return formatter({useGrouping:false,maximumFractionDigits:4}).format(value);}
  function t(key,args={}){
    const message=catalogs[code]?.[key]?.message??catalogs.en[key]?.message??key;
    return message.replace(/\{(\w+)\}/g,(_,name)=>"\u2068"+stripBidi(args[name]??"—")+"\u2069");
  }
  function setLanguage(next,candidates=browserLanguages()){
    choice=normalizeChoice(next);code=resolve(choice,candidates);formatTag=byCode.get(code).tag;
    if(choice==="auto")for(const candidate of candidates){
      if(matchLocale(candidate)!==code)continue;
      try{formatTag=Intl.getCanonicalLocales(candidate.replace(/_/g,"-"))[0];break;}catch{}
    }
    return code;
  }
  function translateDOM(container){
    for(const element of container.querySelectorAll("[data-i18n]"))element.textContent=t(element.dataset.i18n);
    for(const [dataKey,attribute]of [["i18nAria","aria-label"],["i18nTitle","title"]])
      for(const element of container.querySelectorAll(`[data-${dataKey.replace(/[A-Z]/g,c=>"-"+c.toLowerCase())}]`))element.setAttribute(attribute,t(element.dataset[dataKey]));
  }
  function languageOptions(select){
    if(!select.options.length){
      const automatic=document.createElement("option");automatic.value="auto";select.append(automatic);
      for(const language of languages){const option=document.createElement("option");option.value=language.code;option.textContent=language.name;option.lang=language.tag;option.dir=language.dir;select.append(option);}
    }
    select.options[0].textContent=t("automatic");select.value=choice;
  }
  const api={languages,matchLocale,normalizeChoice,resolve,parseNumber,validate,stripBidi,setLanguage,t,number,input,translateDOM,languageOptions,
    get code(){return code;},get choice(){return choice;},get tag(){return formatTag;},get dir(){return byCode.get(code).dir;},
    get languageName(){return byCode.get(code).name;}};
  root.YTSteadyI18n=api;if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(globalThis);
