/* Spatial sampling and translation consensus. GPL-2.0-or-later. */
(function(root){
  "use strict";
  function select(samples,plan,previous=[]){
    const viable=samples.filter(s=>Number.isFinite(s.texture)&&s.texture>=2);
    if(plan.mode!=="adaptive")return samples.map(s=>s.id);
    const score=s=>s.texture*(previous.includes(s.id)?1.1:1),rank=viable.slice().sort((a,b)=>score(b)-score(a)||a.id-b.id),chosen=[],rows=[0,0,0],cols=[0,0,0];
    // Texture alone can select an entire moving center column. Limit each row
    // and column to two votes, so the grid keeps spatially diverse evidence.
    const add=s=>{const row=s.row??Math.floor(s.id/3),col=s.col??s.id%3;if(chosen.length<5&&!chosen.includes(s.id)&&rows[row]<2&&cols[col]<2){chosen.push(s.id);rows[row]++;cols[col]++;}};
    const center=rank.find(s=>s.id===plan.centerId);if(center)add(center);for(const s of rank)add(s);
    return chosen;
  }
  function fuse(samples,selected,plan,trust){
    const minimum=plan.regions.length>1?Math.max(.1,trust/2):trust;
    const valid=samples.filter(s=>selected.includes(s.id)&&(s.weight??1)>0&&s.valid&&(plan.regions.length===1||s.texture>=2)&&Number.isFinite(s.dx)&&Number.isFinite(s.dy)&&Number.isFinite(s.trust)&&s.trust>=minimum);
    // Unreliable cells abstain. Require two independent agreeing regions and
    // a majority of the reliable votes; a flat/low-trust corner must not veto
    // two good background estimates. One surviving region is never enough.
    const required=plan.regions.length===1?1:Math.max(2,Math.ceil(valid.length*.6));
    // Sampling uncertainty alone becomes too permissive relative to a small
    // picture at low Q. Also bound agreement by frame proportions (the former
    // 1080p/4-source-pixels-per-sample reference). Fixed profiles stay unchanged.
    const scale=(a,b,axis)=>{const sample=Math.sqrt(((a[axis]??plan[axis])**2+(b[axis]??plan[axis])**2)/2);return plan.samplingMode==="relative"?Math.min(sample,axis==="scaleX"?plan.sourceWidth/480:plan.sourceHeight/270):sample;};
    const distance=(a,b)=>Math.hypot((a.dx-b.dx)/scale(a,b,"scaleX"),(a.dy-b.dy)/scale(a,b,"scaleY"));
    const weight=s=>(s.weight??(plan.mode==="center"&&s.id===plan.centerId?2:1))*Math.max(.1,Math.min(3,s.trust/10));
    const clusters=valid.map(seed=>{const members=valid.filter(s=>distance(seed,s)<=1.5);return {members,weight:members.reduce((n,s)=>n+weight(s),0)};})
      .sort((a,b)=>b.members.length-a.members.length||b.weight-a.weight);
    const best=clusters[0];
    if(!best||best.members.length<required)return {valid:false,dx:0,dy:0,trust:0,inliers:[],selected:selected.length,reason:1};
    const rival=clusters.find(c=>c.members.every(s=>!best.members.includes(s)));
    if(rival&&rival.members.length===best.members.length&&rival.weight>=best.weight*.8)return {valid:false,dx:0,dy:0,trust:0,inliers:[],selected:selected.length,reason:2};
    const total=best.weight,average=key=>best.members.reduce((n,s)=>n+s[key]*weight(s),0)/total;
    // Independent agreeing cells add evidence. This is a heuristic score,
    // not a probability: keep a per-cell floor and require the combined score
    // to meet the user's threshold. The original single-region score is kept.
    const combined=Math.min(100,average("trust")*Math.sqrt(best.members.length));
    if(combined<trust)return {valid:false,dx:0,dy:0,trust:combined,inliers:[],selected:selected.length,reason:3};
    return {valid:true,dx:average("dx"),dy:average("dy"),trust:combined,inliers:best.members.map(s=>s.id),selected:selected.length,reason:0};
  }
  const api={select,fuse};root.YTSteadyRegions=api;if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(globalThis);
