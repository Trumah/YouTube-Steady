/* Processing profiles are separate from shared UI preferences. GPL-2.0-or-later.
 * Processing records before schema 9 / format 2 are intentionally discarded.
 * Only the current personal profile is loaded; a new save drops older backups. */
(function(root){
  "use strict";
  const S=root.YTSteadySettings||(typeof module!=="undefined"&&module.exports?require("./settings.js"):null);
  const keys=Object.freeze({legacy:"ytSteadySettings",personal:"ytSteadyMyDefault",language:"ytSteadyLanguage",iconHidden:"ytSteadyIconHidden",iconPosition:"ytSteadyIconPosition"});
  const processingKeys=Object.freeze(["enabled","mode","centerPriority",...Object.keys(S.fields)]);
  const snapshot=value=>{const s=S.normalize(value);return {schema:s.schema,...Object.fromEntries(processingKeys.map(k=>[k,s[k]]))};};
  const equal=(a,b)=>{const x=snapshot(a),y=snapshot(b);return processingKeys.every(k=>x[k]===y[k]);};
  const preferences=value=>{const s=S.normalize(value);return {language:s.language,...S.iconPreferences(s)};};
  const validProfile=p=>{if(!p||typeof p!=="object"||Array.isArray(p)||p.schema!==S.defaults.schema)return false;const n=snapshot(p);return processingKeys.every(k=>Object.hasOwn(p,k)&&p[k]===n[k]);};
  function decode(raw={}){
    const legacy=S.normalize(raw[keys.legacy]),record=raw[keys.personal],hasPersonal=record?.format===2&&validProfile(record.profile),personal=hasPersonal?snapshot(record.profile):snapshot(S.defaults);
    const pref={...preferences(legacy)};for(const name of ["language","iconHidden","iconPosition"])if(Object.hasOwn(raw,keys[name]))pref[name]=raw[keys[name]];
    return {personal,hasPersonal:!!hasPersonal,preferences:preferences(pref)};
  }
  const record=value=>({format:2,profile:snapshot(value)});
  const preferenceWrites=patch=>{const p=preferences(patch);return Object.fromEntries(["language","iconHidden","iconPosition"].filter(k=>Object.hasOwn(patch,k)).map(k=>[keys[k],p[k]]));};
  class Session{
    constructor(data,identity){this.identity=identity;this.touched=false;this.defaultAvailable=true;this.receive(data);this.current=snapshot(this.personal);}
    receive(data){this.personal=snapshot(data.personal);this.hasPersonal=!!data.hasPersonal;this.preferences=preferences(data.preferences);}
    settings(){return S.normalize({...this.current,...this.preferences});}
    apply(value){this.touched=true;const next=snapshot(value);if(equal(next,this.current))return false;this.current=next;return true;}
    newVideo(identity){if(identity===this.identity)return false;this.identity=identity;this.current=snapshot(this.personal);this.touched=false;return true;}
  }
  const api={keys,processingKeys,snapshot,equal,preferences,decode,record,preferenceWrites,Session};root.YTSteadyProfiles=api;
  if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(globalThis);
