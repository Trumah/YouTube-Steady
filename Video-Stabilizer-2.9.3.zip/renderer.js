/* Each job owns one VideoFrame. Analysis and output always use that same object.
 * The original video's audio, timeline and controls stay in YouTube's player.
 * The video itself receives no CSS changes. GPL-2.0, see LICENSE.txt.
 */
(function(root){
  "use strict";
  let modulePromise=null,owner=null,queue=Promise.resolve();
  function exclusive(fn){const next=queue.then(fn,fn);queue=next.catch(()=>{});return next;}
  async function loadModule(asset,signal){
    // Node reference tests retain filesystem loading. Chrome injects the browser
    // bytes as a packaged content script: do not fetch an extension URL from the
    // host page. This also keeps seek/retry independent of cross-origin access.
    if(signal?.aborted)throw Error("wasm-load-cancelled");
    if(typeof root.window==="undefined")return root.YTDePanModule({locateFile:name=>asset(name)});
    const data=root.YTSteadyWasmData;
    if(data?.format!==1||typeof data.getBytes!=="function")throw Error("core-version-mismatch-reload-extension");
    const compiled=await root.WebAssembly.compile(data.getBytes());
    if(signal?.aborted)throw Error("wasm-load-cancelled");
    return root.YTDePanModule({instantiateWasm(imports,ready){
      const instance=new root.WebAssembly.Instance(compiled,imports);ready(instance,compiled);return instance.exports;
    }});
  }
  async function createCore(asset,signal){
    if(!modulePromise){const pending=loadModule(asset,signal).catch(error=>{if(modulePromise===pending)modulePromise=null;throw error;});modulePromise=pending;}
    const module=await modulePromise;
    if(!root.YTSteadyRegions||module._ys_api_version?.()!==6){modulePromise=null;throw Error("core-version-mismatch-reload-extension");}
    return new Core(module);
  }
  class Core{
    constructor(module){this.module=module;this.signature="";this.resetNeeded=true;this.input=module._ys_input_ptr();this.result=module._ys_result_ptr()>>2;this.selection=[];}
    invalidate(){this.resetNeeded=true;}
    activate(settings,area,fps){
      if(!area.work.supported)throw Error("sampling-capacity-exceeded");
      const signature=JSON.stringify([area,settings.trust,settings.stab,settings.cutoff,settings.damping]);
      if(owner!==this||signature!==this.signature){
        const localTrust=area.regions.length>1?Math.max(.1,settings.trust/2):settings.trust;
        const code=this.module._ys_configure(area.analysisWidth,area.analysisHeight,area.analysisDx,area.analysisDy,localTrust,settings.stab,settings.cutoff,settings.damping,area.limitX,area.limitY,fps);
        if(code!==0)throw new Error("core-configuration-failed: "+code);
        // Unequal grid cells lose correlation confidence by different amounts
        // during fast camera motion. Their spatial consensus handles this;
        // the original temporal drop veto remains for single/custom profiles.
        const temporalGuard=area.windowLayout==="grid"&&area.regions.length>1?0:1;
        for(const r of area.regions){const result=this.module._ys_region_configure(r.slot,r.analysisWidth,r.analysisHeight,r.analysisDx,r.analysisDy,temporalGuard);if(result!==0)throw Error("region-configuration-failed: "+result);}
        // Resizing the native workspace can move the input allocation and grow
        // linear memory. Never retain an old pointer or heap view across it.
        this.input=this.module._ys_input_ptr();this.result=this.module._ys_result_ptr()>>2;
        owner=this;this.signature=signature;this.resetNeeded=false;this.selection=[];
      }else if(this.resetNeeded){this.module._ys_reset();this.resetNeeded=false;this.selection=[];}
      this.module._ys_set_fps(fps);
    }
    process(){
      this.module._ys_process();return this.state();
    }
    state(){
      const s=this.module.HEAPF32.subarray(this.result,this.result+12);
      return {dx:s[0],dy:s[1],trust:s[2],mapX:s[3],mapY:s[4],valid:!!s[5],frame:s[6],base:s[7],reason:s[8],change:s[9],deviation:s[10],stabilitySteps:s[11]};
    }
    processRegions(samples,plan,settings){
      const R=root.YTSteadyRegions,selected=R.select(samples,plan,this.selection),vectors=[];
      for(const sample of samples){
        if(sample.pixels&&sample.pixels.length!==sample.analysisWidth*sample.analysisHeight)throw Error("invalid-region-sample-length");
        if(sample.pixels)this.module.HEAPU8.set(sample.pixels,this.input);
        this.module._ys_region(sample.slot,selected.includes(sample.id)?1:0);const s=this.state();
        if(s.reason<0)throw Error("region-processing-failed: "+s.reason);
        vectors.push({...sample,pixels:undefined,texture:sample.pixels?sample.texture:s.deviation,dx:(!plan.preserveNativeZero&&Math.abs(s.dx)<=.012?0:s.dx)*sample.scaleX,dy:s.dy*sample.scaleY,valid:s.valid,trust:s.trust,reason:s.reason});
      }
      const fused=R.fuse(vectors,selected,plan,settings.trust);
      this.module._ys_push_motion(fused.dx,fused.dy,fused.valid?1:0);const motion=this.state();
      motion.trust=fused.trust;motion.reason=selected.length&&vectors.filter(v=>selected.includes(v.id)).every(v=>v.reason===1)?1:fused.valid?0:2;
      motion.regions={selected:selected.length,candidates:plan.regions.length,inliers:fused.inliers.length,ids:selected,inlierIds:fused.inliers,vectors:vectors.map(({id,dx,dy,trust,valid,texture})=>({id,dx,dy,trust,valid,texture}))};
      this.selection=selected;return motion;
    }
    processSingle(plan,settings){return this.processRegions([{...plan.regions[0],pixels:null,texture:255}],plan,settings);}
  }
  class LumaReader{
    constructor(){this.bytes=new Uint8Array(0);this.canvas=document.createElement("canvas");this.ctx=this.canvas.getContext("2d",{willReadFrequently:true,alpha:false});this.format="";this.tiles=[];}
    readRegions(frame,plan){
      const {regions}=plan,{width:atlasWidth,height:atlasHeight,positions}=plan.atlas;
      if(this.canvas.width!==atlasWidth||this.canvas.height!==atlasHeight){this.canvas.width=atlasWidth;this.canvas.height=atlasHeight;this.tiles=[];}
      const sx=frame.displayWidth/frame.visibleRect.width,sy=frame.displayHeight/frame.visibleRect.height,ctx=this.ctx;
      ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality="high";ctx.fillStyle="#000";ctx.fillRect(0,0,atlasWidth,atlasHeight);
      regions.forEach((r,n)=>ctx.drawImage(frame,r.left*sx,r.top*sy,r.width*sx,r.height*sy,positions[n].x,positions[n].y,r.analysisWidth,r.analysisHeight));
      const rgba=ctx.getImageData(0,0,atlasWidth,atlasHeight).data,matrix=frame.colorSpace?.matrix;
      const sd=matrix==="smpte170m"||matrix==="bt470bg"||(!matrix&&frame.visibleRect.height<=576),cr=sd ? .299 : .2126,cg=sd ? .587 : .7152,cb=sd ? .114 : .0722;
      const full=frame.colorSpace?.fullRange===true,range=full?1:219/255,black=full?0:16;
      const result=regions.map((region,n)=>{
        const w=region.analysisWidth,h=region.analysisHeight;
        if(this.tiles[n]?.length!==w*h)this.tiles[n]=new Uint8Array(w*h);
        const pixels=this.tiles[n];let sum=0,sq=0,edges=0,count=0;
        for(let y=0;y<h;y++)for(let x=0;x<w;x++){
          const p=((y+positions[n].y)*atlasWidth+positions[n].x+x)*4,v=Math.max(0,Math.min(255,Math.round(black+range*(cr*rgba[p]+cg*rgba[p+1]+cb*rgba[p+2]))));pixels[y*w+x]=v;
          if(x%4===0&&y%4===0){sum+=v;sq+=v*v;count++;if(x)edges+=Math.abs(v-pixels[y*w+x-1]);}
        }
        const texture=Math.sqrt(Math.max(0,sq/count-(sum/count)**2))+edges/count;
        return {...region,pixels,texture};
      });
      this.format=(frame.format||"RGB")+" → region atlas Y";return result;
    }
    async read(frame,area,core){
      if(area.regions){const r=area.regions[0];area={left:r.left,top:r.top,winx:r.width,winy:r.height};}
      const rect=frame.visibleRect,format=frame.format||"";
      const native8=["I420","I420A","I422","I444","NV12"].includes(format);
      const native16=/^I4(?:20|22|44)P(?:10|12)$/.test(format);
      if(native8||native16){
        const wantedX=rect.x+area.left,wantedY=rect.y+area.top;
        const x=Math.floor(wantedX/2)*2,y=Math.floor(wantedY/2)*2;
        const width=Math.ceil((wantedX+area.winx-x)/2)*2,height=Math.ceil((wantedY+area.winy-y)/2)*2;
        const crop={x,y,width,height};
        if(x>=rect.x&&y>=rect.y&&x+width<=rect.x+rect.width&&y+height<=rect.y+rect.height){
          const size=frame.allocationSize({rect:crop});
          if(this.bytes.length<size)this.bytes=new Uint8Array(size);
          const layout=await frame.copyTo(this.bytes,{rect:crop});
          const offsetX=wantedX-x,offsetY=wantedY-y,plane=layout[0],target=core.module.HEAPU8;
          if(native8){
            for(let row=0;row<area.winy;row++){
              const p=plane.offset+(row+offsetY)*plane.stride+offsetX;
              target.set(this.bytes.subarray(p,p+area.winx),core.input+row*area.winx);
            }
          }else{
            const shift=format.endsWith("10")?2:4;
            for(let row=0;row<area.winy;row++)for(let col=0;col<area.winx;col++){
              const p=plane.offset+(row+offsetY)*plane.stride+(col+offsetX)*2;
              target[core.input+row*area.winx+col]=Math.min(255,((this.bytes[p]|this.bytes[p+1]<<8)+(1<<(shift-1)))>>shift);
            }
          }
          this.format=format+" / Y";return;
        }
      }
      // RGB-backed frames use the same captured VideoFrame, never the moving
      // HTMLVideoElement. GPU YUV frames normally take the direct-luma path.
      if(this.canvas.width!==area.winx||this.canvas.height!==area.winy){this.canvas.width=area.winx;this.canvas.height=area.winy;}
      const sx=frame.displayWidth/rect.width,sy=frame.displayHeight/rect.height;
      this.ctx.drawImage(frame,area.left*sx,area.top*sy,area.winx*sx,area.winy*sy,0,0,area.winx,area.winy);
      const rgba=this.ctx.getImageData(0,0,area.winx,area.winy).data,target=core.module.HEAPU8;
      const matrix=frame.colorSpace?.matrix,sd=matrix==="smpte170m"||matrix==="bt470bg"||(!matrix&&rect.height<=576);
      const r=sd ? .299 : .2126,g=sd ? .587 : .7152,b=sd ? .114 : .0722;
      const full=frame.colorSpace?.fullRange===true,scale=full?1:219/255,black=full?0:16;
      for(let i=0,p=0;i<area.winx*area.winy;i++,p+=4)target[core.input+i]=Math.max(0,Math.min(255,Math.round(black+scale*(r*rgba[p]+g*rgba[p+1]+b*rgba[p+2]))));
      this.format=(format||"RGB")+" → Y";
    }
    reset(){this.canvas.width=this.canvas.width;this.tiles=[];}
  }
  // Shared by output and the non-interactive preview so letterboxing and CSS
  // transforms use exactly the same coordinates.
  function surfaceGeometry(video,player,frame,zoom){
    const parent=video.offsetParent&&player.contains(video.offsetParent)?video.offsetParent:player,cs=getComputedStyle(video),w=video.clientWidth,h=video.clientHeight;
    const displayW=frame?.displayWidth||video.videoWidth,displayH=frame?.displayHeight||video.videoHeight;
    if(!w||!h||!displayW||!displayH)return null;
    const factor=cs.objectFit==="cover"?Math.max(w/displayW,h/displayH):Math.min(w/displayW,h/displayH),cw=displayW*factor,ch=displayH*factor;
    const transform=(cs.transform==="none"?"":cs.transform+" ")+`scale(${zoom})`;
    const host={left:video.offsetLeft+"px",top:video.offsetTop+"px",width:w+"px",height:h+"px",transform,transformOrigin:cs.transformOrigin,translate:cs.translate,rotate:cs.rotate,scale:cs.scale,borderRadius:cs.borderRadius};
    const content={left:(w-cw)/2+"px",top:(h-ch)/2+"px",width:cw+"px",height:ch+"px"};
    return {parent,w,h,cw,ch,host,content,filter:cs.filter,opacity:cs.opacity,signature:JSON.stringify([host,content,cs.filter,cs.opacity])};
  }
  class Renderer{
    constructor(video,player){
      this.video=video;this.player=player;
      this.host=document.createElement("div");this.host.id="yt-steady-surface";
      this.host.style.cssText="position:absolute;pointer-events:none;z-index:1;background:#000;overflow:hidden;display:none;";
      // A reduced output must cover the unchanged full-sized source video too.
      this.matte=document.createElement("div");this.matte.id="yt-steady-matte";
      this.matte.style.cssText="position:absolute;pointer-events:none;z-index:1;background:#000;display:none;";
      this.canvas=document.createElement("canvas");this.canvas.id="yt-steady-output";
      this.canvas.style.cssText="position:absolute;pointer-events:none;display:block;";
      this.context=this.canvas.getContext("2d",{alpha:false,desynchronized:true});
      if(!this.context)throw new Error("canvas-context-unavailable");
      this.host.append(this.canvas);this.lastLayout="";this.active=false;this.frame=null;
    }
    sync(zoom){
      const g=surfaceGeometry(this.video,this.player,this.frame,zoom);if(!g)return;
      if(this.matte.parentElement!==g.parent)g.parent.insertBefore(this.matte,this.host.parentElement===g.parent?this.host:null);
      if(this.host.parentElement!==g.parent)g.parent.append(this.host);
      if(g.signature===this.lastLayout)return;this.lastLayout=g.signature;
      Object.assign(this.host.style,g.host);Object.assign(this.canvas.style,g.content,{filter:g.filter,opacity:g.opacity});
      if(zoom<1){const base=surfaceGeometry(this.video,this.player,this.frame,1);Object.assign(this.matte.style,base.host);}
      this.matte.style.display=this.active&&zoom<1?"block":"none";
    }
    draw(frame,motion,settings,time){
      const width=frame.visibleRect.width,height=frame.visibleRect.height;
      if(this.canvas.width!==width||this.canvas.height!==height){this.canvas.width=width;this.canvas.height=height;}
      this.frame={displayWidth:frame.displayWidth,displayHeight:frame.displayHeight};
      this.sync(settings.zoom);
      const ctx=this.context,x=settings.subpixel?motion.mapX:Math.round(motion.mapX),y=settings.subpixel?motion.mapY:Math.round(motion.mapY);
      this.map={x,y};
      ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle="#000";ctx.fillRect(0,0,width,height);
      ctx.imageSmoothingEnabled=!!settings.subpixel;ctx.imageSmoothingQuality="low";
      ctx.drawImage(frame,-x,-y,width,height);
      this.canvas.dataset.frame=JSON.stringify({time,mapX:x,mapY:y,frame:motion.frame,valid:motion.valid});
      this.active=true;this.host.style.display="block";this.matte.style.display=settings.zoom<1?"block":"none";
    }
    hide(){this.host.style.display=this.matte.style.display="none";this.active=false;}
    destroy(){this.host.remove();this.matte.remove();}
  }
  // Drop the orphaned context's native heap after its last in-flight job ends.
  function dispose(){modulePromise=null;owner=null;}
  root.YTSteadyPipeline={coreLoader:"bundled-bytes",createCore,exclusive,dispose,surfaceGeometry,LumaReader,Renderer};
})(globalThis);
