/* Five-second source-coordinate preview. No pixels enter the motion estimator.
 * GPL-2.0-or-later. SVG geometry is independent of the rendered video canvas. */
(function(root){
  "use strict";
  const NS="http://www.w3.org/2000/svg",DURATION=5000,S=root.YTSteadySettings,I=root.YTSteadyI18n;
  // One palette for the settings, native sliders, legend and geometric marks.
  const parameterColors=Object.freeze({centerRatio:"#68cfff",sampleRatio:"#4ee4d0",searchRange:"#ffd268",compensationLimit:"#e2a5ff",zoom:"#f5f7ff"});
  const parameterColor=name=>parameterColors[["mode","centerPriority"].includes(name)?"centerRatio":name]||"#c8dfff";
  function searchArrows(region){
    const x=region.left+region.width/2,y=region.top+region.height/2,dx=region.analysisDx*region.scaleX,dy=region.analysisDy*region.scaleY;
    const head=Math.min(12,region.width/40,region.height/40),hx=Math.min(head,dx/3),hy=Math.min(head,dy/3);
    const horizontal=dx>0?`M${x-dx} ${y}H${x+dx}M${x-dx+hx} ${y-hx}L${x-dx} ${y}L${x-dx+hx} ${y+hx}M${x+dx-hx} ${y-hx}L${x+dx} ${y}L${x+dx-hx} ${y+hx}`:"";
    const vertical=dy>0?`M${x} ${y-dy}V${y+dy}M${x-hy} ${y-dy+hy}L${x} ${y-dy}L${x+hy} ${y-dy+hy}M${x-hy} ${y+dy-hy}L${x} ${y+dy}L${x+hy} ${y+dy-hy}`:"";
    return {x,y,dx,dy,path:horizontal+vertical};
  }
  function compensationBand(width,height,limitX,limitY){
    // Each edge represents one direction of C, independently of the search S.
    // Overlapping opposite bands cover the frame; only the drawing is clipped.
    const x=Math.min(width/2,Math.max(0,limitX)),y=Math.min(height/2,Math.max(0,limitY)),w=width-2*x,h=height-2*y;
    const outer=`M0 0H${width}V${height}H0Z`,inner=w>0&&h>0?`M${x} ${y}H${width-x}V${height-y}H${x}Z`:"";
    return {x,y,width:w,height:h,path:x||y?outer+inner:""};
  }
  const point=(m,p)=>({x:m.a*p.x+m.c*p.y+m.e,y:m.b*p.x+m.d*p.y+m.f});
  function inverse(m){const d=m.a*m.d-m.b*m.c;if(!Number.isFinite(d)||d===0)return null;return {a:m.d/d,b:-m.b/d,c:-m.c/d,d:m.a/d,e:(m.c*m.f-m.d*m.e)/d,f:(m.b*m.e-m.a*m.f)/d};}
  function cropPolygon(width,height,map,matrix,viewport,ratio=1,origin={x:width/2,y:height/2}){
    if(!matrix||!Number.isFinite(ratio)||ratio<=0)return [];
    const t={a:matrix.a*ratio,b:matrix.b*ratio,c:matrix.c*ratio,d:matrix.d*ratio,
      e:matrix.e+(1-ratio)*(matrix.a*origin.x+matrix.c*origin.y),f:matrix.f+(1-ratio)*(matrix.b*origin.x+matrix.d*origin.y)},inv=inverse(t);
    if(!inv)return [];
    let poly=[[viewport.left,viewport.top],[viewport.right,viewport.top],[viewport.right,viewport.bottom],[viewport.left,viewport.bottom]].map(([x,y])=>{const p=point(inv,{x,y});return {x:p.x+map.x,y:p.y+map.y};});
    // Both the source image and the unzoomed output canvas can clip a shifted
    // frame. Keep their intersection; C is not used as a fictitious hard crop.
    const bounds=[Math.max(0,map.x),Math.max(0,map.y),Math.min(width,width+map.x),Math.min(height,height+map.y)];
    for(const [axis,bound,sign]of [["x",bounds[0],1],["x",bounds[2],-1],["y",bounds[1],1],["y",bounds[3],-1]]){
      const result=[];for(let n=0;n<poly.length;n++){const a=poly[n],b=poly[(n+1)%poly.length],insideA=(a[axis]-bound)*sign>=-1e-8,insideB=(b[axis]-bound)*sign>=-1e-8;
        if(insideA)result.push(a);if(insideA!==insideB){const k=(bound-a[axis])/(b[axis]-a[axis]);result.push({x:a.x+k*(b.x-a.x),y:a.y+k*(b.y-a.y)});}}
      poly=result;
    }
    return poly.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y))?poly:[];
  }
  function cellStates(plan,motion,draft){
    return plan.cells.map(c=>({id:c.id,active:plan.regions.some(r=>r.id===c.id),state:!plan.regions.some(r=>r.id===c.id)?"unused":draft?(plan.mode==="adaptive"?"candidate":"planned"):motion?.regions?.inlierIds?.includes(c.id)?"inlier":motion?.regions?.ids?.includes(c.id)?"selected":"candidate"}));
  }
  function svg(name,attrs={},parent){const el=document.createElementNS(NS,name);for(const [key,value]of Object.entries(attrs))el.setAttribute(key,String(value));parent?.append(el);return el;}
  function set(el,attrs){for(const [key,value]of Object.entries(attrs))el.setAttribute(key,String(value));}
  class Overlay{
    constructor(player,video){
      this.player=player;this.video=video;this.visible=false;this.dead=false;this.timers=[];this.state={};this.host=document.createElement("div");this.host.id="yt-steady-preview";
      this.host.style.cssText="position:absolute;pointer-events:none;z-index:60;display:none;transition:opacity 200ms linear;";
      this.shadow=this.host.attachShadow({mode:"open"});
      this.shadow.innerHTML=`<style>:host{pointer-events:none!important}*{box-sizing:border-box}#geometry{position:absolute;inset:0;overflow:hidden}svg{position:absolute;overflow:hidden}rect,path,line,polygon{vector-effect:non-scaling-stroke;filter:drop-shadow(0 0 1px #091522)}.cell{stroke:${parameterColors.centerRatio};stroke-width:1;fill:none}.cell[data-state=candidate]{fill:none}.cell[data-state=planned]{fill:${parameterColors.centerRatio};fill-opacity:.06}.cell[data-state=selected]{fill:${parameterColors.centerRatio};fill-opacity:.10}.cell[data-state=inlier]{fill:#53efab;fill-opacity:.10}.cell[data-state=unused]{stroke-opacity:.35;stroke-dasharray:3 6}.state-marker{fill:#b7c8d9;stroke:#101c29;stroke-width:1;vector-effect:non-scaling-stroke}.state-marker[data-state=unused],.state-marker[data-state=planned]{display:none}.state-marker[data-state=selected]{fill:${parameterColors.centerRatio}}.state-marker[data-state=inlier]{fill:#53efab}.search{stroke:${parameterColors.searchRange};stroke-width:1.5;fill:none}.limit{stroke:${parameterColors.compensationLimit};stroke-width:2;stroke-dasharray:6 4;fill:${parameterColors.compensationLimit};fill-opacity:.18}.draft .limit{fill-opacity:.10;stroke-dasharray:3 5}.crop{stroke:${parameterColors.zoom};stroke-width:2;fill:none}.sample{fill:${parameterColors.sampleRatio};stroke:#101c29;stroke-width:3px;paint-order:stroke;font-family:system-ui,sans-serif}.motion{stroke:${parameterColors.compensationLimit};stroke-width:2;fill:none}#legend{position:absolute;inset-block-start:10px;inset-inline-start:10px;max-inline-size:calc(100% - 20px);font:12px/1.5 system-ui,sans-serif;color:#f1f6ff;background:#101c29df;border:1px solid #9ab0ca88;border-radius:7px;padding:6px 9px;white-space:pre-line;box-shadow:0 2px 8px #0005}#detail{color:#d5e3f4;font-size:11px}.draft .cell:not([data-state=unused]),.draft .search,.draft .crop{stroke-dasharray:6 4}</style><div id="geometry"></div><div id="legend"><div id="phase"></div><div id="values"></div><div id="detail"></div></div>`;
      this.geometry=this.shadow.getElementById("geometry");this.phase=this.shadow.getElementById("phase");this.values=this.shadow.getElementById("values");this.detail=this.shadow.getElementById("detail");
      this.canvas=svg("svg",{"aria-hidden":"true",focusable:"false",preserveAspectRatio:"none"},this.geometry);
    }
    show(profile,{draft=false,focus="all",state={}}={}){
      if(this.dead||!profile)return false;
      const size=state.size||{width:this.video.videoWidth,height:this.video.videoHeight};let plan;
      try{plan=S.plan(profile,size.width,size.height);}catch{return false;}
      for(const timer of this.timers)clearTimeout(timer);this.timers=[];
      this.profile={...profile};this.plan=plan;this.requestedDraft=draft;this.focus=focus;this.state=state;this.deadline=performance.now()+DURATION;this.visible=true;
      this.host.style.display="block";this.host.style.opacity="1";this.host.dataset.visible="true";this.build();this.update(state);
      this.timers.push(setTimeout(()=>{if(this.visible)this.host.style.opacity="0";},DURATION-200),setTimeout(()=>this.hide(),DURATION));return true;
    }
    build(){
      const p=this.plan;this.canvas.replaceChildren();set(this.canvas,{viewBox:`0 0 ${p.sourceWidth} ${p.sourceHeight}`});
      this.source=svg("g",{},this.canvas);this.cells=new Map();this.markers=new Map();this.searches=[];this.searchRanges=[];this.sampleLabels=[];
      const geometryFocus=["all","mode","centerRatio","centerPriority"].includes(this.focus),searchFocus=["all","searchRange"].includes(this.focus);
      for(const c of p.cells){if(c.width<=0||c.height<=0)continue;
        const rect=svg("rect",{class:"cell",x:c.left,y:c.top,width:c.width,height:c.height,"data-id":c.id,opacity:geometryFocus?1:.4},this.source);rect.style.strokeWidth=geometryFocus?(c.id===p.centerId?"3":"2"):"1";this.cells.set(c.id,rect);
        const radius=Math.min(c.width/8,c.height/8,p.sourceWidth/280);
        this.markers.set(c.id,svg("circle",{class:"state-marker","data-id":c.id,cx:c.left+radius*2.2,cy:c.top+radius*2.2,r:radius},this.source));
      }
      for(const r of p.regions){
        const a=searchArrows(r),{x,y}=a;this.searchRanges.push({id:r.id,x,y,dx:a.dx,dy:a.dy});
        this.searches.push(svg("path",{class:"search","data-id":r.id,d:a.path,opacity:searchFocus?1:.22},this.source));
        svg("circle",{class:"search-origin",cx:x,cy:y,r:Math.max(1,Math.min(4,r.width/100,r.height/100)),fill:parameterColors.searchRange,opacity:searchFocus?1:.25},this.source);
        if(this.focus==="sampleRatio"){
          const label=svg("text",{class:"sample",x,y,"text-anchor":"middle","dominant-baseline":"middle"},this.source);label.textContent=`Q ${I.input(this.profile.sampleRatio)}% · ${r.analysisWidth}×${r.analysisHeight}`;this.sampleLabels.push({label,region:r});
        }
      }
      this.cropMask=svg("path",{fill:"#060b13","fill-opacity":this.focus==="zoom"?.28:.035,"fill-rule":"evenodd"},this.source);
      this.crop=svg("polygon",{class:"crop",opacity:["all","zoom"].includes(this.focus)?1:.28},this.source);
      this.band=compensationBand(p.sourceWidth,p.sourceHeight,p.limitX,p.limitY);
      this.limit=svg("path",{class:"limit",d:this.band.path,"fill-rule":"evenodd",opacity:["all","compensationLimit"].includes(this.focus)?1:.22},this.canvas);
      this.arrow=svg("path",{class:"motion"},this.canvas);this.legendKey="";
    }
    layout(state=this.state){
      if(!this.visible||this.dead)return;
      this.state=state;
      const appliedZoom=state.active?(state.settings?.zoom||1):1,g=root.YTSteadyPipeline.surfaceGeometry(this.video,this.player,state.frame,appliedZoom);if(!g){this.hide();return;}
      if(this.host.parentElement!==g.parent)g.parent.append(this.host);
      Object.assign(this.host.style,{left:g.host.left,top:g.host.top,width:g.host.width,height:g.host.height});
      Object.assign(this.geometry.style,{transform:g.host.transform,transformOrigin:g.host.transformOrigin,translate:g.host.translate,rotate:g.host.rotate,scale:g.host.scale,borderRadius:g.host.borderRadius});
      Object.assign(this.canvas.style,g.content);this.geometryInfo=g;this.appliedZoom=appliedZoom;
      for(const {label,region}of this.sampleLabels){label.style.fontSize=(11*this.plan.sourceWidth/g.cw/appliedZoom)+"px";label.style.display=region.width/this.plan.sourceWidth*g.cw*appliedZoom>=130?"":"none";}
      this.geometry.dataset.focus=this.focus;
    }
    update(state=this.state){
      if(!this.visible||this.dead)return;if(performance.now()>=this.deadline){this.hide();return;}
      this.state=state;const size=state.size||{width:this.video.videoWidth,height:this.video.videoHeight};
      if(size.width!==this.plan.sourceWidth||size.height!==this.plan.sourceHeight){try{this.plan=S.plan(this.profile,size.width,size.height);this.build();}catch{this.hide();return;}}
      this.layout(state);if(!this.visible)return;
      const p=this.plan,draft=this.requestedDraft||!state.active,map={x:state.active?(state.motion?.mapX||0):0,y:state.active?(state.motion?.mapY||0):0};
      this.host.dataset.phase=draft?"preview":"applied";this.geometry.classList.toggle("draft",draft);set(this.source,{transform:`translate(${-map.x} ${-map.y})`});
      for(const c of cellStates(p,state.motion,draft)){const el=this.cells.get(c.id),marker=this.markers.get(c.id);if(el){el.dataset.state=c.state;if(c.active&&this.profile.centerPriority&&c.id===p.centerId)el.style.strokeWidth="3";}if(marker)marker.dataset.state=c.state;}
      const matrix=this.canvas.getScreenCTM(),g=this.geometryInfo,originPx=getComputedStyle(this.geometry).transformOrigin.split(" ").map(Number.parseFloat),origin={x:(originPx[0]-(g.w-g.cw)/2)/g.cw*p.sourceWidth,y:(originPx[1]-(g.h-g.ch)/2)/g.ch*p.sourceHeight};
      const crop=cropPolygon(p.sourceWidth,p.sourceHeight,map,matrix,this.player.getBoundingClientRect(),this.profile.zoom/this.appliedZoom,origin);
      set(this.crop,{points:crop.map(v=>`${v.x},${v.y}`).join(" ")});this.crop.style.display=crop.length>=3?"":"none";
      const ring=`M0 0H${p.sourceWidth}V${p.sourceHeight}H0Z`,inside=crop.length>=3?`M${crop.map(v=>`${v.x} ${v.y}`).join("L")}Z`:"";
      this.cropMask.setAttribute("d",inside?ring+inside:"");
      const cx=p.sourceWidth/2,cy=p.sourceHeight/2,tx=cx-map.x,ty=cy-map.y;
      const angle=Math.atan2(ty-cy,tx-cx),head=6*p.sourceWidth/g.cw/this.appliedZoom;
      const tip=Math.hypot(map.x,map.y)>1?`M${tx-head*Math.cos(angle-.5)} ${ty-head*Math.sin(angle-.5)}L${tx} ${ty}L${tx-head*Math.cos(angle+.5)} ${ty-head*Math.sin(angle+.5)}`:"";
      this.arrow.setAttribute("d",`M${cx-5} ${cy}h10M${cx} ${cy-5}v10M${cx} ${cy}L${tx} ${ty}${tip}`);this.arrow.style.display=draft?"none":"";
      const phase=I.t(this.requestedDraft?"overlayDraft":state.active?"overlayApplied":"showRegions"),name=this.focus==="all"?"":I.t(this.focus==="mode"?"analysisMode":this.focus);
      this.host.lang=I.tag;this.host.dir=I.dir;
      const ratio=p.windowLayout==="grid"?I.input(this.profile.centerRatio)+"%":"—",q=this.profile.samplingMode==="relative"?I.input(this.profile.sampleRatio)+"%":"—";
      const search=I.number(p.requestedSearch,2)+"%",effective=I.number(p.effectiveSearchMin,2)+"–"+I.number(p.effectiveSearchMax,2),example=this.searchRanges.find(r=>r.id===p.centerId)||this.searchRanges[0],exampleId=example.id+1,limit=I.number(p.limitX/p.sourceWidth*100,2)+(Math.abs(p.limitX/p.sourceWidth-p.limitY/p.sourceHeight)<1e-7?"%":"% / "+I.number(p.limitY/p.sourceHeight*100,2)+"%");
      const legendKey=JSON.stringify([I.tag,phase,name,ratio,q,search,limit,this.profile.zoom,p.searchLimited]);
      if(legendKey!==this.legendKey){
        this.legendKey=legendKey;this.phase.textContent=phase;
        if(name){const label=document.createElement("span");label.dataset.focus=this.focus;label.style.color=parameterColor(this.focus);label.style.fontWeight="700";label.textContent=" · "+name;this.phase.append(label);}
        this.shadow.getElementById("legend").style.borderColor=this.focus==="all"?"#9ab0ca88":parameterColor(this.focus);
        this.values.replaceChildren();
        for(const [key,text]of [["centerRatio",`R ${ratio}`],["sampleRatio",`Q ${q}`],["searchRange",`S ±${search}`],["compensationLimit",`C ±${limit}`],["zoom",`×${I.number(this.profile.zoom,2)}`]]){
          if(this.values.childNodes.length)this.values.append(document.createTextNode(" · "));
          const label=document.createElement("bdi");label.dataset.parameter=key;label.style.color=parameterColors[key];label.textContent=text;this.values.append(label);
        }
        this.detail.textContent=(this.focus==="searchRange"?I.t("searchArrowHint",{region:I.number(exampleId),x:I.number(example.dx,1),y:I.number(example.dy,1)}):I.t("overlayStates")+"\n"+I.t("overlayGuides")+(["all","compensationLimit"].includes(this.focus)?"\n"+I.t("compensationBandHint"):""))+(p.searchLimited?"\n"+I.t("searchLimited",{requested:I.number(p.requestedSearch,2),effective}):"");
      }
      this.host.dataset.geometry=JSON.stringify({source:[p.sourceWidth,p.sourceHeight],map,draft,focus:this.focus,regions:p.regions.map(r=>r.id),selected:draft?[]:state.motion?.regions?.ids||[],inliers:draft?[]:state.motion?.regions?.inlierIds||[],crop,search:p.requestedSearch,searchEffective:[p.effectiveSearchMin,p.effectiveSearchMax],searchRanges:this.searchRanges,limit:[p.limitX,p.limitY],band:this.band});
    }
    hide(){for(const timer of this.timers)clearTimeout(timer);this.timers=[];this.visible=false;this.host.style.display="none";this.host.style.opacity="0";this.host.dataset.visible="false";}
    destroy(){if(this.dead)return;this.hide();this.dead=true;this.host.remove();}
  }
  root.YTSteadyOverlay=Overlay;root.YTSteadyOverlayGeometry={cropPolygon,compensationBand,searchArrows,cellStates,DURATION,parameterColors,parameterColor};
  if(typeof module!=="undefined"&&module.exports)module.exports={cropPolygon,compensationBand,searchArrows,cellStates,DURATION,parameterColors,parameterColor,Overlay};
})(globalThis);
