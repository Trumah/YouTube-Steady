/* Block motion interpolation on WebGPU. GPL-2.0-or-later. */
(function(root){
  "use strict";
  const rgbFormats=new Set(["RGBA","RGBX","BGRA","BGRX"]);
  const shader=/* wgsl */`
struct Parameters {
  size: vec2<u32>,
  grid: vec2<u32>,
  previousMap: vec2<f32>,
  currentMap: vec2<f32>,
  fraction: f32,
};
@group(0) @binding(0) var previous: texture_external;
@group(0) @binding(1) var current: texture_external;
@group(0) @binding(2) var videoSampler: sampler;
@group(0) @binding(3) var<uniform> params: Parameters;
@group(0) @binding(4) var<storage, read_write> samples: array<vec2<f32>>;
@group(0) @binding(5) var<storage, read_write> vectors: array<vec4<f32>>;
@group(0) @binding(6) var<storage, read> flow: array<vec4<f32>>;
@group(0) @binding(7) var<storage, read_write> reduction: array<vec4<f32>>;
@group(0) @binding(8) var<storage, read> scene: array<vec4<f32>>;
@group(0) @binding(9) var<storage, read_write> checkedMotion: array<vec2<f32>>;
@group(0) @binding(10) var<storage, read> motion: array<vec2<f32>>;

fn inside(uv: vec2<f32>) -> bool {
  return all(uv >= vec2<f32>(0)) && all(uv <= vec2<f32>(1));
}
fn readPrevious(uv: vec2<f32>) -> vec3<f32> {
  return select(vec3<f32>(0),textureSampleBaseClampToEdge(previous,videoSampler,uv).rgb,inside(uv));
}
fn readCurrent(uv: vec2<f32>) -> vec3<f32> {
  return select(vec3<f32>(0),textureSampleBaseClampToEdge(current,videoSampler,uv).rgb,inside(uv));
}
@compute @workgroup_size(16,8) fn downsample(@builtin(global_invocation_id) id: vec3<u32>) {
  let size=(params.size+vec2<u32>(3))/4;
  if (any(id.xy >= size)) { return; }
  let weights=vec3<f32>(0.2126,0.7152,0.0722);
  let position=min(vec2<f32>(id.xy)*4+2,vec2<f32>(params.size)-1);
  var a=0.0;
  var b=0.0;
  for (var i=0; i<4; i++) {
    let offset=vec2<f32>(f32(i%2)*2-1,f32(i/2)*2-1);
    a+=dot(readPrevious((position+offset+params.previousMap)/vec2<f32>(params.size)),weights);
    b+=dot(readCurrent((position+offset+params.currentMap)/vec2<f32>(params.size)),weights);
  }
  samples[id.y*size.x+id.x]=vec2<f32>(a,b)*0.25;
}
fn pairAt(position: vec2<i32>, displacement: vec2<i32>, backward: bool) -> vec2<f32> {
  let size=(params.size+vec2<u32>(3))/4;
  let last=vec2<i32>(size)-1;
  let a=vec2<u32>(clamp(position,vec2<i32>(0),last));
  let b=vec2<u32>(clamp(position+displacement,vec2<i32>(0),last));
  let first=samples[a.y*size.x+a.x];
  let lastSample=samples[b.y*size.x+b.x];
  return select(vec2<f32>(first.x,lastSample.y),vec2<f32>(first.y,lastSample.x),backward);
}
fn errorAt(center: vec2<i32>, displacement: vec2<i32>, backward: bool, stride: i32) -> f32 {
  var error=0.0;
  for (var y=-3; y<=3; y+=stride) {
    for (var x=-3; x<=3; x+=stride) {
      let pair=pairAt(center+vec2<i32>(x,y),displacement,backward);
      error+=abs(pair.x-pair.y);
    }
  }
  return error;
}
var<workgroup> costs: array<f32,64>;
var<workgroup> offsets: array<vec2<i32>,64>;
var<workgroup> coarse: vec2<i32>;
@compute @workgroup_size(64) fn matchBlocks(@builtin(workgroup_id) group: vec3<u32>,@builtin(local_invocation_index) lane: u32) {
  let backward=group.z==1;
  let center=vec2<i32>(group.xy)*4+2;
  let candidate=vec2<i32>(i32(lane%8)-4,i32(lane/8)-4)*2;
  costs[lane]=errorAt(center,candidate,backward,2)+f32(candidate.x*candidate.x+candidate.y*candidate.y)*0.001;
  offsets[lane]=candidate;
  workgroupBarrier();
  if (lane==0) {
    var best=36u;
    for (var i=0u; i<64u; i++) { if (costs[i]<costs[best]) { best=i; } }
    coarse=offsets[best];
  }
  workgroupBarrier();
  if (lane<25) {
    let delta=coarse+vec2<i32>(i32(lane%5)-2,i32(lane/5)-2);
    offsets[lane]=delta;
    costs[lane]=errorAt(center,delta,backward,1)+f32(delta.x*delta.x+delta.y*delta.y)*0.002;
  }
  workgroupBarrier();
  if (lane==0) {
    var best=12u;
    for (var i=0u; i<25u; i++) { if (costs[i]<costs[best]) { best=i; } }
    let delta=offsets[best];
    let base=errorAt(center,delta,backward,1);
    let stationary=errorAt(center,vec2<i32>(0),backward,1);
    let left=errorAt(center,delta-vec2<i32>(1,0),backward,1);
    let right=errorAt(center,delta+vec2<i32>(1,0),backward,1);
    let top=errorAt(center,delta-vec2<i32>(0,1),backward,1);
    let bottom=errorAt(center,delta+vec2<i32>(0,1),backward,1);
    let fine=clamp(0.5*vec2<f32>(left-right,top-bottom)/max(vec2<f32>(0.01),vec2<f32>(left+right,top+bottom)-2*base),vec2<f32>(-0.5),vec2<f32>(0.5));
    let index=(group.z*params.grid.y+group.y)*params.grid.x+group.x;
    vectors[index]=vec4<f32>((vec2<f32>(delta)+fine)*4,stationary/49,base/49);
  }
}
fn vectorAt(position: vec2<f32>, backward: bool) -> vec4<f32> {
  let cell=vec2<u32>(clamp(floor(position/16),vec2<f32>(0),vec2<f32>(params.grid)-1));
  let layer=select(0u,params.grid.y,backward);
  return flow[(layer+cell.y)*params.grid.x+cell.x];
}
fn unreliable(v: vec4<f32>, reverse: vec4<f32>) -> bool {
  let speed=max(length(v.xy),length(reverse.xy));
  let inconsistent=length(v.xy+reverse.xy)>2.5+0.15*speed;
  return speed>34 || max(v.w,reverse.w)>0.075 ||
    (max(v.z,reverse.z)>0.022 && inconsistent);
}
fn checkedDisplacement(point: vec2<f32>, backward: vec4<f32>, reverse: vec4<f32>) -> vec2<f32> {
  if (unreliable(backward,reverse)) { return vec2<f32>(0); }
  let shift=backward.xy;
  let speed=length(shift);
  let change=max(
    max(length(shift-vectorAt(point+vec2<f32>(16,0),true).xy),length(shift-vectorAt(point-vec2<f32>(16,0),true).xy)),
    max(length(shift-vectorAt(point+vec2<f32>(0,16),true).xy),length(shift-vectorAt(point-vec2<f32>(0,16),true).xy)));
  let agreement=1-smoothstep(4+0.10*speed,11+0.2*speed,change);
  let accurate=1-smoothstep(0.045,0.075,max(backward.w,reverse.w));
  return shift*agreement*accurate;
}
var<workgroup> errorSum: array<f32,64>;
var<workgroup> badSum: array<f32,64>;
@compute @workgroup_size(64) fn checkFrame(@builtin(local_invocation_index) lane: u32) {
  var error=0.0;
  var bad=0.0;
  let count=params.grid.x*params.grid.y;
  for (var i=lane; i<count; i+=64) {
    let point=vec2<f32>(f32(i%params.grid.x),f32(i/params.grid.x))*16+8;
    let f=flow[i];
    let b=flow[count+i];
    let reverse=vectorAt(point+b.xy,false);
    error+=max(f.w,b.w);
    let risky=unreliable(f,vectorAt(point+f.xy,true)) || unreliable(b,reverse);
    bad+=select(0.0,1.0,risky);
    checkedMotion[i]=checkedDisplacement(point,b,reverse);
  }
  errorSum[lane]=error;
  badSum[lane]=bad;
  workgroupBarrier();
  if (lane==0) {
    var mean=0.0;
    var fraction=0.0;
    for (var i=0u; i<64; i++) { mean+=errorSum[i]; fraction+=badSum[i]; }
    let residual=mean/f32(count);
    let riskyArea=fraction/f32(count);
    // A local occlusion is handled in the draw pass. Reject the whole frame
    // when the motion model is unreliable across a broad part of the image.
    let useOriginal=residual>0.075 || riskyArea>0.50;
    reduction[0]=vec4<f32>(select(0.0,1.0,useOriginal),riskyArea,residual,0);
  }
}
fn displacementAt(point: vec2<f32>) -> vec2<f32> {
  let cell=clamp((point-8)/16,vec2<f32>(0),vec2<f32>(params.grid)-1);
  let a=vec2<u32>(cell);
  let b=min(a+vec2<u32>(1),params.grid-vec2<u32>(1));
  let f=fract(cell);
  let top=mix(motion[a.y*params.grid.x+a.x],motion[a.y*params.grid.x+b.x],f.x);
  let bottom=mix(motion[b.y*params.grid.x+a.x],motion[b.y*params.grid.x+b.x],f.x);
  return mix(top,bottom,f.y);
}
@vertex fn vertex(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> {
  let p=array<vec2<f32>,3>(vec2<f32>(-1,-1),vec2<f32>(3,-1),vec2<f32>(-1,3));
  return vec4<f32>(p[i],0,1);
}
@fragment fn draw(@builtin(position) pixel: vec4<f32>) -> @location(0) vec4<f32> {
  // Read only the later stabilized frame. A smooth displacement field
  // avoids blending two outlines or switching images across block edges.
  var point=pixel.xy;
  if (scene[0].x<0.5) { point-=(1-params.fraction)*displacementAt(point); }
  let uv=(point+params.currentMap)/vec2<f32>(params.size);
  return vec4<f32>(select(vec3<f32>(0),textureSampleBaseClampToEdge(current,videoSampler,uv).rgb,inside(uv)),1);
}
`;
  class Interpolator{
    static async create(canvas,measure=false){
      const adapter=await root.navigator?.gpu?.requestAdapter();
      const info=adapter?.info;
      if(!adapter||(info?.isFallbackAdapter??adapter.isFallbackAdapter))throw Error("webgpu-hardware-unavailable");
      const timing=measure&&adapter.features.has("timestamp-query");
      const device=await adapter.requestDevice({requiredFeatures:timing?["timestamp-query"]:[]});
      try{
        const module=device.createShaderModule({code:shader});
        if(measure){
          const {messages}=await module.getCompilationInfo();
          const errors=messages.filter(message=>message.type==="error");
          if(errors.length)throw Error(errors.map(message=>message.lineNum+": "+message.message).join("\n"));
        }
        const compute=entryPoint=>device.createComputePipelineAsync({layout:"auto",compute:{module,entryPoint}});
        const format=root.navigator.gpu.getPreferredCanvasFormat();
        const pipelines=await Promise.all([compute("downsample"),compute("matchBlocks"),compute("checkFrame"),
          device.createRenderPipelineAsync({layout:"auto",vertex:{module,entryPoint:"vertex"},fragment:{module,entryPoint:"draw",targets:[{format}]}})]);
        const context=canvas.getContext("webgpu");
        if(!context)throw Error("webgpu-context-unavailable");
        context.configure({device,format,alphaMode:"opaque"});
        return new Interpolator(canvas,device,context,pipelines,info,timing);
      }catch(error){device.destroy();throw error;}
    }
    constructor(canvas,device,context,pipelines,info,timing){
      this.canvas=canvas;this.device=device;this.context=context;this.pipelines=pipelines;
      this.info=info;this.lost=false;this.destroyed=false;this.width=0;this.height=0;this.inFlight=0;
      this.rgbFrames=new Map();
      const buffer=(size,usage)=>device.createBuffer({size,usage});
      this.parameters=buffer(48,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST);
      this.scene=buffer(16,GPUBufferUsage.STORAGE|(timing?GPUBufferUsage.COPY_SRC:0));
      this.samplers=["nearest","linear"].map(mode=>device.createSampler({magFilter:mode,minFilter:mode}));
      this.ms=[];
      if(timing){
        this.decisions=[];
        this.queries=device.createQuerySet({type:"timestamp",count:8});
        this.results=buffer(64,GPUBufferUsage.QUERY_RESOLVE|GPUBufferUsage.COPY_SRC);
        this.readback=buffer(80,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST);
      }
      device.lost.then(()=>this.fail());
      device.addEventListener("uncapturederror",()=>this.fail());
    }
    fail(){
      if(this.destroyed||this.lost)return;
      this.lost=true;
      this.onFailure?.();
    }
    rgbFrame(frame){
      if(rgbFormats.has(frame.format))return frame;
      const cached=this.rgbFrames.get(frame);
      if(cached)return cached;
      // Convert both color planes together before WebGPU can import the decoder's
      // surface. Some NV12 surfaces otherwise show a shifted chroma plane.
      const canvas=this.rgbCanvas??=this.canvas.ownerDocument.createElement("canvas");
      const {width,height}=frame.visibleRect;
      if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height;}
      const context=this.rgbContext??=canvas.getContext("2d",{alpha:false});
      if(!context||context.isContextLost?.())throw Error("interpolation-color-conversion-unavailable");
      context.globalCompositeOperation="copy";
      context.drawImage(frame,0,0,width,height);
      const rgb=new VideoFrame(canvas,{timestamp:frame.timestamp});
      this.rgbFrames.set(frame,rgb);
      return rgb;
    }
    resetFrames(){
      for(const frame of this.rgbFrames.values())frame.close();
      this.rgbFrames.clear();
    }
    draw(previous,current,fraction,linear=true){
      if(this.lost||this.destroyed)throw Error("webgpu-device-lost");
      // Keep slow or shared GPUs from building up a presentation queue.
      if(this.inFlight>=2)return false;
      const {device,canvas}=this;
      const width=current.frame.visibleRect.width,height=current.frame.visibleRect.height;
      const sampleWidth=Math.ceil(width/4),sampleHeight=Math.ceil(height/4),columns=Math.ceil(width/16),rows=Math.ceil(height/16);
      if(this.width!==width||this.height!==height){
        this.width=canvas.width=width;this.height=canvas.height=height;
        this.samples?.destroy();this.flow?.destroy();this.motion?.destroy();
        this.samples=device.createBuffer({size:sampleWidth*sampleHeight*8,usage:GPUBufferUsage.STORAGE});
        this.flow=device.createBuffer({size:columns*rows*32,usage:GPUBufferUsage.STORAGE});
        this.motion=device.createBuffer({size:columns*rows*8,usage:GPUBufferUsage.STORAGE});
      }
      const parameters=new ArrayBuffer(48);
      new Uint32Array(parameters,0,4).set([width,height,columns,rows]);
      new Float32Array(parameters,16,5).set([previous.x,previous.y,current.x,current.y,fraction]);
      device.queue.writeBuffer(this.parameters,0,parameters);
      for(const [source,rgb] of this.rgbFrames){
        if(source!==previous.frame&&source!==current.frame){rgb.close();this.rgbFrames.delete(source);}
      }
      const a=device.importExternalTexture({source:this.rgbFrame(previous.frame)}),b=device.importExternalTexture({source:this.rgbFrame(current.frame)});
      const p={buffer:this.parameters},samples={buffer:this.samples},flow={buffer:this.flow},scene={buffer:this.scene},motion={buffer:this.motion};
      const bind=(pipeline,entries)=>device.createBindGroup({layout:pipeline.getBindGroupLayout(0),entries:entries.map(([binding,resource])=>({binding,resource}))});
      const measure=this.queries&&!this.reading;
      const timestamps=index=>measure?{timestampWrites:{querySet:this.queries,beginningOfPassWriteIndex:2*index,endOfPassWriteIndex:2*index+1}}:{};
      const command=device.createCommandEncoder();
      const run=(index,entries,x,y=1,z=1)=>{
        const pipeline=this.pipelines[index],pass=command.beginComputePass(timestamps(index));
        pass.setPipeline(pipeline);pass.setBindGroup(0,bind(pipeline,entries));pass.dispatchWorkgroups(x,y,z);pass.end();
      };
      run(0,[[0,a],[1,b],[2,this.samplers[1]],[3,p],[4,samples]],Math.ceil(sampleWidth/16),Math.ceil(sampleHeight/8));
      run(1,[[3,p],[4,samples],[5,flow]],columns,rows,2);
      run(2,[[3,p],[6,flow],[7,scene],[9,motion]],1);
      const pipeline=this.pipelines[3],pass=command.beginRenderPass({colorAttachments:[{view:this.context.getCurrentTexture().createView(),loadOp:"clear",storeOp:"store",clearValue:[0,0,0,1]}],...timestamps(3)});
      pass.setPipeline(pipeline);pass.setBindGroup(0,bind(pipeline,[[1,b],[2,this.samplers[+linear]],[3,p],[8,scene],[10,motion]]));pass.draw(3);pass.end();
      if(measure){
        command.resolveQuerySet(this.queries,0,8,this.results,0);command.copyBufferToBuffer(this.results,0,this.readback,0,64);
        command.copyBufferToBuffer(this.scene,0,this.readback,64,16);
      }
      device.queue.submit([command.finish()]);
      this.inFlight++;
      const complete=()=>{this.inFlight--;};
      device.queue.onSubmittedWorkDone().then(complete,()=>{complete();this.fail();});
      if(measure){
        this.reading=true;
        this.readback.mapAsync(GPUMapMode.READ).then(()=>{
          const mapped=this.readback.getMappedRange(),data=new BigUint64Array(mapped,0,8);
          const sum=Number((data[1]-data[0])+(data[3]-data[2])+(data[5]-data[4])+(data[7]-data[6]))/1e6;
          const [useOriginal,riskyArea,residual]=new Float32Array(mapped,64,4);
          this.decisions.push({time:current.time,fraction,useOriginal:!!useOriginal,riskyArea,residual});
          if(this.decisions.length>1200)this.decisions.shift();
          this.ms.push(sum);if(this.ms.length>1200)this.ms.shift();this.readback.unmap();
        }).catch(()=>{}).finally(()=>{this.reading=false;});
      }
      return true;
    }
    destroy(){
      if(this.destroyed)return;
      this.destroyed=true;
      this.resetFrames();
      this.rgbContext=this.rgbCanvas=null;
      this.context.unconfigure();
      this.device.destroy();
    }
  }
  root.YTSteadyInterpolation=Interpolator;
})(globalThis);
