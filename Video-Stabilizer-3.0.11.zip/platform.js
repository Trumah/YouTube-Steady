/* Browser boundaries only. The motion core and saved profiles are shared.
 * GPL-2.0-or-later. No page-world injection or remote executable code. */
(function(root){
  "use strict";
  function browserAPI(scope=root){
    // Firefox/Safari expose promises through browser.*. Chrome 120+ also
    // supports promises for every chrome.* API used by this extension.
    for(const name of ["browser","chrome"]){
      try{const api=scope[name];if(api?.storage?.local&&api?.runtime?.id)return api;}catch{}
    }
    return null;
  }
  function watchIdentity(location){
    return ["www.youtube.com","m.youtube.com"].includes(location.hostname)&&location.pathname==="/watch"?new URLSearchParams(location.search).get("v"):null;
  }
  function findPlayer(document,location,testPage=false){
    if(!testPage&&!watchIdentity(location))return null;
    // Both current desktop and mobile YouTube use movie_player. Keep the
    // search inside the main player: never attach to previews or Shorts.
    const player=document.querySelector(testPage?"[data-ytsteady-test-player]":"#movie_player");
    const video=player?.querySelector("video.html5-main-video,video");
    return player&&video?{player,video}:null;
  }
  function originalPresentation(video,document){
    return !!(video.webkitDisplayingFullscreen||video.webkitPresentationMode==="fullscreen"||video.webkitPresentationMode==="picture-in-picture"||
      document.pictureInPictureElement===video||document.fullscreenElement===video||document.webkitFullscreenElement===video||
      video.remote?.state==="connected"||video.webkitCurrentPlaybackTargetIsWireless);
  }
  class FrameClock{
    constructor(){this.mode="native";}
    time(timestamp,metadata,still=false){
      const mediaTime=metadata.mediaTime;
      // Some Gecko builds construct VideoFrame(video).timestamp from whole
      // seconds rather than microseconds. Detect the unit error from a real
      // compositor callback; never replace a valid Chromium frame timestamp
      // with a potentially late callback or a free-running wall clock.
      if(this.mode==="native"&&!metadata.fallback&&!still&&Number.isFinite(mediaTime)&&mediaTime>=.25&&
        Math.abs(timestamp-mediaTime)<1.1&&Math.abs(timestamp/1e6-mediaTime)>.2)this.mode="callback";
      if(this.mode==="callback"&&!metadata.fallback&&!still&&Number.isFinite(mediaTime)&&
        Math.abs(timestamp/1e6-mediaTime)<.2&&Math.abs(timestamp-mediaTime)>1.1)this.mode="native";
      if(this.mode==="native")return timestamp;
      // Without native frame identity, a watchdog cannot distinguish repeated
      // captures. Use each video callback once; paused redraws use its supplied
      // media position and are already guarded by the controller's still job.
      if(metadata.fallback||!Number.isFinite(mediaTime))return null;
      return Math.round(mediaTime*1e6);
    }
  }
  class SourceCadence{
    constructor(){this.reset();}
    reset(){this.fps=0;this.suspend();}
    suspend(){this.counters=[];this.intervals=[];}
    observe(interval,hasCounters){
      if(!(interval>0&&interval<=.25))return;
      this.intervals.push(interval);if(this.intervals.length>60)this.intervals.shift();
      // Without playback counters, wait for a consistent run of media times.
      if(!hasCounters&&this.intervals.length>=12){
        const rate=12/this.intervals.slice(-12).reduce((sum,dt)=>sum+dt,0);
        if(rate<=250&&this.intervals.slice(-12).every(dt=>Math.abs(dt*rate-1)<.05))this.fps=Math.round(rate*100)/100;
      }
    }
    sample(time,total){
      if(!Number.isFinite(time)||!Number.isFinite(total))return;
      const previous=this.counters.at(-1);
      if(previous&&(time<=previous.time||time-previous.time>12||total<previous.total))this.suspend();
      this.counters.push({time,total});if(this.counters.length>4)this.counters.shift();
      const first=this.counters[0],span=time-first.time,frames=total-first.total;
      if(span<.3||frames<8)return;
      const rate=frames/span;if(rate<1||rate>250)return;
      // Total includes frames dropped by the browser. Media timestamps let
      // us refine that counter estimate even if callbacks skip source frames.
      let matched=0,elapsed=0,steps=0;
      for(const interval of this.intervals){
        const count=Math.round(interval*rate);
        if(count<1||Math.abs(count-interval*rate)>.15)continue;
        matched++;elapsed+=interval;steps+=count;
      }
      if(matched>=8&&matched>=this.intervals.length*.8){
        this.fps=Math.round(100*steps/elapsed)/100;
      }else this.fps=Math.round(10*rate)/10;
    }
  }
  class OutputCadence{
    constructor(){this.reset();}
    reset(){this.intervals=[];this.refreshMs=0;this.resetSlots();}
    resetSlots(){this.lastTick=null;this.nextSlot=null;this.slotTime=null;this.mediaAnchor=null;}
    get refreshHz(){return this.refreshMs?1000/this.refreshMs:0;}
    period(fps){
      const requested=1000/fps;if(!this.refreshMs)return requested;
      const aligned=Math.round(requested/this.refreshMs)*this.refreshMs;
      return Math.abs(aligned-requested)<=requested*.005?aligned:requested;
    }
    canAnalyze(now,workMs){
      // Leave time for capture and analysis without holding a frame for a
      // full output interval when the selected rate is low.
      const refresh=this.refreshMs||1000/60;
      const lead=Math.max(1000/30,2*refresh,workMs+refresh);
      return this.nextSlot===null||now+lead>=this.nextSlot;
    }
    observe(now){
      const interval=now-this.lastTick;
      if(this.lastTick!==null&&interval>0&&interval<=100){
        this.intervals.push(interval);if(this.intervals.length>9)this.intervals.shift();
        if(this.intervals.length>=5){const sorted=this.intervals.slice().sort((a,b)=>a-b);this.refreshMs=sorted[sorted.length>>1];}
      }
      this.lastTick=now;
    }
    due(now,fps){
      this.observe(now);
      // Lock near-integer rates to the display, e.g. 30 fps on 59.94 Hz.
      // Otherwise choose the nearest refresh and carry the fractional phase.
      const period=this.period(fps),tolerance=Math.max(.01,this.refreshMs*.45);
      if(this.nextSlot!==null&&now+tolerance<this.nextSlot)return false;
      this.slotTime=this.nextSlot===null||period<=this.refreshMs?now:
        this.nextSlot+Math.floor((now+tolerance-this.nextSlot)/period)*period;
      this.nextSlot=this.slotTime+period;
      return true;
    }
    mediaTarget(time,playbackRate,maxOffset){
      const anchor=this.mediaAnchor;
      if(anchor){
        const target=anchor.time+(this.slotTime-anchor.slot)*playbackRate/1000;
        if(Math.abs(target-time)<=maxOffset)return target;
      }
      // Re-anchor after a stall rather than extrapolating across its gap.
      this.mediaAnchor={slot:this.slotTime,time};
      return time;
    }
  }
  function motionRetime(motion,target,time,limits){
    const offset=target-time,span=motion.span;
    if(!motion.valid||!(span>0&&span<=.1)||Math.abs(offset)<.0001||Math.abs(offset)>span*.55)return null;
    // The core returns the correlation offset, opposite to feature motion.
    // After stabilization, the feature step also includes the change in map.
    const x=(-motion.dx-motion.mapX+motion.previousMapX)*offset/span;
    const y=(-motion.dy-motion.mapY+motion.previousMapY)*offset/span;
    const within=(delta,map,limit)=>Number.isFinite(delta)&&Math.abs(map-delta)<=Math.max(Math.abs(map),limit);
    if(!within(x,motion.mapX,limits.limitX)||!within(y,motion.mapY,limits.limitY))return null;
    return {time:target,x,y};
  }
  const platform={browserAPI,watchIdentity,findPlayer,originalPresentation,FrameClock,SourceCadence,OutputCadence,motionRetime};
  root.YTSteadyPlatform=platform;
  if(typeof module!=="undefined"&&module.exports)module.exports=platform;
})(globalThis);
