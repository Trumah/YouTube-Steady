param([switch]$SourceOnly)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$steadyProject = Split-Path -Parent $PSScriptRoot
$steadyOutput = Join-Path $steadyProject 'dist'
[IO.Directory]::CreateDirectory($steadyOutput) | Out-Null
$steadyManifest = Get-Content -LiteralPath (Join-Path $steadyProject 'extension\manifest.json') -Raw | ConvertFrom-Json
$steadyVersion = $steadyManifest.version
if ($steadyVersion -notmatch '^\d+\.\d+\.\d+$') { throw 'Expected a three-part release version' }
& node (Join-Path $PSScriptRoot 'build-locales.cjs') --check
if ($LASTEXITCODE) { throw 'Locale bundle is not ready for release' }
& node (Join-Path $PSScriptRoot 'build-distribution.cjs') --check
if ($LASTEXITCODE) { throw 'Public destinations are not ready for release' }
& node (Join-Path $PSScriptRoot 'build-icons.cjs') --check
if ($LASTEXITCODE) { throw 'Extension icons are not ready for release' }
& node (Join-Path $PSScriptRoot 'build-wasm-data.cjs') --check
if ($LASTEXITCODE) { throw 'Bundled WASM data is not ready for release' }
$steadyExtension = @('manifest.json','depan-core.js','depan-core.wasm','depan-wasm-data.js','locales.js','i18n.js','settings.js','profiles.js','performance.js','regions.js','support.js','renderer.js','overlay.js','ui.js','controller.js','popup.html','popup.js','LICENSE.txt','NOTICE.txt','FFTW-COPYRIGHT.txt','EMSCRIPTEN-LICENSE.txt')
$steadyExtension += $steadyManifest.icons.psobject.Properties.Value | Select-Object -Unique
foreach ($steadyCatalog in Get-ChildItem -LiteralPath (Join-Path $steadyProject 'extension\_locales') -Filter messages.json -File -Recurse) {
    $steadyExtension += $steadyCatalog.FullName.Substring((Join-Path $steadyProject 'extension').Length + 1).Replace('\','/')
}
function Write-SteadyZip([string]$Path, [hashtable]$Files) {
    $steadyStream = [IO.File]::Open($Path,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try {
        $steadyArchive = [IO.Compression.ZipArchive]::new($steadyStream,[IO.Compression.ZipArchiveMode]::Create,$false)
        try {
            foreach ($steadyEntry in ($Files.Keys | Sort-Object)) {
                $steadyFile = $Files[$steadyEntry]
                if (!(Test-Path -LiteralPath $steadyFile -PathType Leaf)) { throw "Missing release input: $steadyFile" }
                [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($steadyArchive,$steadyFile,$steadyEntry,[IO.Compression.CompressionLevel]::Optimal) | Out-Null
            }
        } finally { $steadyArchive.Dispose() }
    } finally { $steadyStream.Dispose() }
}
$steadyBinaryFiles = @{}
foreach ($steadyName in $steadyExtension) { $steadyBinaryFiles[$steadyName] = Join-Path $steadyProject "extension\$steadyName" }
$steadyBinaryZip = Join-Path $steadyOutput "Video-Stabilizer-$steadyVersion.zip"
if ($SourceOnly) {
    if (!(Test-Path -LiteralPath $steadyBinaryZip -PathType Leaf)) { throw 'Source-only packaging requires the tested install ZIP.' }
} else { Write-SteadyZip $steadyBinaryZip $steadyBinaryFiles }
$steadySourceFiles = @{}
foreach ($steadyName in $steadyExtension) { $steadySourceFiles["Video-Stabilizer/extension/$steadyName"] = Join-Path $steadyProject "extension\$steadyName" }
# Public source includes synthetic evidence only. Local installed-browser
# records and screenshots of a signed-in YouTube page stay outside this ZIP.
$steadyRelativeFiles = @('package.json','README.md','AGENTS.md','PROJECT_STATUS.md','.gitignore','.gitattributes','README.txt','README-build.txt','TRANSLATING.txt','使用說明.txt','LICENSE.txt','NOTICE.txt','FFTW-COPYRIGHT.txt','EMSCRIPTEN-LICENSE.txt','tests/depan.test.cjs','tests/settings.test.cjs','tests/i18n.test.cjs','tests/native_reference.py','dev/v2.html','dev/v2-harness.js','dev/i18n-harness.js','dev/popup-preview.html','dev/popup-test-api.js','dev/server.cjs','validation/native/reference.json','validation/native/world-0.bin','validation/native/world-1.bin','validation/native-conformance.json','validation/i18n-browser.json','validation/media-v2.1.json','validation/cadence-v2.0-local.json','validation/cadence-v2.1-local.json','validation/public-validation.json')
foreach ($steadyName in $steadyRelativeFiles) { $steadySourceFiles["Video-Stabilizer/$steadyName"] = Join-Path $steadyProject $steadyName }
foreach ($steadyName in @('PUBLISHING.txt','RELEASE.txt','tests/distribution.test.cjs','site/index.html','site/style.css','site/script.js','site/icon.svg','site/privacy.html','site/privacy.css','dev/site-server.cjs','dev/support-test.html','dev/support-harness.js','validation/i18n-browser-2.1.1.json','validation/support-browser.json','validation/site-browser.json')) {
    $steadySourceFiles["Video-Stabilizer/$steadyName"] = Join-Path $steadyProject $steadyName
}
foreach ($steadyName in @('validation/i18n-browser-2.1.2.json','validation/support-browser-2.1.2.json','validation/popup-support-2.1.2.json','validation/site-browser-2.1.2.json','validation/publication-live-2.1.2.json')) {
    $steadySourceFiles["Video-Stabilizer/$steadyName"] = Join-Path $steadyProject $steadyName
}
$steadySourceFiles['Video-Stabilizer/validation/defaults-browser-2.1.3.json'] = Join-Path $steadyProject 'validation/defaults-browser-2.1.3.json'
$steadySourceFiles['Video-Stabilizer/validation/compensation-browser-2.5.2.json'] = Join-Path $steadyProject 'validation/compensation-browser-2.5.2.json'
$steadySourceFiles['Video-Stabilizer/validation/ui-defaults-browser-2.8.1.json'] = Join-Path $steadyProject 'validation/ui-defaults-browser-2.8.1.json'
$steadySourceFiles['Video-Stabilizer/validation/ui-simplify-browser-2.9.0.json'] = Join-Path $steadyProject 'validation/ui-simplify-browser-2.9.0.json'
$steadySourceFiles['Video-Stabilizer/dev/wasm-harness.js'] = Join-Path $steadyProject 'dev/wasm-harness.js'
$steadySourceFiles['Video-Stabilizer/validation/embedded-core-browser-2.9.3.json'] = Join-Path $steadyProject 'validation/embedded-core-browser-2.9.3.json'
$steadySourceFiles['Video-Stabilizer/validation/last-applied-browser-2.9.4.json'] = Join-Path $steadyProject 'validation/last-applied-browser-2.9.4.json'
$steadySourceFiles['Video-Stabilizer/validation/cadence-browser-2.9.5.json'] = Join-Path $steadyProject 'validation/cadence-browser-2.9.5.json'
$steadySourceFiles['Video-Stabilizer/validation/performance-alert-browser-2.9.6.json'] = Join-Path $steadyProject 'validation/performance-alert-browser-2.9.6.json'
$steadySourceFiles['Video-Stabilizer/validation/store-localization-2.9.7.json'] = Join-Path $steadyProject 'validation/store-localization-2.9.7.json'
$steadySourceFiles['Video-Stabilizer/validation/rename-browser-2.9.2.json'] = Join-Path $steadyProject 'validation/rename-browser-2.9.2.json'
$steadySourceFiles['Video-Stabilizer/validation/apply-confirm-browser-2.9.1.json'] = Join-Path $steadyProject 'validation/apply-confirm-browser-2.9.1.json'
foreach ($steadyName in @('dev/profile-fixture.js','dev/profiles-harness.js','dev/performance-harness.js','tests/profiles.test.cjs','tests/performance.test.cjs','validation/profiles-browser-2.7.0.json','validation/cutoff-browser-2.7.1.json','validation/log-cutoff-browser-2.7.2.json','validation/region-search-browser-2.8.0.json','dev/limits-harness.js','tests/ui.test.cjs','validation/native/extension-2.5.2-motion.json','validation/limits-icon-browser-2.6.0.json')) {
    $steadySourceFiles["Video-Stabilizer/$steadyName"] = Join-Path $steadyProject $steadyName
}
foreach ($steadyName in @('dev/icon-preview.html','dev/regions-harness.js','dev/sampling-harness.js','tests/regions.test.cjs','tests/lifetime.test.cjs','tests/overlay.test.cjs','dev/overlay-harness.js','dev/slider-harness.js','validation/sliders-browser-2.5.1.json','validation/overlay-browser-2.5.0.json','validation/regions-browser-2.2.0.json','validation/ratio-browser-2.3.0.json','validation/sampling-browser-2.4.0.json','validation/lifetime-2.4.1.json','validation/icon-browser-2.1.4.json','validation/entry-browser-2.1.5.json','validation/popup-sizing-2.1.6.json')) {
    $steadySourceFiles["Video-Stabilizer/$steadyName"] = Join-Path $steadyProject $steadyName
}
foreach ($steadyFile in Get-ChildItem -LiteralPath $PSScriptRoot -File -Recurse) {
    $steadyName = $steadyFile.FullName.Substring($steadyProject.Length + 1).Replace('\','/')
    $steadySourceFiles["Video-Stabilizer/$steadyName"] = $steadyFile.FullName
}
$steadySourceZip = Join-Path $steadyOutput "Video-Stabilizer-$steadyVersion-source.zip"
Write-SteadyZip $steadySourceZip $steadySourceFiles
@($steadyBinaryZip,$steadySourceZip) | ForEach-Object {
    [pscustomobject]@{file=[IO.Path]::GetFileName($_);bytes=(Get-Item -LiteralPath $_).Length;sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash}
} | ConvertTo-Json
