"use strict";
const fs=require("node:fs"),path=require("node:path"),assert=require("node:assert/strict");
const root=path.resolve(__dirname,".."),languages=JSON.parse(fs.readFileSync(path.join(__dirname,"languages.json"),"utf8"));
const catalogs={},placeholders=s=>Array.from(s.matchAll(/\{(\w+)\}/g),m=>m[1]).sort();
const base=JSON.parse(fs.readFileSync(path.join(root,"extension/_locales/en/messages.json"),"utf8"));
for(const language of languages){
  const file=path.join(root,"extension/_locales",language.code,"messages.json"),catalog=JSON.parse(fs.readFileSync(file,"utf8"));
  assert.deepEqual(Object.keys(catalog).sort(),Object.keys(base).sort(),`${language.code}: missing or extra messages`);
  for(const [key,value]of Object.entries(catalog)){
    assert.match(key,/^[A-Za-z][A-Za-z0-9_]*$/);assert.equal(typeof value.message,"string");assert.ok(value.message.trim(),`${language.code}.${key}: empty`);
    assert.deepEqual(placeholders(value.message),placeholders(base[key].message),`${language.code}.${key}: placeholders`);
    assert.ok(!/[<>]/.test(value.message),`${language.code}.${key}: messages are plain text`);
  }
  assert.ok(Array.from(catalog.extensionName.message).length<=75,`${language.code}: manifest name too long`);
  assert.ok(Array.from(catalog.extensionDescription.message).length<=132,`${language.code}: manifest description too long`);
  catalogs[language.code]=catalog;
}
const generated="/* Generated from the _locales message catalogs by src/build-locales.cjs. GPL-2.0-or-later. */\n"+
  "(function(root){\"use strict\";const data="+JSON.stringify({languages,catalogs})+";root.YTSteadyLocales=data;if(typeof module!==\"undefined\"&&module.exports)module.exports=data;})(globalThis);\n";
const target=path.join(root,"extension/locales.js");
if(process.argv.includes("--check")){assert.equal(fs.readFileSync(target,"utf8"),generated,"Generated locales.js is stale; run npm run build:locales");}
else fs.writeFileSync(target,generated);
console.log(`${languages.length} complete locales, ${Object.keys(base).length} messages each; bundle ${process.argv.includes("--check")?"verified":"generated"}.`);
