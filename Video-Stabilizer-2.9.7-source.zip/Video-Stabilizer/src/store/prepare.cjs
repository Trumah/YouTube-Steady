"use strict";
// Store materials use the tested binary; never rebuild a sealed release.
const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto"),assert=require("node:assert/strict");
const root=path.resolve(__dirname,"../.."),listing=require("./listing.json"),out=path.join(root,listing.materialsDirectory);
const languages=require("../languages.json");
const hash=data=>crypto.createHash("sha256").update(data).digest("hex");
fs.mkdirSync(out,{recursive:true});
const binary=fs.readFileSync(path.join(root,listing.package));
assert.equal(hash(binary),listing.packageSha256,"The tested public install package must remain byte-identical.");
fs.writeFileSync(path.join(out,path.basename(listing.package)),binary);
assert.deepEqual(Object.keys(listing.locales).sort(),languages.map(language=>language.code).sort(),"Provide a complete store listing for every supported language.");
for(const [locale,text]of Object.entries(listing.locales)){
  const catalog=JSON.parse(fs.readFileSync(path.join(root,"extension/_locales",locale,"messages.json"),"utf8"));
  assert.equal(text.name,catalog.extensionName.message,"Store title and packaged title differ: "+locale);
  assert.equal(text.summary,catalog.extensionDescription.message,"Store summary and packaged summary differ: "+locale);
  assert.ok(Array.from(text.name).length<=75,"Title is too long: "+locale);
  assert.ok(text.summary.length<=132,"Summary is too long: "+locale);
  assert.ok(text.description.trim(),"Full description is missing: "+locale);
  assert.ok(text.description.length<=16000,"Description is too long: "+locale);
  fs.writeFileSync(path.join(out,"listing-"+locale+".txt"),text.name+"\n\n"+text.summary+"\n\n"+text.description+"\n");
}
fs.writeFileSync(path.join(out,"reviewer-notes.txt"),listing.reviewerNotes+"\n");
assert.ok(listing.reviewerNotesShort.length<=500,"Reviewer instructions exceed the dashboard's 500-character limit.");
fs.writeFileSync(path.join(out,"reviewer-instructions-500.txt"),listing.reviewerNotesShort+"\n");
fs.writeFileSync(path.join(out,"privacy-fields.txt"),[
  "Single purpose",listing.privacy.singlePurpose,"","storage permission",listing.privacy.storageJustification,
  "","YouTube host access",listing.privacy.hostJustification,"","Remote code: NO",listing.privacy.remoteCodeExplanation,
  "","Data handled locally: "+listing.privacy.dataTypesHandledLocally.join(", "),listing.privacy.dataHandlingExplanation,
  "","Privacy policy URL (verify public availability before submitting)",listing.privacyPolicy,""
].join("\n"));
for(const name of ["privacy.html","privacy.css"]){
  const data=fs.readFileSync(path.join(root,"site",name));fs.writeFileSync(path.join(root,name),data);fs.writeFileSync(path.join(out,name),data);
}
// Keep the version-matched portal beside the policy without changing the live site.
fs.copyFileSync(path.join(root,"work/github-web-"+listing.version,"index.html"),path.join(out,"index.html"));
fs.copyFileSync(path.join(root,"site/icon.svg"),path.join(out,"icon.svg"));
console.log(JSON.stringify({version:listing.version,packageSha256:hash(binary),locales:Object.fromEntries(Object.entries(listing.locales).map(([code,text])=>[code,{summaryCharacters:text.summary.length,descriptionCharacters:text.description.length}])),output:out},null,2));
