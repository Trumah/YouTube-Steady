# Video Stabilizer

Version **2.9.7** adds concise localized purpose titles, summaries and full Chrome Web Store descriptions in all 12 supported languages. The Video Stabilizer brand is retained; relevant shake, vibration and stabilization wording is used in context. The native core, processing, saved settings, permissions and privacy behavior are unchanged. The public store and website remain on the verified 2.9.6 installation while the metadata update goes through review. See PROJECT_STATUS.md for current publication status.

The **2.9.6** release adds sustained playback warnings: an amber icon with a `!`, one brief notice per incident, and localized advice in the panel. The monitor compares successful output with source cadence and distinguishes processing pressure, source frame drops and buffering when evidence is available. Five effective seconds of trouble trigger the reminder; ten healthy seconds clear it. Startup, seeking, pauses, ads and hidden pages do not create false incidents. The Q and Performance buttons only open the relevant controls; all adjustments remain manual. All 12 languages, localized numbers, right-to-left layout and narrow players are supported. Last Apply, My default and every processing setting are retained. Its Chrome Web Store installation has been verified.

Local **2.9.5** keeps frame delivery independent of whether the settings panel is open. A bounded native-timestamp watchdog recovers frames missed by video callbacks; duplicates are closed without analysis, and capture/output keep the same VideoFrame. Output uses normal compositing. Settings and the native core are unchanged. This local build is not publicly released.

Local **2.9.4**: Apply now persists the confirmed settings for new videos, tabs, reloads and browser restarts. My default is a separate, manually restored preset. Existing open videos and unapplied drafts are not overwritten by another tab. Enable remains immediate and is remembered. On first upgrade, the existing personal default is the starting point because earlier Apply-only values were never stored. This local update is not yet publicly released.


Complete source workspace for **Video Stabilizer**, a free, open-source Chrome extension that stabilizes video inside the YouTube player using a local DePan / FFTW WebAssembly core.

The **2.9.3** release fixes the browser core-loading path: the same WASM bytes are delivered as packaged content-script data, with no page-to-extension WASM fetch. All files must be updated together before reloading the extension and refreshing YouTube. The native core, defaults and personal settings are retained. Packages use `Video-Stabilizer-2.9.3{,-source}.zip`; see `validation/embedded-core-browser-2.9.3.json`.

The earlier local **2.9.2** release renames the product from YouTube Steady to **Video Stabilizer**. All features remain free, with optional one-time support and no subscription. The supported target is YouTube in desktop Google Chrome; Microsoft Edge has not been validated. Processing, defaults, the single personal profile and storage identifiers are retained. Update files in the existing installed folder, reload the extension, then refresh YouTube. The installation and corresponding-source packages are `dist/Video-Stabilizer-2.9.2.zip` and `dist/Video-Stabilizer-2.9.2-source.zip`. The 2.9.3 release carries this product name forward at the existing public URLs.

- [Public website and installation guide](https://trumah.github.io/YouTube-Steady/)
- [Video Stabilizer releases](https://github.com/Trumah/YouTube-Steady/releases)
- [Current project status and handoff](PROJECT_STATUS.md)
- [Playback controls and parameters](README.txt)
- [Native-core build prerequisites](README-build.txt)

## Development

The local **2.9.1** build requires an explicit Apply for changed parameters and loaded presets. System defaults and Restore my default only fill the form; closing discards them. Apply is disabled when unchanged. Save as my default sits beside Apply and saves only confirmed settings, with no pending draft and no processing restart. Direct Enable/UI preferences remain immediate, and processing failures have a separate Retry. Defaults and the native core are unchanged. See `validation/apply-confirm-browser-2.9.1.json`. The version notes below are historical.

The local **2.9.0** build uses one personal default and a compact panel. Enable switches stabilization on/off; Show regions and Restore my default share a row. Apply changes only this viewing. Save as my default validates, applies and saves the current form for later videos. Closing, Escape or toggling the entry closed discards unapplied edits. Comparison, undo, the previous-default backup and the My default section are removed. Parameter help uses tooltips and accessible descriptions; limits remain visible and detailed readings move to Performance. The current schema9/format2 profile remains readable; the next save removes any old backup. System defaults and the native core are unchanged. See `validation/ui-simplify-browser-2.9.0.json`.

The earlier local **2.8.1** build introduced the user-selected defaults: central only, R85/Q30/S30/C15, cutoff0.5Hz/damping0.3, center priority off, trust4/stab1, zoom1.00 and bilinear output. Advanced follows the requested order from damping through detection, sampling, search, interpolation, zoom, icon and language. See `validation/ui-defaults-browser-2.8.1.json`. Version notes below describe historical behavior.

The earlier local **2.8.0** build defines S against each region, limits each axis independently and draws yellow bidirectional arrows. Periods use seconds. Pre2.8 processing settings/backups are intentionally discarded; new profiles use schema9/format2. See `validation/region-search-browser-2.8.0.json`. Version notes below describe their historical behavior.

The local **2.7.2** build uses logarithmic cutoff slider travel and shows its reciprocal period in milliseconds. Cutoff and C% stay in the common controls; R, Q and Zoom move to Advanced. Exact Hz input, all saved values, undo and comparison remain unchanged. See `validation/log-cutoff-browser-2.7.2.json`.

The local **2.7.1** build moves cutoff to the common controls and removes the separate strength preset buttons and duplicate status. Heavy / Medium / Light are slider guides, with Medium at the default 1 Hz. Changing cutoff preserves C and every other custom value, including existing 2.7.0 personal profiles. Comparison, undo and explicitly saved defaults remain. See `validation/cutoff-browser-2.7.1.json`.

The local **2.7.0** build adds Light / Medium / Heavy drafts, display-only original comparison, five-step local undo and separate current-viewing / My default scopes. Existing custom profiles remain readable and their original storage is untouched. Refreshing or switching videos loads My default; saving it never replaces another open video's active settings. See `README.txt` and `validation/profiles-browser-2.7.0.json` for recovery, calibration and verification.

The local **2.6.0** update expands supported numeric inputs, separates precise entry from common slider travel, stabilizes stiff nonlinear compensation, and adds automatic icon clearance, drag/keyboard positioning and hiding with toolbar recovery. Existing defaults and profiles are preserved. See `validation/limits-icon-browser-2.6.0.json` and README.txt for exact ranges and evidence.

The local **2.5.2** update displays C as a translucent purple band at the frame edges. Each side is C% of its corresponding source dimension; the inner rectangle subtracts both sides. C is independent of search S and remains a soft limit, not a crop or a guarantee against black borders. Zero hides the band; overlapping bands fill the frame without changing the stored value. See `validation/compensation-browser-2.5.2.json`.

The local **2.5.1** update adds sliders to all numeric fields and matches parameter/slider colors with the preview outlines. R is blue, Q teal, S yellow, C purple and Zoom white. Precise text input, the draft/Apply workflow and existing defaults are retained. Region status uses fill and dots so it does not overwrite parameter colors. See `validation/sliders-browser-2.5.1.json`.

The local **2.5.0** build simplifies geometry to R and source-relative shared search/compensation values S/C. Parameter edits draw a five-second preview of the grid, analysis regions, search bounds, soft compensation and visible zoom crop. Drafts and actual selected regions are distinguished, and the overlay never enters the analysis/output pixels. Existing profiles remain active until **Use R / S / C** is previewed and applied. See `validation/overlay-browser-2.5.0.json`.

The local **2.4.1** repair removes orphaned player controls/output after Chrome invalidates an extension context, uses an inline player icon, and loads WASM from complete bytes without the streaming path. Existing settings and native calculations are preserved. Refresh existing YouTube tabs after updating or re-enabling the extension; see `validation/lifetime-2.4.1.json` for test scope.

Node 20+ and PowerShell are sufficient for the existing program tests and packaging. No npm dependencies are required.

```powershell
npm test
npm run serve
```

Open the development page at `http://127.0.0.1:8770/` in a foreground Chrome tab. Select **製作測試片** once if the synthetic fixture is missing. The installed extension does not need this server, Node or Python.

The local 2.1.4 build adds an original camera stabilization icon to Chrome, the popup, player controls and site. Preview actual icon sizes at `http://127.0.0.1:8770/icon-preview`. The editable vector is `src/brand/icon.svg`; `npm run build:icons` uses Sharp to rebuild PNGs. See README-build.txt for the optional tooling. Normal tests and packaging use the supplied assets without installing Sharp.

The local 2.1.5 build makes the lower-right player entry icon-only, with localized tooltips, accessible naming and a dimmed off/bypass state.

The local 2.1.6 build fixes the toolbar popup collapsing into a narrow column. A definite root width avoids a circular dependency on Chrome's initial popup viewport. It was verified in the actual toolbar popup and at three preview widths across all 12 languages; see `validation/popup-sizing-2.1.6.json`.

The local 2.2.0 build adds source-width/height percentages and three spatial detection modes: center-weighted five regions, balanced five regions, and adaptive selection of up to five cells from a 3×3 grid. Each cell keeps its own preceding-frame reference. Reliable, agreeing motion is combined before a single smoothing step. Sampling precision is bounded independently from the source footprint. The original single-region path and existing pixel profiles are preserved; select a new mode and convert units in the player, or use Reset defaults for the new balanced percentage profile. Zoom remains 1.00×. See `README.txt` for conversion and tuning.

The local 2.3.0 build defines the grid with one central ratio R. At R=50, a 1024×768 source has a 512×384 center and 256×192 corners; opposite sides share the remaining space. Cells do not overlap and their integer bounds cover the complete frame. Detection mode controls which cells participate independently from their size. Each cell has its own sampling scale and search limits. Single-region detection uses the shared estimator; the source-luma fast path and old sampling precision remain available. New profiles use R=50 and automatic search. Existing profiles keep their custom geometry and manual search until explicitly changed. See README.txt for the full-frame R=100 limit.

The local 2.4.0 build adds cross-shaped five-region detection and percentage sampling Q. R chooses coverage; Q retains the same percentage of each region’s source width and height from 360p through 4K, including 100% sampling. The main panel shows mode, R, Q and zoom, with a workload/memory estimate; language and detailed controls are in Advanced. Legacy pixel values are read-only until explicitly converted, and old sampling is preserved until Use percentage sampling is chosen. Slow processing keeps the chosen Q and processes available frames, with measured fps/timing and a nonfatal slow status. The native workspace grows on demand; real size/memory failures still restore original playback.

```powershell
.\src\package-release.ps1
npm run build:site
node src/build-web-publication.cjs
```

Archives are written to `dist/`. The structured site preview is in `work/public-site/`; the flat upload bundle is in `work/github-web-<version>/`. To preview the site, run `node dev/site-server.cjs` and open `http://127.0.0.1:8772/`.

## Layout

- `extension/`: directly loadable unpacked extension, including 12 language catalogs and the DePan / FFTW WebAssembly core.
- `src/`: native source, upstream source archives, localization/configuration builders and release scripts.
- `tests/`, `dev/`, `validation/`: automated tests, synthetic browser fixtures and scoped verification reports.
- `site/`: editable website source. The repository-root HTML/JS/ZIPs are the existing published distribution portal.

The versioned 2.1.1/2.1.2 downloads and their release checksums are published artifacts. The root portal and SHA256SUMS.txt track the current release. A rebuild in `dist/` is a local output and must not overwrite a published version. The 2.2.0 percentage defaults express the native DePan 60/30px limits and 512px footprint against a 1920×1080 reference; other resolutions scale with source width/height. Smoothing and bilinear output remain unchanged. Saved custom settings are retained; use Reset defaults to adopt the new profile. Optional support uses the owner's [PayPal.Me profile](https://paypal.me/TrumanSun); there is no subscription or automatic billing.

GNU GPL v2 or later. See [LICENSE.txt](LICENSE.txt), [NOTICE.txt](NOTICE.txt), and [PUBLISHING.txt](PUBLISHING.txt).
