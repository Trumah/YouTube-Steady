"use strict";
// Rasterize vector artwork from the project's established logo, without AI UI mockups.
const fs=require("node:fs"),path=require("node:path"),{createRequire}=require("node:module");
const root=path.resolve(__dirname,"../.."),listing=require("./listing.json"),out=path.join(root,listing.materialsDirectory);
const sharp=createRequire(path.join(root,"work/chrome-web-store/deps/package.json"))("sharp");
const mark=fs.readFileSync(path.join(root,"src/brand/icon.svg"),"utf8").replace(/<!--[\s\S]*?-->/g,"").replace(/^[\s\S]*?<svg[^>]*>/,"").replace(/<\/svg>\s*$/,"");
const svg=(w,h,body)=>`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${body}</svg>`;
function promo(w,h){
  const s=w/440;
  return svg(w,h,`<defs><linearGradient id="bg" x2="1" y2="1"><stop stop-color="#102f3b"/><stop offset="1" stop-color="#081b26"/></linearGradient><radialGradient id="glow"><stop stop-color="#43edbb" stop-opacity=".22"/><stop offset="1" stop-color="#43edbb" stop-opacity="0"/></radialGradient></defs><rect width="${w}" height="${h}" fill="url(#bg)"/><ellipse cx="${w/2}" cy="${h/2}" rx="${w*.54}" ry="${h*.7}" fill="url(#glow)"/><g transform="translate(${w/2-220*s} ${h/2-140*s}) scale(${s})"><g fill="none" stroke-width="2"><rect x="28" y="89" width="84" height="102" rx="12" stroke="#efcb72" opacity=".25" transform="rotate(-10 70 140)"/><rect x="28" y="89" width="84" height="102" rx="12" stroke="#efcb72" opacity=".5" transform="rotate(7 70 140)"/><rect x="28" y="89" width="84" height="102" rx="12" stroke="#efcb72"/><path d="M38 158l20-29 15 16 15-37 14 50" stroke="#d4e6de" stroke-linejoin="round"/><rect x="328" y="89" width="84" height="102" rx="12" stroke="#43edbb"/><path d="M338 158l20-29 15 16 15-37 14 50" stroke="#d4e6de" stroke-linejoin="round"/><path d="M123 140h19m156 0h19" stroke="#43edbb" opacity=".6"/><path d="M137 135l5 5-5 5m175-10 5 5-5 5" stroke="#43edbb" opacity=".6"/></g><g transform="translate(156 76)">${mark}</g></g>`);
}
async function run(){
  fs.mkdirSync(out,{recursive:true});
  const files={"icon128.png":svg(128,128,`<g transform="translate(16 16) scale(.75)">${mark}</g>`),"promo-small.png":promo(440,280),"promo-marquee.png":promo(1400,560)};
  for(const [name,source]of Object.entries(files)){
    fs.writeFileSync(path.join(out,name.replace(/\.png$/,".svg")),source);
    let image=sharp(Buffer.from(source));if(name!=="icon128.png")image=image.removeAlpha();
    await image.png({compressionLevel:9}).toFile(path.join(out,name));
  }
  console.log("Store artwork ready: icon128.png, promo-small.png, promo-marquee.png");
}
run().catch(error=>{console.error(error.message);process.exitCode=1;});
