"use strict";
const http=require("node:http"),fs=require("node:fs"),path=require("node:path");
const root=path.resolve(__dirname,"../.."),port=8778,manifest=require("../../extension/manifest.json");
const extensionFiles=new Set([...manifest.content_scripts.flatMap(x=>x.js),...Object.values(manifest.icons)]);
const routes={"/":"src/store/demo.html","/demo.js":"src/store/demo.js","/demo.css":"src/store/demo.css","/brand.svg":"src/brand/icon.svg","/privacy.html":"site/privacy.html","/privacy.css":"site/privacy.css","/icon.svg":"site/icon.svg"};
const types={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".svg":"image/svg+xml",".png":"image/png"};
http.createServer((req,res)=>{
  try{
    if(!["GET","HEAD"].includes(req.method)){res.writeHead(405);res.end();return;}
    const url=new URL(req.url,"http://127.0.0.1"),name=url.pathname,asset=name.startsWith("/extension/")?name.slice(11):null;
    const rel=routes[name]||(asset&&extensionFiles.has(asset)?"extension/"+asset:null);
    if(!rel){res.writeHead(404);res.end();return;}
    const file=path.join(root,rel),size=fs.statSync(file).size;
    res.writeHead(200,{"Content-Type":types[path.extname(file)]||"application/octet-stream","Content-Length":size,"Cache-Control":"no-store","Content-Security-Policy":"default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src 'self' blob:; img-src 'self' data:; connect-src 'none'; object-src 'none'"});
    if(req.method==="HEAD")res.end();else fs.createReadStream(file).pipe(res);
  }catch{res.writeHead(404);res.end();}
}).listen(port,"127.0.0.1",()=>console.log("Store preview: http://127.0.0.1:"+port));
