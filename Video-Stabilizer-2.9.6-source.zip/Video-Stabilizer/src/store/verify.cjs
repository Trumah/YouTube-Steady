"use strict";
const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto"),assert=require("node:assert/strict"),{createRequire}=require("node:module");
const root=path.resolve(__dirname,"../.."),listing=require("./listing.json"),out=path.join(root,listing.materialsDirectory);
const sharp=createRequire(path.join(root,"work/chrome-web-store/deps/package.json"))("sharp"),hash=data=>crypto.createHash("sha256").update(data).digest("hex");
async function run(){
  const reportFile=path.join(root,"validation/chrome-web-store-"+listing.version+".json"),previous=fs.existsSync(reportFile)?JSON.parse(fs.readFileSync(reportFile,"utf8")):{};
  const packageHash=hash(fs.readFileSync(path.join(out,path.basename(listing.package))));assert.equal(packageHash,listing.packageSha256);
  // ZIP layout and file comparisons are recorded by the independent archive check.
  const archiveCheck=JSON.parse(fs.readFileSync(path.join(out,"package-check.json"),"utf8"));
  assert.equal(archiveCheck.version,listing.version);assert.equal(archiveCheck.sha256,packageHash);assert.equal(archiveCheck.rootManifest,true);assert.equal(archiveCheck.allFilesMatchExtension,true);assert.equal(archiveCheck.sourceMatchesExtension,true);
  const releaseFiles=await Promise.all([path.basename(listing.package),"Video-Stabilizer-"+listing.version+"-source.zip"].map(async name=>{
    const url="https://github.com/Trumah/YouTube-Steady/releases/download/v"+listing.version+"/"+name,response=await fetch(url);assert.equal(response.status,200,url);
    const data=Buffer.from(await response.arrayBuffer()),expected=fs.readFileSync(path.join(root,"dist",name));assert.equal(hash(data),hash(expected),"Public release differs: "+name);
    return {name,url,sha256:hash(data),matchesLocal:true};
  }));
  const publicFiles=await Promise.all(["index.html","script.js","public.js","privacy.html","privacy.css"].map(async name=>{
    const url=listing.website+name,response=await fetch(url);assert.equal(response.status,200,url);
    const data=Buffer.from(await response.arrayBuffer()),expected=fs.readFileSync(path.join(root,name));
    assert.equal(hash(data),hash(expected),"Published file differs: "+name);
    return {name,url,status:response.status,sha256:hash(data),matchesLocal:true};
  }));
  const artwork=[];
  for(const [name,width,height]of [["icon128.png",128,128],["promo-small.png",440,280],["promo-marquee.png",1400,560],["screenshot-controls.jpg",1280,800],["screenshot-regions.jpg",1280,800]]){
    const file=path.join(out,name),data=fs.readFileSync(file),info=await sharp(data).metadata();assert.equal(info.width,width,name);assert.equal(info.height,height,name);if(name!=="icon128.png")assert.equal(info.hasAlpha,false,"Store screenshots and promo images must not contain alpha: "+name);
    artwork.push({name,width,height,bytes:data.length,sha256:hash(data)});
  }
  const response=await fetch("https://api.github.com/repos/Trumah/YouTube-Steady/commits/main",{headers:{Accept:"application/vnd.github+json"}});assert.equal(response.status,200);
  const commit=await response.json();
  const screenshots=JSON.parse(fs.readFileSync(path.join(out,"screenshot-observations.json"),"utf8"));assert.equal(screenshots.version,listing.version);assert.equal(screenshots.observed.active,true);assert.equal(screenshots.observed.error,false);
  const report={...previous,version:listing.version,checkedAt:new Date().toISOString(),package:{...archiveCheck,byteIdenticalToPublishedRelease:true},programTests:previous.programTests||null,releaseFiles,publicFiles,websiteCommit:commit.sha,artwork,screenshots,privacyDisclosure:{dataHandledLocally:listing.privacy.dataTypesHandledLocally,transmissionToDeveloper:false},storeSubmission:previous.storeSubmission||{status:"draft",itemId:listing.itemId,reviewSubmitted:false}};
  fs.writeFileSync(reportFile,JSON.stringify(report,null,2)+"\n");
  console.log(JSON.stringify({packageHash,publicFiles:publicFiles.length,artwork:artwork.length,websiteCommit:commit.sha,report:path.relative(root,reportFile)},null,2));
}
run().catch(error=>{console.error(error.message);process.exitCode=1;});
