"use strict";
// Self-authored canvas scene, not a screenshot or video from another publisher.
// The shipped extension renders and controls the live video without modification.
localStorage.setItem("ytSteadyLanguage",JSON.stringify("en"));
const world=document.createElement("canvas");world.width=1600;world.height=950;
const paint=world.getContext("2d"),polygon=(points,color)=>{paint.fillStyle=color;paint.beginPath();points.forEach(([x,y],n)=>n?paint.lineTo(x,y):paint.moveTo(x,y));paint.closePath();paint.fill();};
const sky=paint.createLinearGradient(0,0,0,600);sky.addColorStop(0,"#9bc6cf");sky.addColorStop(1,"#e5e3c8");paint.fillStyle=sky;paint.fillRect(0,0,1600,950);
paint.fillStyle="#f8e5aa";paint.beginPath();paint.arc(1250,180,62,0,Math.PI*2);paint.fill();
polygon([[0,470],[150,210],[290,376],[470,100],[720,370],[940,170],[1170,400],[1400,160],[1600,420],[1600,680],[0,680]],"#7297a0");
polygon([[0,520],[200,330],[400,470],[650,250],[880,440],[1110,320],[1390,460],[1600,350],[1600,680],[0,680]],"#4d7d7b");
paint.fillStyle="#86b8b4";paint.fillRect(0,580,1600,370);
polygon([[0,610],[270,450],[470,480],[640,415],[850,530],[1120,558],[1040,650],[530,694],[0,810]],"#547c58");
let seed=37519;const random=()=>{seed=Math.imul(seed,1664525)+1013904223|0;return(seed>>>0)/4294967296;};
for(let n=0;n<600;n++){const x=random()*1600,y=620+random()*330;paint.strokeStyle=n%2?"#9ccac1":"#79a7a5";paint.lineWidth=1;paint.beginPath();paint.moveTo(x,y);paint.lineTo(x+12+random()*65,y);paint.stroke();}
for(let row=0;row<3;row++)for(let n=0;n<10;n++){
  const x=140+n*71+row*35,y=485+row*48-n*3,w=42+random()*18,h=45+random()*20;
  paint.fillStyle=["#e8d4ae","#d5c2a0","#f1dfbc"][n%3];paint.fillRect(x,y-h,w,h);
  polygon([[x-5,y-h],[x+w/2,y-h-18],[x+w+5,y-h]],n%2?"#885344":"#a56950");
  paint.fillStyle="#41605c";for(let i=0;i<3;i++)for(let j=0;j<2;j++)paint.fillRect(x+7+i*12,y-h+10+j*19,6,9);
}
paint.fillStyle="#e5d9bc";paint.fillRect(855,422,35,124);paint.fillStyle="#405a50";paint.fillRect(864,440,17,29);polygon([[849,422],[873,390],[896,422]],"#9a624b");
for(let n=0;n<65;n++){const x=40+random()*1040,y=480+random()*145;paint.fillStyle="#304f3f";paint.fillRect(x-2,y,4,22);polygon([[x-14,y+7],[x,y-34],[x+14,y+7]],n%2?"#315e49":"#3a6b50");}
polygon([[0,950],[0,815],[360,735],[690,800],[1000,780],[1600,900],[1600,950]],"#395b45");
for(let n=0;n<330;n++){const x=random()*1600,y=790+random()*160;paint.strokeStyle=n%2?"#6c8b5c":"#486f4e";paint.beginPath();paint.moveTo(x,y);paint.lineTo(x+5,y-7-random()*9);paint.stroke();}
const canvas=document.createElement("canvas");canvas.width=1280;canvas.height=720;const ctx=canvas.getContext("2d",{alpha:false}),video=document.querySelector("video");
video.srcObject=canvas.captureStream(30);video.play().catch(()=>{});
let frame=0;function draw(){const t=frame++/30,x=120+Math.sin(t*12)*15+Math.sin(t*21)*5,y=100+Math.sin(t*15)*8;ctx.drawImage(world,x,y,1280,720,0,0,1280,720);requestAnimationFrame(draw);}draw();
