"use strict";
const http = require("node:http"), fs = require("node:fs"), path = require("node:path");
const root = path.resolve(__dirname, ".."), port = Number(process.env.PORT||8770);
// Optional fixed runtime/page roots allow comparing a prior release without
// changing the installed extension or exposing arbitrary filesystem paths.
const runtimeRoot=process.env.STEADY_RUNTIME_ROOT?path.resolve(process.env.STEADY_RUNTIME_ROOT):path.join(root,"extension");
const iconFiles=Object.values(JSON.parse(fs.readFileSync(path.join(runtimeRoot,"manifest.json"),"utf8")).icons||{});
let rawWasmRequests=0;const blockRawWasm=process.env.STEADY_BLOCK_WASM_FETCH==="1";
const fixture = path.join(__dirname, "fixture-v2.webm");
const types = {".html":"text/html; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".css":"text/css; charset=utf-8", ".webm":"video/webm", ".json":"application/json; charset=utf-8", ".wasm":"application/wasm", ".png":"image/png"};
const server = http.createServer(async (req, res) => {
  try {
    const pathname = new URL(req.url, "http://127.0.0.1").pathname;
    if ((req.method === "GET" || req.method === "HEAD") && pathname === "/wasm-load-status") { res.writeHead(200,{"Content-Type":"application/json","Cache-Control":"no-store"});res.end(JSON.stringify({blocked:blockRawWasm,rawWasmRequests}));return; }
    if (pathname === "/depan-core.wasm") { rawWasmRequests++; if(blockRawWasm){res.writeHead(403,{"Cache-Control":"no-store"});res.end("Raw WASM fetch disabled for bundled-core validation");return;} }
    if (req.method === "POST" && pathname === "/fixture-v2.webm" && req.headers.origin === `http://127.0.0.1:${port}` && req.headers["content-type"] === "video/webm") {
      const chunks = []; let length = 0;
      for await (const chunk of req) { length += chunk.length; if (length > 32 * 1024 * 1024) { res.writeHead(413); res.end(); return; } chunks.push(chunk); }
      fs.writeFileSync(fixture, Buffer.concat(chunks)); res.writeHead(201); res.end("synthetic fixture saved"); return;
    }
    if (req.method !== "GET" && req.method !== "HEAD") { res.writeHead(405); res.end(); return; }
    const routes = {"/":"dev/v2.html", "/v2-harness.js":"dev/v2-harness.js", "/depan-core.js":"extension/depan-core.js", "/depan-core.wasm":"extension/depan-core.wasm", "/depan-wasm-data.js":"extension/depan-wasm-data.js", "/wasm-harness.js":"dev/wasm-harness.js", "/locales.js":"extension/locales.js", "/i18n.js":"extension/i18n.js", "/ui.js":"extension/ui.js", "/overlay.js":"extension/overlay.js", "/settings.js":"extension/settings.js", "/profiles.js":"extension/profiles.js", "/performance.js":"extension/performance.js", "/profile-fixture.js":"dev/profile-fixture.js", "/profiles-harness.js":"dev/profiles-harness.js", "/performance-harness.js":"dev/performance-harness.js", "/support.js":"extension/support.js", "/regions.js":"extension/regions.js", "/renderer.js":"extension/renderer.js", "/controller.js":"extension/controller.js", "/fixture-v2.webm":"dev/fixture-v2.webm", "/regions-harness.js":"dev/regions-harness.js", "/sampling-harness.js":"dev/sampling-harness.js", "/overlay-harness.js":"dev/overlay-harness.js", "/slider-harness.js":"dev/slider-harness.js", "/limits-harness.js":"dev/limits-harness.js", "/i18n-harness.js":"dev/i18n-harness.js", "/popup-preview":"dev/popup-preview.html", "/popup-test-api.js":"dev/popup-test-api.js", "/popup.js":"extension/popup.js", "/support-test":"dev/support-test.html", "/support-harness.js":"dev/support-harness.js"};
    // Only generated, manifest-declared PNGs are available through this route.
    const rel = routes[pathname]||(pathname==="/icon-preview"?"dev/icon-preview.html":iconFiles.includes(pathname.slice(1))?"extension"+pathname:null);
    if (!rel) { res.writeHead(404); res.end(); return; }
    const file = pathname==="/"&&process.env.STEADY_TEST_PAGE?path.resolve(process.env.STEADY_TEST_PAGE):rel.startsWith("extension/")?path.join(runtimeRoot,rel.slice(10)):path.join(root,rel), stat = fs.statSync(file);
    let start = 0, end = stat.size - 1, status = 200;
    if (req.headers.range) {
      const match = /^bytes=(\d+)-(\d*)$/.exec(req.headers.range);
      if (!match) { res.writeHead(416); res.end(); return; }
      start = Number(match[1]); end = match[2] ? Math.min(end, Number(match[2])) : end; status = 206;
      if (start > end || start >= stat.size) { res.writeHead(416, {"Content-Range":`bytes */${stat.size}`}); res.end(); return; }
    }
    const headers = {"Content-Type":types[path.extname(file)] || "application/octet-stream", "Content-Length":end - start + 1, "Accept-Ranges":"bytes", "Cache-Control":"no-store", "X-Content-Type-Options":"nosniff"};
    if(path.extname(file)===".html")headers["Content-Security-Policy"]=`default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; media-src 'self' blob: http://localhost:${port}; connect-src 'self'; img-src 'self' data:; object-src 'none'`;
    if (status === 206) headers["Content-Range"] = `bytes ${start}-${end}/${stat.size}`;
    res.writeHead(status, headers); if (req.method === "HEAD") res.end(); else fs.createReadStream(file, {start, end}).pipe(res);
  } catch { res.writeHead(404); res.end("not found"); }
});
server.listen(port, "127.0.0.1", () => process.stdout.write(`Video Stabilizer test server: http://127.0.0.1:${port}\n`));
server.on("error", error => { process.stderr.write(error.message + "\n"); process.exitCode = 1; });
