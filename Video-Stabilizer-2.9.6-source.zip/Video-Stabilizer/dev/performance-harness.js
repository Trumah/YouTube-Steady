/* Isolated UI fixtures only; never loaded as an extension content script. */
(function(){
  "use strict";
  const button=document.createElement("button");button.id="test-performance-warning";button.textContent="Test performance alerts & locales";document.querySelector(".actions").append(button);
  const output=document.createElement("pre");output.id="performance-warning-results";output.textContent="Performance alerts not tested.";document.getElementById("results").before(output);
  const language=document.createElement("select");language.id="warning-preview-language";language.setAttribute("aria-label","Warning preview language");for(const item of YTSteadyI18n.languages){const option=document.createElement("option");option.value=item.code;option.textContent=item.name;language.append(option);}document.querySelector(".actions").append(language);
  const preview=document.createElement("button");preview.id="preview-performance-warning";preview.textContent="Preview performance warning";document.querySelector(".actions").append(preview);
  let previewUI,previewBox;
  preview.addEventListener("click",()=>{
    previewUI?.destroy();previewBox?.remove();const languageBefore=YTSteadyI18n.choice;YTSteadyI18n.setLanguage(language.value);
    previewBox=document.createElement("div");previewBox.style.cssText="position:fixed;inset:16px auto auto 16px;width:min(720px,calc(100vw - 32px));height:min(760px,calc(100vh - 32px));background:#172435;z-index:99999;";document.body.append(previewBox);
    const settings={...YTSteadySettings.defaults},state={...JSON.parse(document.getElementById("yt-steady-controls").dataset.state),...settings,version:YTSteadySupport.version,profileDirty:false,error:false,active:true,performanceWarning:{active:true,visible:true,kind:"processing",episode:1,outputFps:42.5,targetFps:60}};
    previewUI=new YTSteadyPlayerUI(previewBox,{settings:()=>settings,dimensions:()=>({width:3840,height:2160,fps:60}),save(){},saveDefault(){},retryStorage(){},retryProcessing(){},draft(){},preview(){},cancel(){}});previewUI.host.id="warning-preview-controls";previewUI.refreshEntry(settings,false);previewUI.publish(state);previewUI.togglePanel(true);
    const close=document.createElement("button");close.textContent="Close preview";close.style.cssText="position:absolute;inset-inline-start:12px;inset-block-end:12px;z-index:100000;";close.addEventListener("click",()=>{previewUI.destroy();previewBox.remove();YTSteadyI18n.setLanguage(languageBefore);});previewBox.append(close);
  });
  button.addEventListener("click",async()=>{
    button.disabled=true;const I=YTSteadyI18n,S=YTSteadySettings,F=YTSteadyProfiles,originalLanguage=I.choice,checks={},report={version:YTSteadySupport.version,userAgent:navigator.userAgent,checks};let fixture,ui,writes=0;
    const check=(name,pass,detail={})=>{checks[name]={pass,...detail};output.textContent=JSON.stringify(report,null,2);};
    const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
    try{
      fixture=document.createElement("div");fixture.id="performance-warning-fixture";fixture.style.cssText="position:fixed;z-index:99999;left:20px;top:20px;background:#07111f;";document.body.append(fixture);
      let applied={...S.defaults},state={...applied,version:YTSteadySupport.version,profileDirty:false,defaultAvailable:true,hasPersonal:true,active:true,error:false,paused:false,outputFps:42,meanMs:22,p95Ms:25,copyMs:10,computeMs:10,drawMs:2,dropped:0,total:300,callbackMisses:0,invalidMatches:0,regions:{inliers:5,selected:5},pixelFormat:"synthetic"};
      const actions={settings:()=>applied,dimensions:()=>({width:1280,height:720,fps:60}),save:()=>{writes++;},saveDefault:()=>{writes++;},retryStorage(){},retryProcessing(){},preview(){},draft:p=>{state.profileDirty=!p||!F.equal(p,applied);ui.publish(state);},cancel:()=>{ui.refreshFields(applied);state.profileDirty=false;ui.publish(state);}};
      ui=new YTSteadyPlayerUI(fixture,actions);ui.host.id="yt-steady-warning-fixture";const e=ui.elements;
      let episode=0;
      for(const language of I.languages)for(const width of [640,320]){
        fixture.style.width=width+"px";fixture.style.height=(width===320?180:500)+"px";I.setLanguage(language.code);ui.translate();ui.refreshFields(applied);ui.refreshEntry(applied,false);
        for(const kind of ["processing","source","buffering","unknown"]){
          state.performanceWarning={active:true,visible:true,kind,episode:++episode,recoveredEpisode:0,outputFps:42.5,targetFps:60};ui.publish(state);ui.togglePanel(true);
          const name=language.code+"_"+width+"_"+kind,p=e.panel.getBoundingClientRect(),r=e.perfWarning.getBoundingClientRect();
          check(name,!e.perfWarning.hidden&&!!e.perfWarningAdvice.textContent&&!/perfWarning[A-Z]/.test(e.perfWarningAdvice.textContent)&&e.perfWarning.scrollWidth<=e.perfWarning.clientWidth+1&&r.left>=p.left-1&&r.right<=p.right+1&&ui.host.dir===language.dir&&e.warningAdjust.hidden===(kind!=="processing"),{dir:ui.host.dir,width,warningWidth:r.width});
          if(kind!=="buffering")check(name+"_localized_rate",e.perfWarningRate.textContent===I.t("perfWarningRate",{output:I.number(42.5,1),target:I.number(60,1)}));
          ui.togglePanel(false);
        }
      }
      fixture.style.width="640px";fixture.style.height="500px";I.setLanguage("en");ui.translate();ui.refreshFields(applied);ui.refreshEntry(applied,false);
      state.performanceWarning={active:true,visible:true,kind:"processing",episode:++episode,recoveredEpisode:0,outputFps:42,targetFps:60};ui.publish(state);
      check("closed_panel_shows_amber_symbol_and_toast",e.entry.dataset.performanceWarning==="true"&&!e.warningBadge.hidden&&!e.perfToast.hidden&&e.panel.hidden&&e.entry.getAttribute("aria-label").includes(I.t("perfWarningEntry")));
      const timer=ui.toastTimer,announcement=e.warningLive.textContent;state.performanceWarning.outputFps=41;ui.publish(state);check("one_notice_per_episode",ui.toastTimer===timer&&e.warningLive.textContent===announcement&&e.warningLive.getAttribute("role")==="status");
      await wait(4200);check("toast_expires_but_warning_remains",e.perfToast.hidden&&!e.warningBadge.hidden&&e.entry.dataset.performanceWarning==="true");
      ui.stageProfile({...applied,sampleRatio:25});const draft=e.sampleRatio.value;ui.showPerformanceTarget("sampleRatio");check("adjust_q_only_locates_existing_draft",e.advanced.open&&ui.shadow.activeElement===e.sampleRatio&&e.sampleRatio.value===draft&&state.profileDirty&&writes===0&&applied.sampleRatio===S.defaults.sampleRatio);
      ui.showPerformanceTarget("performance");check("details_does_not_apply_draft",e.performance.open&&state.profileDirty&&e.sampleRatio.value===draft&&writes===0);
      ui.togglePanel(false);check("close_keeps_existing_cancel_semantics",!state.profileDirty&&e.sampleRatio.value===I.input(applied.sampleRatio)&&writes===0);
      applied={...applied,iconHidden:true};ui.refreshEntry(applied,false);state={...state,...applied,performanceWarning:{...state.performanceWarning,episode:++episode}};ui.publish(state);check("hidden_icon_preference_is_respected",e.entry.hidden&&!e.perfToast.hidden&&applied.iconHidden&&writes===0);
      state.performanceWarning={active:false,visible:true,kind:"",episode,recoveredEpisode:episode,outputFps:60,targetFps:60};ui.publish(state);check("recovery_clears_warning_and_announces_once",e.perfWarning.hidden&&e.warningBadge.hidden&&e.perfToast.hidden&&e.warningLive.textContent===I.t("perfWarningRecovered"));
      state.performanceWarning={active:true,visible:true,kind:"unknown",episode:++episode,recoveredEpisode:episode-1,outputFps:40,targetFps:60};ui.publish(state);state.error=true;ui.refreshEntry(applied,true);ui.publish(state);check("processing_error_takes_precedence",e.warningBadge.hidden&&e.perfWarning.hidden&&e.perfToast.hidden&&e.entry.title.includes(I.t("entryBypass")));
      check("no_preferences_or_processing_values_written",writes===0);
    }catch(error){check("unexpected_error",false,{message:error.message,stack:error.stack});}
    finally{ui?.destroy();fixture?.remove();I.setLanguage(originalLanguage);button.disabled=false;report.complete=true;output.textContent=JSON.stringify(report,null,2);}
  });
})();
