/* Observational playback warnings. Never writes or changes processing settings.
 * Rates use successful output, not the number of late video callbacks.
 * GPL-2.0-or-later. */
(function(root){
  "use strict";
  const policy=Object.freeze({enterRatio:.9,recoverRatio:.95,enterMs:5000,recoverMs:10000,settleMs:1500,windowMs:3000});
  const finite=(value,fallback=0)=>Number.isFinite(value)?value:fallback;
  class Monitor{
    constructor(){this.episode=0;this.recoveredEpisode=0;this.clear(0);}
    clear(now){this.kind="";this.badMs=this.goodMs=this.kindMs=0;this.nextKind="";this.outputFps=this.targetFps=0;this.last=null;this.window=[];this.settleUntil=now+policy.settleMs;}
    suspend(now,keepProgress=false,settleMs=0){this.last=null;this.window=[];if(!keepProgress)this.badMs=this.goodMs=0;this.settleUntil=Math.max(this.settleUntil,now+settleMs);}
    status(){return {active:!!this.kind,kind:this.kind,episode:this.episode,recoveredEpisode:this.recoveredEpisode,outputFps:this.outputFps,targetFps:this.targetFps};}
    sample(input){
      const now=finite(input.now),previous=this.last;
      if(input.clear){this.clear(now);return this.status();}
      if(!input.eligible){this.suspend(now,!!input.seeking);return this.status();}
      this.last={...input,now};
      if(!previous||now<this.settleUntil||previous.now<this.settleUntil)return this.status();
      const dt=now-previous.now,output=input.outputFrames-previous.outputFrames,total=input.sourceFrames-previous.sourceFrames,dropped=input.dropped-previous.dropped,busy=input.busyFrames-previous.busyFrames;
      if(dt<250||dt>2500||[output,total,dropped,busy].some(v=>!Number.isFinite(v)||v<0)||input.mediaTime<previous.mediaTime-.05){this.suspend(now,false,1000);return this.status();}
      const target=Math.max(0,finite(input.targetFps)),waiting=!!input.waiting&&finite(input.bufferAhead,Infinity)<.25;
      if(!waiting&&target<5){this.badMs=this.goodMs=0;return this.status();}
      this.window.push({dt,output,total,dropped,busy,target:target*dt,job:Math.max(0,finite(input.jobMs))*dt,p95:Math.max(0,finite(input.p95Ms))});
      let span=this.window.reduce((n,s)=>n+s.dt,0);while(this.window.length>1&&span-this.window[0].dt>=policy.windowMs)span-=this.window.shift().dt;
      const sum=key=>this.window.reduce((n,s)=>n+s[key],0),frames=sum("total"),dropRate=frames>=15?sum("dropped")/frames:0;
      this.outputFps=sum("output")*1000/span;this.targetFps=sum("target")/span;
      const budget=1000/Math.max(1,this.targetFps),job=sum("job")/span,busyRate=sum("busy")/Math.max(1,this.targetFps*span/1000);
      const p95=Math.max(...this.window.map(s=>s.p95)),processing=job>=budget*.9||(p95>=budget&&busyRate>=.05);
      // Confirm with fresh intervals. A rolling display rate must not extend a
      // three-second hiccup into a five-second incident after playback recovers.
      const intervalRatio=target>0?output*1000/dt/target:0,intervalDrops=total>=15?dropped/total:0;
      const bad=waiting||intervalRatio<policy.enterRatio||intervalDrops>=.05,healthy=!waiting&&intervalRatio>=policy.recoverRatio&&intervalDrops<.03;
      if(bad){
        this.goodMs=0;this.badMs+=dt;
        const kind=waiting?"buffering":processing?"processing":dropRate>=.05?"source":"unknown";
        if(!this.kind&&this.badMs>=policy.enterMs){this.kind=kind;this.episode++;this.nextKind="";this.kindMs=0;}
        else if(this.kind&&kind!==this.kind){if(kind!==this.nextKind){this.nextKind=kind;this.kindMs=0;}this.kindMs+=dt;if(this.kindMs>=2000){this.kind=kind;this.nextKind="";this.kindMs=0;}}
        else{this.nextKind="";this.kindMs=0;}
      }else{
        this.badMs=0;this.nextKind="";this.kindMs=0;this.goodMs=healthy?this.goodMs+dt:0;
        if(this.kind&&this.goodMs>=policy.recoverMs){this.kind="";this.goodMs=0;this.recoveredEpisode=this.episode;}
      }
      return this.status();
    }
  }
  const api={Monitor,policy};root.YTSteadyPerformance=api;if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(globalThis);
