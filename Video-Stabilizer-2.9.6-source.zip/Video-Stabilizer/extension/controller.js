/* Video Stabilizer 2.9.6. GPL-2.0. See LICENSE.txt and NOTICE.txt.
 * One captured VideoFrame is analyzed and drawn as one completed output frame.
 * No per-frame CSS translation, extra decoder, audio output or remote service.
 */
(function(){
  "use strict";
  if(globalThis.__ytSteadyV2Loaded||!globalThis.YTSteadyPipeline||!globalThis.YTSteadySettings||!globalThis.YTSteadyPlayerUI||!globalThis.YTSteadyProfiles||!globalThis.YTSteadyPerformance)return;
  const S=YTSteadySettings,P=YTSteadyPipeline,I=YTSteadyI18n,F=YTSteadyProfiles,W=YTSteadyPerformance,version="2.9.6",storageKeys=Object.values(F.keys);
  const extensionId=globalThis.chrome?.runtime?.id,extension=!!extensionId;
  const testPage=!extension&&location.hostname==="127.0.0.1"&&!!document.querySelector("[data-ytsteady-test-player]");
  if(!extension&&!testPage)return;
  globalThis.__ytSteadyV2Loaded=true;
  const asset=name=>extension?chrome.runtime.getURL(name):new URL("/"+name,location.href).href;
  let settings={...S.defaults},controller=null,reconcileTimer=0,observer=null,stopped=false,loaded=false,session=null,storageReadable=false,writeToken=0,writeQueue=Promise.resolve();
  const stored={},revisions={},pendingWrites=new Map();
  const lifetime=new AbortController(),listeners=[],extensionListeners=[];
  function listen(target,name,fn){target.addEventListener(name,fn);listeners.push([target,name,fn]);}
  function stop(){
    if(stopped)return;stopped=true;lifetime.abort();clearTimeout(reconcileTimer);reconcileTimer=0;observer?.disconnect();
    controller?.destroy();controller=null;P.dispose();
    for(const [target,name,fn]of listeners)target.removeEventListener(name,fn);
    // Invalidated Chrome API objects can throw even while removing a listener.
    for(const [event,fn]of extensionListeners)try{event.removeListener(fn);}catch{}
    listeners.length=extensionListeners.length=0;
  }
  function alive(){
    if(stopped)return false;if(!extension)return true;
    try{if(chrome.runtime?.id===extensionId)return true;}catch{}
    stop();return false;
  }
  const median=a=>{const b=a.slice().sort((x,y)=>x-y),n=b.length;return n%2?b[n>>1]:(b[n/2-1]+b[n/2])/2;};
  async function readPersistent(){
    const before={...revisions};let values;
    if(extension)values=await chrome.storage.local.get(storageKeys);
    else{values={};for(const key of storageKeys)try{const value=localStorage.getItem(key);if(value!==null)values[key]=JSON.parse(value);}catch{}}
    if(!alive())return false;
    for(const key of storageKeys)if((revisions[key]||0)===(before[key]||0)){if(Object.hasOwn(values,key))stored[key]=values[key];else delete stored[key];}
    storageReadable=true;return true;
  }
  function acceptPersistent(){
    if(!session)return;
    const data=F.decode({...stored,...Object.fromEntries([...pendingWrites].map(([key,p])=>[key,p.value]))}),recover=!session.defaultAvailable&&storageReadable&&!session.touched&&!controller?.dirty;
    session.receive(data);session.defaultAvailable=storageReadable;if(recover)session.current=F.snapshot(session.applied);
    changeSettings(session.settings(),recover);controller?.publish();
  }
  async function writeStore(values){
    if(!alive())return false;
    if(!values)return true;
    const before={...revisions};
    if(extension)await chrome.storage.local.set(values);else for(const [key,value]of Object.entries(values))localStorage.setItem(key,JSON.stringify(value));
    if(!alive())return false;
    // A late completion must not overwrite a newer cross-tab storage event.
    for(const [key,value]of Object.entries(values))if((revisions[key]||0)===(before[key]||0)){stored[key]=value;revisions[key]=(revisions[key]||0)+1;}
    try{await readPersistent();}catch{}return alive();
  }
  function writePersistent(values){const pending=writeQueue.then(async()=>writeStore(typeof values==="function"?await values():values));writeQueue=pending.catch(()=>{});return pending;}
  function changeSettings(value,forcePlayback=false){
    if(!alive())return;
    const next=S.normalize(value),languageChanged=next.language!==settings.language;
    const playbackChanged=forcePlayback||["enabled","parameterModel","mode","units","precision","samplingMode","centerPriority","windowLayout","searchMode",...Object.keys(S.fields)].some(name=>next[name]!==settings[name]);
    const previousLocale=I.code;settings=next;I.setLanguage(settings.language);
    if(!controller)return;
    if(languageChanged||previousLocale!==I.code)controller.applyLocale();
    if(playbackChanged)controller.applySettings();
    else{controller.refreshEntry();controller.updateStatus();controller.publish();}
  }
  async function save(patch,forcePlayback=false,focus="all"){
    if(!alive()||!session)return;
    const processing=forcePlayback||F.processingKeys.some(k=>Object.hasOwn(patch,k)),writes=processing?{}:F.preferenceWrites(patch);
    if(processing){
      if(controller)controller.defaultSaveState="";
      session.apply({...settings,...patch});changeSettings(session.settings(),forcePlayback);
      writes[F.keys.applied]=F.record(session.current);
      if(controller&&(forcePlayback||patch.enabled===true))controller.preview(settings,focus,false);
    }
    await persist(writes);
  }
  async function persist(writes){
    const names=Object.keys(writes);if(!alive()||!names.length)return;
    const token=++writeToken;for(const [key,value]of Object.entries(writes))pendingWrites.set(key,{token,value,failed:false});acceptPersistent();
    try{
      // Never overwrite unread settings. Keep the confirmed snapshot available
      // for this tab and for Retry even if reading or saving fails.
      if(!await writePersistent(async()=>{if(!storageReadable)await readPersistent();return writes;}))return;
      for(const key of names)if(pendingWrites.get(key)?.token===token)pendingWrites.delete(key);
    }catch{if(!alive())return;for(const key of names)if(pendingWrites.get(key)?.token===token)pendingWrites.get(key).failed=true;}
    acceptPersistent();
  }
  async function saveDefault(){
    if(!alive()||!session?.defaultAvailable||!controller||controller.defaultSaving||controller.dirty)return;
    // Save only the confirmed profile. Loading a preset or editing the form
    // must pass through Apply first; saving never restarts stabilization.
    const target=controller,profile=F.snapshot(session.current),identity=session.identity;
    const token=++target.defaultSaveToken;
    target.defaultSaving=true;target.defaultSaveState="saving";target.publish();
    const current=()=>controller===target&&!target.dead&&session.identity===identity&&target.defaultSaveToken===token;
    try{
      if(!await writePersistent(async()=>{await readPersistent();const latest=F.decode(stored);return latest.hasPersonal&&F.equal(profile,latest.personal)&&!Object.hasOwn(stored[F.keys.personal],"previous")?null:{[F.keys.personal]:F.record(profile)};}))return;
      acceptPersistent();if(current())target.defaultSaveState=!target.dirty&&F.equal(session.current,profile)?"saved":"";
    }catch{if(!alive())return;if(current())target.defaultSaveState="failed";}
    if(current()){target.defaultSaving=false;target.publish();}
  }
  async function retryStorage(){
    if(!alive())return;
    if(!storageReadable){try{await readPersistent();}catch{}if(alive())acceptPersistent();}
    const writes=Object.fromEntries([...pendingWrites].filter(([,p])=>p.failed).map(([key,p])=>[key,p.value]));
    await persist(writes);
  }
  class Player{
    constructor(player,video){
      this.player=player;this.video=video;this.core=null;this.loading=false;this.renderer=null;this.reader=new P.LumaReader();
      this.dead=false;this.error=false;this.ad=false;this.generation=0;this.callback=null;this.frameTimer=null;this.job=null;this.stillWanted=false;
      this.events=[];this.samples=[];this.drawTimes=[];this.deltas=[];this.slowFrames=[];
      this.outputFrames=0;this.invalid=0;this.resets=0;this.callbackMisses=0;
      this.receivedCallbacks=0;this.deliveryMisses=0;this.busyFrames=0;this.fallbackFrames=0;this.framePolls=0;this.duplicateFrames=0;this.lastCallbackPresented=null;this.lastCallbackTime=null;this.lastFrameTimestamp=null;this.callbackLeadTimes=[];
      this.mediaFps=30;this.sourceFps=30;this.overBudget=false;this.lastTime=null;this.source=video.currentSrc;this.lastMotion=null;this.area=null;this.reason="loading";
      this.performanceMonitor=new W.Monitor();this.waiting=false;
      this.qualityBase=video.getVideoPlaybackQuality?.();this.lastStatus="";this.statusKey="";this.dirty=false;this.saveFailed=false;this.defaultSaveState="";this.defaultSaving=false;this.defaultSaveToken=0;this.errorCode="";this.errorDetail="";
      this.createUI();
      for(const name of ["seeking","seeked","loadedmetadata","emptied","ratechange","ended"])this.listen(video,name,()=>{
        if(name==="loadedmetadata"||name==="emptied"){
          this.source=video.currentSrc;this.error=false;this.errorCode=this.errorDetail="";this.reader.reset();this.samples=[];this.drawTimes=[];
          this.outputFrames=this.invalid=this.callbackMisses=0;this.qualityBase=video.getVideoPlaybackQuality?.();
          this.resetCallbackMetrics();
        }
        this.reset(name);if(name!=="seeking"&&name!=="emptied"&&name!=="ended")this.startOrStill();
      });
      this.listen(video,"play",()=>{this.drawTimes=[];this.performanceMonitor.suspend(performance.now(),false,1000);this.startOrStill();});
      this.listen(video,"waiting",()=>{this.waiting=true;});this.listen(video,"playing",()=>{this.waiting=false;});
      this.listen(video,"loadeddata",()=>this.startOrStill());this.listen(video,"canplay",()=>this.startOrStill());
      this.listen(video,"pause",()=>{this.cancel();this.performanceMonitor.suspend(performance.now());this.updateStatus();this.publish();});
      this.listen(document,"visibilitychange",()=>{this.reset("visibility");if(!document.hidden)this.startOrStill();});
      this.listen(document,"fullscreenchange",()=>this.layout());
      this.listen(video,"resize",()=>this.layout());
      this.listen(window,"resize",()=>this.layout());
      this.listen(window,"scroll",()=>{if(!this.ui.panel.hidden)this.view.layout();this.overlay?.update(this.previewState());});
      this.listen(document,"enterpictureinpicture",()=>this.updateStatus());
      this.resize=new ResizeObserver(()=>this.layout());this.resize.observe(video);this.resize.observe(player);
      this.timer=setInterval(()=>this.tick(),1000);this.applySettings();
    }
    listen(target,name,fn){const handler=(...args)=>{if(alive()&&!this.dead)fn(...args);};target.addEventListener(name,handler);this.events.push([target,name,handler]);}
    createUI(){
      this.overlay=rootOverlay(this.player,this.video);
      this.view=new YTSteadyPlayerUI(this.player,{settings:()=>settings,save,saveDefault,retryStorage,retryProcessing:()=>{if(alive()&&!this.dead&&this.error&&!this.dirty)this.applySettings();},cancel:()=>this.cancelDraft(),useDefault:()=>{if(session.defaultAvailable&&session.hasPersonal)this.view.stageProfile(session.personal);},dimensions:()=>({width:this.area?.sourceWidth||this.video.videoWidth,height:this.area?.sourceHeight||this.video.videoHeight,fps:this.mediaFps}),
        draft:(profile,focus)=>{this.dirty=!profile||!F.equal(profile,settings);this.defaultSaveState="";this.updateStatus();this.publish();this.preview(profile,focus,this.dirty);},preview:(profile,focus)=>this.preview(profile,focus,this.dirty)});
      this.host=this.view.host;this.ui=this.view.elements;this.refreshEntry();
    }
    refreshFields(){this.view.refreshFields(settings);this.dirty=false;this.refreshEntry();}
    refreshEntry(){this.view.refreshEntry(settings,this.error);}
    togglePanel(force){this.view.togglePanel(force);this.layout();}
    previewState(){return {active:!!this.renderer?.active&&!this.error,settings,size:{width:this.area?.sourceWidth||this.video.videoWidth,height:this.area?.sourceHeight||this.video.videoHeight},frame:this.renderer?.active?this.renderer.frame:null,motion:this.lastMotion?{...this.lastMotion,mapX:this.renderer?.map?.x??this.lastMotion.mapX,mapY:this.renderer?.map?.y??this.lastMotion.mapY}:null};}
    preview(profile,focus="all",draft=false){if(alive()&&!this.dead&&settings.enabled&&profile)this.overlay?.show(profile,{focus,draft,state:this.previewState()});}
    cancelDraft(){if(!alive()||this.dead)return;this.refreshFields();this.view.setEffective(this.area,this.lastMotion?.regions);this.overlay?.hide();this.updateStatus();this.publish();}
    layout(){if(!alive()||this.dead)return;this.view.layout();this.renderer?.sync(settings.zoom);this.overlay?.update(this.previewState());}
    applyLocale(){
      this.view.translate();this.refreshEntry();this.updateStatus();this.view.setEffective(this.area);this.publish();
      this.overlay?.update(this.previewState());
    }
    setStatus(key,args={}){
      this.statusKey=key;const text=I.t(key,args);
      if(text!==this.lastStatus){this.lastStatus=text;this.ui.status.textContent=text;}
    }
    updateStatus(){
      if(this.error){this.setStatus(this.errorCode||"errorProcessing");return;}
      if(!storageReadable){this.setStatus("profileLoadFailed");return;}
      if(this.dirty){this.setStatus("statusPending");return;}
      this.saveFailed=[...pendingWrites.values()].some(p=>p.failed);
      if(this.saveFailed){this.setStatus("statusSaveFailed");return;}
      this.setStatus(!settings.enabled?"statusOff":this.loading?"statusLoading":this.ad?"statusAd":
        this.video.seeking?"statusSeeking":this.video.paused&&this.renderer?.active?"statusPaused":
        this.renderer?.active?"statusActive":"statusWaiting");
    }
    async ensureCore(){
      if(!alive()||this.core||this.loading||this.dead||!settings.enabled)return;
      if(typeof VideoFrame!=="function"||typeof this.video.requestVideoFrameCallback!=="function"){
        this.halt("errorUnsupported");return;
      }
      this.loading=true;this.updateStatus();
      try{const core=await P.createCore(asset,lifetime.signal);if(!alive()||this.dead)return;this.core=core;this.reason="ready";}
      catch(error){if(alive()&&!this.dead)this.halt(error.message==="core-version-mismatch-reload-extension"?"errorVersion":"errorCore",error.name+": "+error.message);}
      finally{this.loading=false;if(!this.dead){this.updateStatus();this.startOrStill();}}
    }
    applySettings(){
      this.renderer?.hide();
      if(this.error&&this.renderer){this.renderer.destroy();this.renderer=null;}
      this.samples=[];this.outputFrames=this.invalid=this.callbackMisses=0;this.qualityBase=this.video.getVideoPlaybackQuality?.();
      this.resetCallbackMetrics();
      this.error=false;this.errorCode=this.errorDetail="";this.refreshFields();this.reader.reset();this.reset("settings");
      this.ensureCore();this.startOrStill();this.updateStatus();this.publish();
    }
    resetCallbackMetrics(){this.receivedCallbacks=this.deliveryMisses=this.busyFrames=this.fallbackFrames=this.framePolls=this.duplicateFrames=0;this.callbackLeadTimes=[];}
    cancel(){if(this.callback!==null){this.video.cancelVideoFrameCallback(this.callback);this.callback=null;}if(this.frameTimer!==null){clearTimeout(this.frameTimer);this.frameTimer=null;}}
    reset(reason){
      if(["settings","source","source-recovery","resolution","loadedmetadata","emptied","ratechange","ended"].includes(reason)){this.performanceMonitor.clear(performance.now());this.waiting=false;}
      else this.performanceMonitor.suspend(performance.now(),["seeking","seeked","time-gap"].includes(reason),1000);
      if(reason!=="resolution")this.overlay?.hide();
      if(["source","source-recovery","loadedmetadata","emptied"].includes(reason))this.area=null;
      this.generation++;this.cancel();this.core?.invalidate();this.renderer?.hide();this.lastTime=null;
      this.deltas=[];this.drawTimes=[];this.slowFrames=[];this.overBudget=false;this.reason=reason;this.resets++;
      this.lastCallbackPresented=null;this.lastCallbackTime=null;this.lastFrameTimestamp=null;
    }
    halt(code,detail=""){
      this.performanceMonitor.clear(performance.now());
      this.overlay?.hide();
      this.error=true;this.errorCode=code;this.errorDetail=detail;this.reason="bypass";this.generation++;this.cancel();this.renderer?.hide();this.refreshEntry();this.setStatus(code);this.publish();
    }
    startOrStill(){
      if(!alive()||this.dead||this.error||!settings.enabled||document.hidden||this.video.seeking)return;
      if(!this.core){this.ensureCore();return;}
      if(this.video.paused){this.stillWanted=true;if(!this.job)this.submit(performance.now(),{mediaTime:this.video.currentTime},true);return;}
      if(this.video.ended)return;
      // A video callback is best-effort and can be deferred when the output
      // covers the source video. Check for new native frames independently of
      // the compositor; opening a settings panel must not drive our cadence.
      // At most one timer and one processing job exist. Duplicate timestamps
      // close immediately, so low-fps/high-refresh playback is not reanalyzed.
      if(this.frameTimer===null){
        const delay=Math.max(4,Math.min(16,500/(this.sourceFps*this.video.playbackRate)));
        const timer=setTimeout(()=>{if(this.frameTimer!==timer)return;this.frameTimer=null;this.framePolls++;this.startOrStill();this.submit(performance.now(),{fallback:true},false);},delay);
        this.frameTimer=timer;
      }
      if(this.callback!==null)return;
      this.callback=this.video.requestVideoFrameCallback((now,meta)=>{
        this.callback=null;
        this.receivedCallbacks++;
        if(this.lastCallbackPresented!==null&&meta.presentedFrames>this.lastCallbackPresented+1)this.deliveryMisses+=meta.presentedFrames-this.lastCallbackPresented-1;
        if(this.lastCallbackPresented!==null&&meta.mediaTime>this.lastCallbackTime){const rate=(meta.presentedFrames-this.lastCallbackPresented)/(meta.mediaTime-this.lastCallbackTime);if(Number.isFinite(rate)&&rate>=5&&rate<=240)this.sourceFps=rate;}
        this.lastCallbackPresented=meta.presentedFrames;this.lastCallbackTime=meta.mediaTime;this.callbackMisses=this.deliveryMisses;
        const lead=meta.expectedDisplayTime-performance.now();if(Number.isFinite(lead)){this.callbackLeadTimes.push(lead);if(this.callbackLeadTimes.length>360)this.callbackLeadTimes.shift();}
        // Subscribe before the asynchronous GPU readback. Registering only
        // after processing can miss the compositor's next callback deadline
        // even when the job itself takes less than one source-frame interval.
        // submit still permits only one in-flight job; busy frames are skipped.
        this.startOrStill();this.submit(now,meta,false);
      });
    }
    fps(time){
      if(this.lastTime!==null){const delta=time-this.lastTime;if(delta>1/250&&delta<5){this.deltas.push(delta);if(this.deltas.length>12)this.deltas.shift();}}
      if(this.deltas.length){
        let rate=1/median(this.deltas),common=[12,15,16,18,20,23.976,24,25,29.97,30,48,50,59.94,60,90,120];
        const nearest=common.reduce((a,b)=>Math.abs(b-rate)<Math.abs(a-rate)?b:a);
        if(Math.abs(nearest-rate)/rate<.025)rate=nearest;this.mediaFps=Math.max(5,Math.min(240,rate));
      }
      this.lastTime=time;return this.mediaFps;
    }
    submit(now,meta,still){
      if(!alive()||this.dead||this.error||!settings.enabled||document.hidden||this.video.readyState<2||this.video.seeking)return;
      if(this.job){if(!meta.fallback)this.busyFrames++;return;}
      if(syncIdentity(this.player))return;
      this.stillWanted=false;
      const ad=this.player.classList.contains("ad-showing")||this.player.classList.contains("ad-interrupting");
      if(ad!==this.ad){this.ad=ad;this.reset("ad");this.updateStatus();}
      if(ad){if(!still)this.startOrStill();return;}
      if(this.source!==this.video.currentSrc){this.source=this.video.currentSrc;this.reset("source");this.reader.reset();}
      const profile={...settings};let frame;
      try{frame=new VideoFrame(this.video);}
      catch(error){
        // During source/seek transitions readyState can precede an actually
        // capturable image. Wait for loadeddata/canplay or the next real RVFC;
        // do not turn a temporary decoder state into a persistent bypass.
        if(error.name==="InvalidStateError"){
          this.reason="waiting-for-frame";this.renderer?.hide();this.updateStatus();this.publish();
          if(!still)this.startOrStill();return;
        }
        this.halt(error.name==="SecurityError"?"errorRestricted":"errorCapture",error.name+": "+error.message);return;
      }
      const timestamp=frame.timestamp;
      if(!still&&timestamp===this.lastFrameTimestamp){this.duplicateFrames++;frame.close();return;}
      meta={...meta,mediaTime:timestamp/1000000};
      // Use the captured frame's native timestamp, never an invented clock or
      // a possibly late video callback's timestamp. The callback and watchdog may see the
      // same frame; close duplicates before analysis or history advancement.
      const gapLimit=Math.max(.25,(this.samples.at(-1)?.total||0)/1000*this.video.playbackRate*3);
      if(this.lastTime!==null&&(meta.mediaTime<this.lastTime-.001||meta.mediaTime-this.lastTime>gapLimit))this.reset("time-gap");
      const frameSize=frame.visibleRect.width+"x"+frame.visibleRect.height;
      if(this.frameSize&&this.frameSize!==frameSize)this.reset("resolution");this.frameSize=frameSize;
      this.lastFrameTimestamp=timestamp;
      const generation=this.generation;
      this.job=P.exclusive(async()=>{
        if(!alive()||this.dead||generation!==this.generation||this.error||!settings.enabled)return;
        const begin=performance.now(),area=S.plan(profile,frame.visibleRect.width,frame.visibleRect.height);
        const rate=this.fps(meta.mediaTime);this.core.activate(profile,area,rate);
        const copyBegin=performance.now();let regionSamples;
        if(area.direct)await this.reader.read(frame,area,this.core);else regionSamples=this.reader.readRegions(frame,area);
        if(!alive()||this.dead||generation!==this.generation||this.error||!settings.enabled)return;
        const computeBegin=performance.now(),motion=area.direct?this.core.processSingle(area,profile):this.core.processRegions(regionSamples,area,profile),drawBegin=performance.now();
        if(!this.renderer){
          this.renderer=new P.Renderer(this.video,this.player);
          this.renderer.canvas.addEventListener("contextlost",()=>this.halt("errorCanvas"));
        }
        this.renderer.draw(frame,motion,profile,meta.mediaTime);
        const end=performance.now();this.outputFrames++;if(!motion.valid&&motion.reason!==1)this.invalid++;
        if(meta.fallback)this.fallbackFrames++;
        this.drawTimes.push(end);this.samples.push({total:end-begin,copy:computeBegin-copyBegin,compute:drawBegin-computeBegin,draw:end-drawBegin,delay:end-now});
        if(this.samples.length>360)this.samples.shift();
        this.area=area;this.lastMotion=motion;this.reason=motion.reason===1?"reference":motion.valid?"matched":"scene-or-low-trust";
        this.view.setEffective(area,motion.regions);
        this.overlay?.update(this.previewState());
        const budget=1000/(this.sourceFps*this.video.playbackRate);
        this.slowFrames.push(end-begin>budget*1.3);if(this.slowFrames.length>60)this.slowFrames.shift();
        // The chosen ratio is authoritative. Busy frames are already skipped;
        // report reduced throughput instead of disabling or reducing quality.
        this.overBudget=this.slowFrames.length>=10&&this.slowFrames.filter(Boolean).length>this.slowFrames.length*.6;
        this.updateStatus();
        const sample=this.samples.at(-1);sample.ui=performance.now()-end;sample.job=performance.now()-begin;
      }).catch(error=>{
        if(alive()&&!this.dead&&generation===this.generation)this.halt(error.name==="SecurityError"?"errorRestricted":error.message==="analysis-regions-too-small"?"errorRegionSize":error.message==="sampling-capacity-exceeded"?"errorSamplingCapacity":"errorProcessing",error.name+": "+error.message);
      }).finally(()=>{
        frame.close();this.job=null;
        if(this.dead)return;
        if(this.stillWanted&&this.video.paused)this.startOrStill();else if(!this.video.paused)this.startOrStill();
        if(this.video.paused||this.outputFrames===1)this.publish();
      });
    }
    tick(){
      if(!alive()||this.dead)return;
      if(syncIdentity(this.player))return;
      if(this.source!==this.video.currentSrc){this.source=this.video.currentSrc;this.error=false;this.errorCode=this.errorDetail="";this.reset("source-recovery");this.reader.reset();this.startOrStill();}
      // Chrome can fire loadeddata/canplay before a replacement source has a
      // capturable frame. Paused video gets no later playback callback; retry
      // through the existing lifetime-guarded tick without resetting history.
      if(this.reason==="waiting-for-frame"&&this.video.paused)this.startOrStill();
      this.samplePerformance();
      this.view.layout();this.updateStatus();this.publish();
    }
    samplePerformance(){
      const v=this.video,q=v.getVideoPlaybackQuality?.(),times=this.samples.map(s=>s.job??s.total).sort((a,b)=>a-b);
      let bufferAhead=Infinity;try{bufferAhead=0;for(let n=0;n<(v.buffered?.length||0);n++)if(v.currentTime>=v.buffered.start(n)-.05&&v.currentTime<=v.buffered.end(n)+.05){bufferAhead=Math.max(0,v.buffered.end(n)-v.currentTime);break;}}catch{bufferAhead=Infinity;}
      // sourceFps comes from presented-frame metadata on the media timeline;
      // playbackRate converts it to the browser's attainable wall-clock rate.
      this.performanceMonitor.sample({now:performance.now(),clear:!settings.enabled||this.error,eligible:settings.enabled&&!this.error&&!this.loading&&!!this.core&&!v.paused&&!v.ended&&!v.seeking&&!document.hidden&&!this.ad&&!!v.videoWidth,
        seeking:v.seeking,waiting:this.waiting||v.readyState<3,bufferAhead,mediaTime:v.currentTime,outputFrames:this.outputFrames,sourceFrames:q?.totalVideoFrames||0,dropped:q?.droppedVideoFrames||0,busyFrames:this.busyFrames,targetFps:this.sourceFps*v.playbackRate,
        jobMs:times.reduce((a,b)=>a+b,0)/Math.max(1,times.length),p95Ms:times[Math.floor(times.length*.95)]||0});
    }
    publish(){
      const now=performance.now();this.drawTimes=this.drawTimes.filter(t=>t>now-5000);
      const outputFps=this.drawTimes.length<2?0:(this.drawTimes.length-1)*1000/Math.max(1,this.drawTimes.at(-1)-this.drawTimes[0]);
      const mean=key=>this.samples.reduce((n,s)=>n+(s[key]||0),0)/Math.max(1,this.samples.length),sorted=this.samples.map(s=>s.total).sort((a,b)=>a-b);
      const quality=this.video.getVideoPlaybackQuality?.();
      const state={version,coreLoader:P.coreLoader||"unknown",scheduler:"native-frame-watchdog",...settings,locale:I.code,direction:I.dir,statusKey:this.statusKey,errorDetail:this.errorDetail,active:!!this.renderer?.active,error:this.error,reason:this.reason,outputFrames:this.outputFrames,
        performanceWarning:{...this.performanceMonitor.status(),visible:settings.enabled&&!this.error&&!this.ad},
        profileScope:"last-applied",matchesPersonal:F.equal(settings,session.personal),profileDirty:this.dirty,defaultAvailable:session.defaultAvailable,hasPersonal:session.hasPersonal,defaultSaving:this.defaultSaving,defaultSaveState:this.defaultSaveState,retryStorage:!storageReadable||[...pendingWrites.values()].some(p=>p.failed),
        outputFps:+outputFps.toFixed(1),mediaFps:+this.mediaFps.toFixed(3),sourceFps:+this.sourceFps.toFixed(2),overBudget:this.overBudget,meanMs:+mean("total").toFixed(2),p95Ms:+(sorted[Math.floor(sorted.length*.95)]||0).toFixed(2),
        copyMs:+mean("copy").toFixed(2),computeMs:+mean("compute").toFixed(2),drawMs:+mean("draw").toFixed(2),delayMs:+mean("delay").toFixed(2),
        receivedCallbacks:this.receivedCallbacks,deliveryMisses:this.deliveryMisses,busyFrames:this.busyFrames,fallbackFrames:this.fallbackFrames,framePolls:this.framePolls,duplicateFrames:this.duplicateFrames,callbackLeadMs:+(this.callbackLeadTimes.reduce((a,b)=>a+b,0)/Math.max(1,this.callbackLeadTimes.length)).toFixed(2),lateCallbacks:this.callbackLeadTimes.filter(t=>t<0).length,jobMs:+mean("job").toFixed(2),uiMs:+mean("ui").toFixed(2),desynchronized:this.renderer?.desynchronized??null,
        invalidMatches:this.invalid,callbackMisses:this.callbackMisses,resets:this.resets,pixelFormat:this.reader.format,area:this.area,regions:this.lastMotion?.regions||{selected:1,candidates:1,inliers:this.lastMotion?.valid?1:0},
        mapX:this.lastMotion?.mapX||0,mapY:this.lastMotion?.mapY||0,trustValue:this.lastMotion?.trust||0,mediaTime:this.lastTime||0,
        stabilitySteps:this.lastMotion?.stabilitySteps||0,effectiveCutoff:Math.min(settings.cutoff,this.mediaFps/2),
        paused:this.video.paused,status:this.lastStatus,total:Math.max(0,(quality?.totalVideoFrames||0)-(this.qualityBase?.totalVideoFrames||0)),
        dropped:Math.max(0,(quality?.droppedVideoFrames||0)-(this.qualityBase?.droppedVideoFrames||0))};
      this.host.dataset.state=JSON.stringify(state);
      this.view.publish(state);
    }
    destroy(){
      if(this.dead)return;
      this.dead=true;this.generation++;this.cancel();clearInterval(this.timer);this.resize.disconnect();
      for(const [target,name,fn]of this.events)target.removeEventListener(name,fn);
      this.events=[];this.reader.reset();this.core=null;this.renderer?.destroy();this.renderer=null;this.overlay?.destroy();this.view.destroy?.();this.host.remove();
    }
  }
  function rootOverlay(player,video){return globalThis.YTSteadyOverlay?new YTSteadyOverlay(player,video):null;}
  function videoIdentity(){
    if(testPage)return "test:"+(new URLSearchParams(location.search).get("testVideo")||"synthetic");
    return location.pathname==="/watch"?new URLSearchParams(location.search).get("v"):null;
  }
  function syncIdentity(){
    if(!loaded||!session||!session.newVideo(videoIdentity()))return false;
    if(controller){controller.defaultSaveToken++;controller.defaultSaving=false;controller.defaultSaveState="";}
    changeSettings(session.settings(),true);return true;
  }
  function reconcile(){
    reconcileTimer=0;
    if(!alive()||!loaded)return;
    const allowed=testPage||(location.pathname==="/watch"&&new URLSearchParams(location.search).has("v"));
    const player=allowed?document.querySelector(testPage?"[data-ytsteady-test-player]":"#movie_player"):null;
    const video=player?.querySelector("video.html5-main-video,video");
    if(controller&&(controller.video!==video||controller.player!==player||!video?.isConnected)){controller.destroy();controller=null;}
    syncIdentity();
    if(!controller&&player&&video)controller=new Player(player,video);
  }
  function queueReconcile(){if(alive()&&!reconcileTimer)reconcileTimer=setTimeout(reconcile,150);}
  observer=new MutationObserver(queueReconcile);observer.observe(document.documentElement,{childList:true,subtree:true});
  for(const name of ["yt-navigate-finish","yt-page-data-updated"])listen(document,name,queueReconcile);
  listen(window,"popstate",queueReconcile);
  if(extension){
    const changed=(changes,area)=>{
      if(!alive())return;
      if(area!=="local")return;let relevant=false;
      for(const key of storageKeys)if(changes[key]){relevant=true;revisions[key]=(revisions[key]||0)+1;if(changes[key].newValue===undefined)delete stored[key];else stored[key]=changes[key].newValue;}
      if(relevant)acceptPersistent();
    };
    const message=(message,sender,reply)=>{if(alive()&&message?.type==="yt-steady-panel"){controller?.togglePanel(true);reply({found:!!controller,version});}};
    for(const [event,fn]of [[chrome.storage.onChanged,changed],[chrome.runtime.onMessage,message]]){event.addListener(fn);extensionListeners.push([event,fn]);}
  }else listen(window,"storage",event=>{if(storageKeys.includes(event.key)){revisions[event.key]=(revisions[event.key]||0)+1;try{if(event.newValue===null)delete stored[event.key];else stored[event.key]=JSON.parse(event.newValue);}catch{delete stored[event.key];}acceptPersistent();}});
  listen(window,"languagechange",()=>{if(alive()&&settings.language==="auto"){I.setLanguage("auto");controller?.applyLocale();}});
  (async()=>{
    try{await readPersistent();}catch{}if(!alive())return;
    session=new F.Session(F.decode(stored),videoIdentity());session.defaultAvailable=storageReadable;
    if(!storageReadable)session.current=F.snapshot({...S.defaults,enabled:false});
    settings=session.settings();loaded=true;I.setLanguage(settings.language);reconcile();
  })();
})();
